-- ============================================
-- SCRIPT RAPIDO: Inicializar Categorías
-- Ejecuta esto si necesitas crear/recrear las categorías
-- ============================================

USE encantoea;

-- Opción 1: Si NO tienes categorías y quieres crearlas
-- (Descomenta las siguientes líneas)

/*
INSERT INTO categoria (nombre, descripcion) VALUES
('Arreglos Florales', 'Arreglos y bouquets de flores naturales y artificiales'),
('Regalos', 'Peluches, chocolates y detalles complementarios'),
('Caja de regalos', 'Cajas decorativas con flores, chocolates y sorpresas');
*/

-- Opción 2: Si YA tienes categorías, solo verlas
SELECT 'Categorías actuales:' AS Estado;
SELECT 
    id,
    nombre,
    descripcion
FROM categoria;

-- Verificar cuántos productos hay por categoría
SELECT 'Productos por categoría:' AS Estado;
SELECT 
    c.nombre AS Categoria,
    COUNT(p.id) AS 'Total Productos'
FROM categoria c
LEFT JOIN producto p ON c.id = p.categoria_id
GROUP BY c.id, c.nombre;
