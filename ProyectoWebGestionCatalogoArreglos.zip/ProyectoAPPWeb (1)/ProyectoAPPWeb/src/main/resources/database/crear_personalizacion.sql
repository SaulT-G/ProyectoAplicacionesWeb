-- ========================================================================
-- SCRIPT SQL: Crear tablas para Personalización de Productos
-- ========================================================================
-- Fecha: 2026-01-02
-- Base de datos: encanto_ea
-- ========================================================================

USE encanto_ea;

-- Tabla: producto_personalizado
-- Almacena los productos personalizados por los compradores
CREATE TABLE IF NOT EXISTS producto_personalizado (
    id INT PRIMARY KEY AUTO_INCREMENT,
    seccion_id INT,
    precio DOUBLE NOT NULL DEFAULT 0.0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (seccion_id) REFERENCES seccion_personalizacion(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla: producto_personalizado_opciones
-- Tabla intermedia Many-to-Many entre producto_personalizado y producto_personalizable
CREATE TABLE IF NOT EXISTS producto_personalizado_opciones (
    producto_personalizado_id INT NOT NULL,
    opcion_id INT NOT NULL,
    PRIMARY KEY (producto_personalizado_id, opcion_id),
    FOREIGN KEY (producto_personalizado_id) REFERENCES producto_personalizado(id) ON DELETE CASCADE,
    FOREIGN KEY (opcion_id) REFERENCES producto_personalizable(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Índices para mejor rendimiento
CREATE INDEX idx_producto_personalizado_seccion ON producto_personalizado(seccion_id);
CREATE INDEX idx_opciones_personalizado ON producto_personalizado_opciones(producto_personalizado_id);
CREATE INDEX idx_opciones_opcion ON producto_personalizado_opciones(opcion_id);

-- ========================================================================
-- VERIFICACIÓN
-- ========================================================================
SHOW TABLES LIKE 'producto_personalizado%';
DESCRIBE producto_personalizado;
DESCRIBE producto_personalizado_opciones;
