-- Script para crear la tabla producto en MySQL
CREATE DATABASE IF NOT EXISTS encantoea;
USE encantoea;

-- Tabla de Categorías
CREATE TABLE IF NOT EXISTS categoria (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  descripcion VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabla de Productos
CREATE TABLE IF NOT EXISTS producto (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(255) NOT NULL,
  categoria_id INT,
  precio DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  descripcion TEXT,
  imagen VARCHAR(255),
  stock INT NOT NULL DEFAULT 0,
  descuento DOUBLE NOT NULL DEFAULT 0.0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (categoria_id) REFERENCES categoria(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insertar categorías de ejemplo
INSERT INTO categoria (nombre, descripcion) VALUES
('Ramos', 'Ramos de flores variados'),
('Cajas de Regalo', 'Cajas decorativas con flores y detalles'),
('Arreglos Florales', 'Arreglos florales personalizados'),
('Globos', 'Globos decorativos para ocasiones especiales'),
('Peluches', 'Peluches y complementos'),
('Ocasiones Especiales', 'Productos para eventos y celebraciones');

-- Insertar productos de ejemplo
INSERT INTO producto (nombre, categoria_id, precio, descripcion, stock, descuento) VALUES
('Ramo de Rosas Rojas', 1, 45.00, 'Elegante ramo de 12 rosas rojas premium', 50, 0),
('Caja Rosa Premium', 2, 35.00, 'Caja decorativa con flores y chocolates', 30, 10),
('Arreglo Aniversario', 3, 55.00, 'Arreglo especial para aniversarios', 20, 15);