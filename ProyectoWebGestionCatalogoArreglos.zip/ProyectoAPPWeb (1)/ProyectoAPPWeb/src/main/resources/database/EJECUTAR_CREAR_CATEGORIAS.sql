-- ============================================
-- SOLUCIÓN: Crear Categorías
-- Ejecuta este script COMPLETO en MySQL Workbench
-- ============================================

-- Paso 1: Usar la base de datos correcta
USE encantoea;

-- Paso 2: Verificar estado actual
SELECT 'ANTES - Categorías actuales:' AS Estado;
SELECT COUNT(*) AS 'Total Categorías' FROM categoria;

-- Paso 3: Insertar las 3 categorías principales
INSERT INTO categoria (nombre, descripcion) VALUES
('Arreglos Florales', 'Arreglos y bouquets de flores naturales y artificiales'),
('Regalos', 'Peluches, chocolates y detalles complementarios'),
('Caja de regalos', 'Cajas decorativas con flores, chocolates y sorpresas');

-- Paso 4: Verificar que se crearon correctamente
SELECT 'DESPUÉS - Categorías creadas:' AS Estado;
SELECT * FROM categoria;

-- Deberías ver 3 categorías con IDs 1, 2 y 3
