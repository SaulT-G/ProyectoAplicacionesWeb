-- Script SQL para crear las tablas del sistema Encanto EA
-- Base de datos: encantoea

-- Crear tabla de usuarios (clase base)
CREATE TABLE IF NOT EXISTS usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    correo_electronico VARCHAR(150) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL,
    telefono VARCHAR(20),
    estado VARCHAR(20) NOT NULL DEFAULT 'ACTIVO',
    rol VARCHAR(20) NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Crear tabla de compradores (hereda de usuario)
CREATE TABLE IF NOT EXISTS comprador (
    id_usuario INT PRIMARY KEY,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario) ON DELETE CASCADE
);

-- Crear tabla de categorías (si no existe)
CREATE TABLE IF NOT EXISTS categoria (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion VARCHAR(255)
);

-- Crear tabla de productos (si no existe)
CREATE TABLE IF NOT EXISTS producto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    categoria_id INT,
    precio DECIMAL(10, 2) NOT NULL,
    descripcion TEXT,
    imagen VARCHAR(255),
    stock INT DEFAULT 0,
    descuento INT DEFAULT 0,
    FOREIGN KEY (categoria_id) REFERENCES categoria(id) ON DELETE SET NULL
);

-- Insertar datos de ejemplo de categorías
INSERT INTO categoria (nombre, descripcion) VALUES
('Ramos', 'Hermosos ramos de flores frescas'),
('Cajas Florales', 'Arreglos en elegantes cajas'),
('Arreglos Premium', 'Diseños exclusivos y sofisticados'),
('Flores Secas', 'Arreglos de flores preservadas')
ON DUPLICATE KEY UPDATE nombre = nombre;

-- Insertar datos de ejemplo de productos
INSERT INTO producto (nombre, categoria_id, precio, descripcion, imagen, stock, descuento) VALUES
('Ramo de Rosas Premium', 1, 89.90, 'Elegante ramo de 12 rosas rojas premium con follaje decorativo', 'Ramo.jpeg', 15, 10),
('Caja Floral Deluxe', 2, 129.90, 'Sofisticada caja con rosas y lisianthus en tonos pastel', 'CajaFloral.jpeg', 8, 15),
('Arreglo Premium Especial', 3, 159.90, 'Diseño exclusivo con flores exóticas y follaje tropical', 'CajaPremium.jpg', 5, 20),
('Ramo Silvestre', 1, 69.90, 'Hermoso ramo campestre con flores de temporada', 'Ramo.jpeg', 20, 0),
('Caja Rosa Elegante', 2, 99.90, 'Caja decorativa con rosas y hortensias', 'CajaFloral.jpeg', 12, 5)
ON DUPLICATE KEY UPDATE nombre = nombre;

-- Insertar usuario administrador de ejemplo
INSERT INTO usuario (nombre, correo_electronico, contrasena, telefono, estado, rol) VALUES
('Administrador', 'admin@encantoea.com', 'admin123', '999888777', 'ACTIVO', 'ADMIN')
ON DUPLICATE KEY UPDATE correo_electronico = correo_electronico;

-- Insertar comprador de ejemplo
INSERT INTO usuario (nombre, correo_electronico, contrasena, telefono, estado, rol) VALUES
('Juan Pérez', 'juan@example.com', '123456', '987654321', 'ACTIVO', 'COMPRADOR')
ON DUPLICATE KEY UPDATE correo_electronico = correo_electronico;

-- Insertar en tabla comprador especificando el alias para evitar ambigüedad
INSERT INTO comprador (id_usuario) 
SELECT u.id_usuario FROM usuario u WHERE u.correo_electronico = 'juan@example.com'
ON DUPLICATE KEY UPDATE comprador.id_usuario = comprador.id_usuario;
