-- Script para actualizar categorías a las 3 principales
USE encantoea;

-- Limpiar categorías existentes
DELETE FROM producto;
DELETE FROM categoria;

-- Insertar las 3 categorías principales
INSERT INTO categoria (id, nombre, descripcion) VALUES
(1, 'Arreglos Florales', 'Arreglos y bouquets de flores naturales y artificiales'),
(2, 'Regalos', 'Peluches, chocolates y detalles complementarios'),
(3, 'Caja de regalos', 'Cajas decorativas con flores, chocolates y sorpresas');

-- Insertar productos de ejemplo para cada categoría
INSERT INTO producto (nombre, categoria_id, precio, descripcion, stock, descuento) VALUES
('Bouquet de Rosas', 1, 45.00, 'Elegante bouquet de 12 rosas rojas premium', 50, 0),
('Arreglo Primaveral', 1, 38.00, 'Arreglo floral con flores de temporada', 30, 10),
('Peluche Osito', 2, 25.00, 'Peluche de osito suave 40cm', 40, 0),
('Chocolates Ferrero', 2, 18.00, 'Caja de chocolates Ferrero Rocher 16 piezas', 60, 5),
('Caja Premium Rosa', 3, 55.00, 'Caja elegante con rosas, chocolates y peluche', 20, 15),
('Caja Aniversario', 3, 65.00, 'Caja especial para aniversarios con detalles exclusivos', 15, 10);

-- Verificar
SELECT 'Categorías creadas:' as Resultado;
SELECT * FROM categoria;

SELECT 'Productos de ejemplo:' as Resultado;
SELECT p.id, p.nombre, c.nombre as categoria, p.precio, p.stock 
FROM producto p 
LEFT JOIN categoria c ON p.categoria_id = c.id;
