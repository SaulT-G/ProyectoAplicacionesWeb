-- Script SEGURO para actualizar categorías SIN BORRAR productos existentes
USE encantoea;

-- Mostrar categorías actuales
SELECT 'Categorías ANTES de actualizar:' as Info;
SELECT * FROM categoria;

-- Verificar si hay productos
SELECT 'Total de productos actuales:' as Info, COUNT(*) as Total FROM producto;

-- Limpiar SOLO categorías (los productos se mantienen pero quedan sin categoría)
DELETE FROM categoria;

-- Resetear auto-increment
ALTER TABLE categoria AUTO_INCREMENT = 1;

-- Insertar las 3 categorías principales
INSERT INTO categoria (nombre, descripcion) VALUES
('Arreglos Florales', 'Arreglos y bouquets de flores naturales y artificiales'),
('Regalos', 'Peluches, chocolates y detalles complementarios'),
('Caja de regalos', 'Cajas decorativas con flores, chocolates y sorpresas');

-- Insertar productos de ejemplo SOLO si no hay productos
INSERT INTO producto (nombre, categoria_id, precio, descripcion, stock, descuento)
SELECT * FROM (
    SELECT 'Bouquet de Rosas' as nombre, 1 as categoria_id, 45.00 as precio, 'Elegante bouquet de 12 rosas rojas premium' as descripcion, 50 as stock, 0 as descuento
    UNION ALL
    SELECT 'Arreglo Primaveral', 1, 38.00, 'Arreglo floral con flores de temporada', 30, 10
    UNION ALL
    SELECT 'Peluche Osito', 2, 25.00, 'Peluche de osito suave 40cm', 40, 0
    UNION ALL
    SELECT 'Chocolates Ferrero', 2, 18.00, 'Caja de chocolates Ferrero Rocher 16 piezas', 60, 5
    UNION ALL
    SELECT 'Caja Premium Rosa', 3, 55.00, 'Caja elegante con rosas, chocolates y peluche', 20, 15
    UNION ALL
    SELECT 'Caja Aniversario', 3, 65.00, 'Caja especial para aniversarios con detalles exclusivos', 15, 10
) AS tmp
WHERE (SELECT COUNT(*) FROM producto) = 0;

-- Mostrar resultado
SELECT 'Categorías DESPUÉS de actualizar:' as Info;
SELECT * FROM categoria;

SELECT 'Productos en base de datos:' as Info;
SELECT p.id, p.nombre, c.nombre as categoria, p.precio, p.stock 
FROM producto p 
LEFT JOIN categoria c ON p.categoria_id = c.id;

SELECT 'Productos SIN categoría asignada:' as Info;
SELECT COUNT(*) as Total FROM producto WHERE categoria_id IS NULL OR categoria_id NOT IN (SELECT id FROM categoria);
