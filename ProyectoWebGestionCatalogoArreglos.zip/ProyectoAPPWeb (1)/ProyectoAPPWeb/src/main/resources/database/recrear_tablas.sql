-- ====================================================================
-- SCRIPT DE LIMPIEZA Y RECREACIÓN DE TABLAS
-- Ejecutar este script si ya tenías tablas creadas con la estructura incorrecta
-- ====================================================================

-- Desactivar verificación de claves foráneas temporalmente
SET FOREIGN_KEY_CHECKS = 0;

-- Eliminar tablas existentes (en el orden correcto)
DROP TABLE IF EXISTS comprador;
DROP TABLE IF EXISTS usuario;
DROP TABLE IF EXISTS producto;
DROP TABLE IF EXISTS categoria;

-- Reactivar verificación de claves foráneas
SET FOREIGN_KEY_CHECKS = 1;

-- ====================================================================
-- CREAR TABLAS CON LA ESTRUCTURA CORRECTA
-- ====================================================================

-- Crear tabla de usuarios (clase base)
CREATE TABLE usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    correo_electronico VARCHAR(150) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL,
    telefono VARCHAR(20),
    estado VARCHAR(20) NOT NULL DEFAULT 'ACTIVO',
    rol VARCHAR(20) NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Crear tabla de compradores (hereda de usuario)
CREATE TABLE comprador (
    id_usuario INT PRIMARY KEY,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario) ON DELETE CASCADE
);

-- Crear tabla de categorías
CREATE TABLE categoria (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion VARCHAR(255)
);

-- Crear tabla de productos
CREATE TABLE producto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    categoria_id INT,
    precio DECIMAL(10, 2) NOT NULL,
    descripcion TEXT,
    imagen VARCHAR(255),
    stock INT DEFAULT 0,
    descuento INT DEFAULT 0,
    FOREIGN KEY (categoria_id) REFERENCES categoria(id) ON DELETE SET NULL
);

-- ====================================================================
-- INSERTAR DATOS DE EJEMPLO
-- ====================================================================

-- Insertar categorías
INSERT INTO categoria (nombre, descripcion) VALUES
('Ramos', 'Hermosos ramos de flores frescas'),
('Cajas Florales', 'Arreglos en elegantes cajas'),
('Arreglos Premium', 'Diseños exclusivos y sofisticados'),
('Flores Secas', 'Arreglos de flores preservadas');

-- Insertar productos de ejemplo
INSERT INTO producto (nombre, categoria_id, precio, descripcion, imagen, stock, descuento) VALUES
('Ramo de Rosas Premium', 1, 89.90, 'Elegante ramo de 12 rosas rojas premium con follaje decorativo', 'Ramo.jpeg', 15, 10),
('Caja Floral Deluxe', 2, 129.90, 'Sofisticada caja con rosas y lisianthus en tonos pastel', 'CajaFloral.jpeg', 8, 15),
('Arreglo Premium Especial', 3, 159.90, 'Diseño exclusivo con flores exóticas y follaje tropical', 'CajaPremium.jpg', 5, 20),
('Ramo Silvestre', 1, 69.90, 'Hermoso ramo campestre con flores de temporada', 'Ramo.jpeg', 20, 0),
('Caja Rosa Elegante', 2, 99.90, 'Caja decorativa con rosas y hortensias', 'CajaFloral.jpeg', 12, 5);

-- Insertar usuario administrador
INSERT INTO usuario (nombre, correo_electronico, contrasena, telefono, estado, rol) VALUES
('Administrador', 'admin@encantoea.com', 'admin123', '999888777', 'ACTIVO', 'ADMIN');

-- Insertar comprador de ejemplo
INSERT INTO usuario (nombre, correo_electronico, contrasena, telefono, estado, rol) VALUES
('Juan Pérez', 'juan@example.com', '123456', '987654321', 'ACTIVO', 'COMPRADOR');

-- Insertar en tabla comprador
INSERT INTO comprador (id_usuario) 
SELECT u.id_usuario FROM usuario u WHERE u.correo_electronico = 'juan@example.com';

-- ====================================================================
-- VERIFICAR DATOS INSERTADOS
-- ====================================================================

SELECT 'Categorías insertadas:' AS Mensaje;
SELECT * FROM categoria;

SELECT 'Productos insertados:' AS Mensaje;
SELECT * FROM producto;

SELECT 'Usuarios insertados:' AS Mensaje;
SELECT * FROM usuario;

SELECT 'Compradores insertados:' AS Mensaje;
SELECT * FROM comprador;

-- ====================================================================
-- SCRIPT COMPLETADO
-- ====================================================================
