-- Datos iniciales para H2 Database (se cargan automáticamente)

-- Insertar las 3 categorías principales
INSERT INTO categoria (nombre, descripcion) VALUES
('Arreglos Florales', 'Arreglos y bouquets de flores naturales y artificiales'),
('Regalos', 'Peluches, chocolates y detalles complementarios'),
('Caja de regalos', 'Cajas decorativas con flores, chocolates y sorpresas');

-- Insertar productos de ejemplo para cada categoría
INSERT INTO producto (nombre, categoria_id, precio, descripcion, stock, descuento) VALUES
('Bouquet de Rosas', 1, 45.00, 'Elegante bouquet de 12 rosas rojas premium', 50, 0),
('Arreglo Primaveral', 1, 38.00, 'Arreglo floral con flores de temporada', 30, 10),
('Peluche Osito', 2, 25.00, 'Peluche de osito suave 40cm', 40, 0),
('Chocolates Ferrero', 2, 18.00, 'Caja de chocolates Ferrero Rocher 16 piezas', 60, 5),
('Caja Premium Rosa', 3, 55.00, 'Caja elegante con rosas, chocolates y peluche', 20, 15),
('Caja Aniversario', 3, 65.00, 'Caja especial para aniversarios con detalles exclusivos', 15, 10);
