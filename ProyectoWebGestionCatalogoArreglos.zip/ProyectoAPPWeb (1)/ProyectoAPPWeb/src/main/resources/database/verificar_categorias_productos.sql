-- Script de Verificación Rápida: Categorías y Productos
-- Ejecuta este script en MySQL Workbench para verificar el estado actual

USE encantoea;

-- ===== PASO 1: Ver todas las categorías =====
SELECT '==== CATEGORÍAS DISPONIBLES ====' AS Info;
SELECT 
    id AS 'ID',
    nombre AS 'Nombre',
    descripcion AS 'Descripción'
FROM categoria
ORDER BY id;

-- ===== PASO 2: Ver todos los productos con sus categorías =====
SELECT '==== PRODUCTOS CON CATEGORÍAS ====' AS Info;
SELECT 
    p.id AS 'ID',
    p.nombre AS 'Producto',
    IFNULL(c.nombre, '❌ SIN CATEGORÍA') AS 'Categoría',
    p.precio AS 'Precio',
    p.stock AS 'Stock',
    p.descuento AS 'Descuento %'
FROM producto p
LEFT JOIN categoria c ON p.categoria_id = c.id
ORDER BY p.id;

-- ===== PASO 3: Verificar productos sin categoría =====
SELECT '==== PRODUCTOS SIN CATEGORÍA ====' AS Info;
SELECT 
    p.id,
    p.nombre,
    p.precio
FROM producto p
WHERE p.categoria_id IS NULL 
   OR p.categoria_id NOT IN (SELECT id FROM categoria);

-- ===== PASO 4: Estadísticas =====
SELECT '==== ESTADÍSTICAS ====' AS Info;
SELECT 
    'Total Categorías' AS Métrica,
    COUNT(*) AS Cantidad
FROM categoria
UNION ALL
SELECT 
    'Total Productos',
    COUNT(*)
FROM producto
UNION ALL
SELECT 
    'Productos con Categoría',
    COUNT(*)
FROM producto
WHERE categoria_id IS NOT NULL 
  AND categoria_id IN (SELECT id FROM categoria)
UNION ALL
SELECT 
    'Productos SIN Categoría',
    COUNT(*)
FROM producto
WHERE categoria_id IS NULL 
   OR categoria_id NOT IN (SELECT id FROM categoria);

-- ===== PASO 5: Productos por categoría =====
SELECT '==== PRODUCTOS POR CATEGORÍA ====' AS Info;
SELECT 
    c.nombre AS 'Categoría',
    COUNT(p.id) AS 'Cantidad de Productos'
FROM categoria c
LEFT JOIN producto p ON c.id = p.categoria_id
GROUP BY c.id, c.nombre
ORDER BY COUNT(p.id) DESC;
