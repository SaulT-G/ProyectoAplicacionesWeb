package controlador;

import dao.ProductoPersonalizableDAO;
import dao.SeccionDePersonalizacionDAO;
import dao.DBUtil;
import modelo.entities.ProductoPersonalizable;
import modelo.entities.SeccionDePersonalizacion;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

@WebServlet(name = "GestionarProductosPersonalizacionServlet", urlPatterns = {"/GestionarProductosPersonalizacion"})
@MultipartConfig(maxFileSize = 5 * 1024 * 1024) // 5MB
public class GestionarProductosPersonalizacionServlet extends HttpServlet {

	// Thread-local para almacenar la lista de secciones durante la petición
    private static final ThreadLocal<List<SeccionDePersonalizacion>> threadSecciones = new ThreadLocal<>();

    // Devuelve la lista de productos personalizables para mostrar en la gestión.
    public List<ProductoPersonalizable> solicitarGestionPersonalizacion() throws Exception {
        ProductoPersonalizableDAO dao = new ProductoPersonalizableDAO();
        return dao.obtenerProductosPersonalizables();
    }

    // Inserta un nuevo producto personalizable con sus datos y devuelve si fue exitoso.
    public boolean ingresarNuevoPersonalizable(String nombre, SeccionDePersonalizacion seccion, double precio, int stock, byte[] imagen, String descripcion) throws Exception {
        ProductoPersonalizableDAO dao = new ProductoPersonalizableDAO();
        boolean ok = dao.guardarPersonalizable(nombre, seccion, precio, stock, imagen, descripcion);
        return ok;
    }

    // Obtiene un producto personalizable por id para ver sus detalles.
    public ProductoPersonalizable ver(int id) throws Exception {
        ProductoPersonalizableDAO dao = new ProductoPersonalizableDAO();
        return dao.obtenerPersonalizable(id);
    }

    // Actualiza la información de un producto y sincroniza su sección.
    public boolean actualizarInfoPersonalizable(int id, String nombre, SeccionDePersonalizacion seccion, double precio, int stock, byte[] imagen, String descripcion) throws Exception {
        ProductoPersonalizableDAO dao = new ProductoPersonalizableDAO();
        boolean ok = dao.actualizarPersonalizable(id, nombre, seccion, precio, stock, imagen, descripcion);
        if (ok) {
            SeccionDePersonalizacionDAO sdao = new SeccionDePersonalizacionDAO();
            ProductoPersonalizable p = dao.obtenerPersonalizable(id);
            sdao.actualizarSeccionPersonalizable(p);
        }
        return ok;
    }

    // Elimina un producto por id y limpia su relación con la sección.
    public boolean eliminar(int id) throws Exception {
        ProdutoPersonalizableDAO_CHECK: {
            // label used to avoid accidental removal of logic when editing
        }
        ProductoPersonalizableDAO dao = new ProductoPersonalizableDAO();
        boolean ok = dao.eliminarPersonalizable(id);
        if (ok) {
            SeccionDePersonalizacionDAO sdao = new SeccionDePersonalizacionDAO();
            sdao.eliminarPersonalizableDeSeccion(id);
        }
        return ok;
    }

    // Carga las secciones y las guarda en thread-local para su uso en la petición.
    public void agregarNuevoProducto() throws Exception {
        SeccionDePersonalizacionDAO sdao = new SeccionDePersonalizacionDAO();
        List<SeccionDePersonalizacion> secciones = sdao.obtenerSeccionesPersonalizacion();
        threadSecciones.set(secciones);
    }

    // Devuelve el producto para edición (wrapper de ver).
    public ProductoPersonalizable editar(int id) throws Exception {
        return ver(id);
    }

    // Recupera y limpia la lista de secciones del thread-local
    private List<SeccionDePersonalizacion> takeThreadSecciones() {
        List<SeccionDePersonalizacion> s = threadSecciones.get();
        threadSecciones.remove();
        return s;
    }

    // Maneja peticiones POST: orquesta create/update/delete delegando a métodos del servlet.
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            if ("create".equals(action)) {
                String nombre = request.getParameter("nombre");
                double precio = Double.parseDouble(request.getParameter("precio"));
                String descripcion = request.getParameter("descripcion");
                int stock = Integer.parseInt(request.getParameter("stock"));
                String seccionId = request.getParameter("seccionId");

                Part imagenPart = request.getPart("imagen");
                byte[] img = null;
                if (imagenPart != null && imagenPart.getSize() > 0) {
                    long dbMax = getDbMaxAllowedPacket();
                    long partSize = imagenPart.getSize();
                    if (dbMax > 0 && partSize > dbMax) {
                        String msg = "El archivo es demasiado grande para la configuración del servidor DB (" + partSize + " bytes > max_allowed_packet=" + dbMax + "). Incrementa 'max_allowed_packet' en MySQL o sube una imagen más pequeña.";
                        String url = request.getContextPath() + "/GestionarProductosPersonalizacion?msg=" + URLEncoder.encode(msg, StandardCharsets.UTF_8) + "&type=" + URLEncoder.encode("error", StandardCharsets.UTF_8);
                        response.sendRedirect(url);
                        return;
                    }
                    try (InputStream is = imagenPart.getInputStream()) {
                        img = is.readAllBytes();
                    }
                }

                SeccionDePersonalizacion s = null;
                if (seccionId != null && !seccionId.isEmpty()) {
                    // obtener secciones via agregarNuevoProducto() (no llamar DAOs directamente)
                    agregarNuevoProducto();
                    List<SeccionDePersonalizacion> tmp = takeThreadSecciones();
                    if (tmp != null) {
                        for (SeccionDePersonalizacion sec : tmp) {
                            if (sec.getId() != null && sec.getId() == Integer.parseInt(seccionId)) {
                                s = sec;
                                break;
                            }
                        }
                    }
                }

                boolean ok = ingresarNuevoPersonalizable(nombre, s, precio, stock, img, descripcion);
                String msg = ok ? "Producto creado correctamente" : "No se pudo crear el producto";
                String type = ok ? "exito" : "error";
                String url = request.getContextPath() + "/GestionarProductosPersonalizacion?msg=" + URLEncoder.encode(msg, StandardCharsets.UTF_8) + "&type=" + URLEncoder.encode(type, StandardCharsets.UTF_8);
                response.sendRedirect(url);
                return;
            } else if ("update".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                String nombre = request.getParameter("nombre");
                double precio = Double.parseDouble(request.getParameter("precio"));
                String descripcion = request.getParameter("descripcion");
                int stock = Integer.parseInt(request.getParameter("stock"));
                String seccionId = request.getParameter("seccionId");

                Part imagenPart = request.getPart("imagen");
                byte[] img = null;
                if (imagenPart != null && imagenPart.getSize() > 0) {
                    long dbMax = getDbMaxAllowedPacket();
                    long partSize = imagenPart.getSize();
                    if (dbMax > 0 && partSize > dbMax) {
                        String msg = "El archivo es demasiado grande para la configuración del servidor DB (" + partSize + " bytes > max_allowed_packet=" + dbMax + "). Incrementa 'max_allowed_packet' en MySQL o sube una imagen más pequeña.";
                        String url = request.getContextPath() + "/GestionarProductosPersonalizacion?msg=" + URLEncoder.encode(msg, StandardCharsets.UTF_8) + "&type=" + URLEncoder.encode("error", StandardCharsets.UTF_8);
                        response.sendRedirect(url);
                        return;
                    }
                    try (InputStream is = imagenPart.getInputStream()) {
                        img = is.readAllBytes();
                    }
                }

                SeccionDePersonalizacion s = null;
                if (seccionId != null && !seccionId.isEmpty()) {
                    // obtener secciones via agregarNuevoProducto() (no llamar DAOs directamente)
                    agregarNuevoProducto();
                    List<SeccionDePersonalizacion> tmp = takeThreadSecciones();
                    if (tmp != null) {
                        for (SeccionDePersonalizacion sec : tmp) {
                            if (sec.getId() != null && sec.getId() == Integer.parseInt(seccionId)) {
                                s = sec;
                                break;
                            }
                        }
                    }
                }

                boolean ok = actualizarInfoPersonalizable(id, nombre, s, precio, stock, img, descripcion);
                String msg = ok ? "Producto actualizado correctamente" : "No se pudo actualizar el producto";
                String type = ok ? "exito" : "error";
                String url = request.getContextPath() + "/GestionarProductosPersonalizacion?msg=" + URLEncoder.encode(msg, StandardCharsets.UTF_8) + "&type=" + URLEncoder.encode(type, StandardCharsets.UTF_8);
                response.sendRedirect(url);
                return;
            } else if ("delete".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                boolean ok = eliminar(id);
                String msg = ok ? "Producto eliminado correctamente" : "No se pudo eliminar el producto";
                String type = ok ? "exito" : "error";
                String url = request.getContextPath() + "/GestionarProductosPersonalizacion?msg=" + URLEncoder.encode(msg, StandardCharsets.UTF_8) + "&type=" + URLEncoder.encode(type, StandardCharsets.UTF_8);
                response.sendRedirect(url);
                return;
            }
        } catch (Exception e) {
            String errorMsg = e.getMessage() != null ? e.getMessage() : "Error interno";
            try {
                String url = request.getContextPath() + "/GestionarProductosPersonalizacion?msg=" + URLEncoder.encode(errorMsg, StandardCharsets.UTF_8) + "&type=error";
                response.sendRedirect(url);
            } catch (IOException ioe) {
                throw new ServletException(ioe);
            }
            return;
        }
        try {
            response.sendRedirect("GestionarProductosPersonalizacion");
        } catch (IOException e) {
            throw new ServletException(e);
        }
    }

    // Maneja peticiones GET: muestra listados, formularios y recursos (imagen, detalle) según 'op'.
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String op = request.getParameter("op");
        try {
            if (op == null) {
                List<ProductoPersonalizable> productos = solicitarGestionPersonalizacion();
                agregarNuevoProducto();
                List<SeccionDePersonalizacion> secciones = takeThreadSecciones();
                Map<Integer, List<ProductoPersonalizable>> productosPorSeccion = new HashMap<>();
                for (ProductoPersonalizable p : productos) {
                    if (p.getSeccion() != null && p.getSeccion().getId() != null) {
                        Integer sid = p.getSeccion().getId();
                        productosPorSeccion.computeIfAbsent(sid, k -> new ArrayList<>()).add(p);
                    }
                }
                request.setAttribute("productosPersonalizables", productos);
                request.setAttribute("secciones", secciones);
                request.setAttribute("productosPorSeccion", productosPorSeccion);
                request.getRequestDispatcher("vista/ListaProductosPersonalizables.jsp").forward(request, response);
                return;
            }
            switch (op) {
                case "obtener":
                    int idOb = Integer.parseInt(request.getParameter("id"));
                    ProductoPersonalizable p = ver(idOb);
                    response.setContentType("application/json; charset=utf-8");
                    StringBuilder sb = new StringBuilder();
                    sb.append("{");
                    sb.append("\"id\":").append(p.getId()).append(',');
                    sb.append("\"nombre\":\"").append(escape(p.getNombre())).append("\",");
                    sb.append("\"precio\":").append(p.getPrecio()).append(',');
                    sb.append("\"descripcion\":\"").append(escape(p.getDescripcion())).append("\",");
                    sb.append("\"stock\":").append(p.getStock()).append(',');
                    if (p.getSeccion()!=null) sb.append("\"seccionId\":").append(p.getSeccion().getId()); else sb.append("\"seccionId\":null");
                    sb.append("}");
                    response.getWriter().write(sb.toString());
                    return;
                case "imagen":
                    int idImg = Integer.parseInt(request.getParameter("id"));
                    ProductoPersonalizable prodImg = ver(idImg);
                    if (prodImg != null) {
                        byte[] image = prodImg.getImagen();
                        if (image != null && image.length > 0) {
                            String mime = detectMime(image);
                            if (mime == null) mime = "application/octet-stream";
                            response.setContentType(mime);
                            try (OutputStream os = response.getOutputStream()) {
                                os.write(image);
                            }
                        }
                    }
                    return;
                case "formNuevo":
                    agregarNuevoProducto();
                    List<SeccionDePersonalizacion> seccionesForm = takeThreadSecciones();
                    request.setAttribute("secciones", seccionesForm);
                    request.getRequestDispatcher("/vista/FormularioNuevoPersonalizable.jsp").forward(request, response);
                    return;
                case "formEditar":
                    String idp = request.getParameter("id");
                    if (idp != null) {
                        int id = Integer.parseInt(idp);
                        ProductoPersonalizable prod = editar(id);
                        agregarNuevoProducto();
                        List<SeccionDePersonalizacion> seccionesEdit = takeThreadSecciones();
                        request.setAttribute("producto", prod);
                        request.setAttribute("secciones", seccionesEdit);
                        request.getRequestDispatcher("/vista/FormularioActualizacionPersonalizable.jsp").forward(request, response);
                        return;
                    }
                    response.sendRedirect("GestionarProductosPersonalizacion");
                    return;
                case "formDetalle":
                    String idpd = request.getParameter("id");
                    if (idpd != null) {
                        int id = Integer.parseInt(idpd);
                        ProductoPersonalizable prod = ver(id);
                        request.setAttribute("producto", prod);
                        request.getRequestDispatcher("/vista/DetalleProductoPersonalizable.jsp").forward(request, response);
                        return;
                    }
                    response.sendRedirect("GestionarProductosPersonalizacion");
                    return;
                default:
                    response.sendRedirect("GestionarProductosPersonalizacion");
                    return;
            }
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    // Escapa cadenas para JSON simple (evita romper las comillas y saltos de línea).
    private String escape(String s) {
        if (s==null) return "";
        return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n");
    }

    // Detecta el MIME type básico de una imagen a partir de sus bytes (jpg, png, gif, webp).
    private String detectMime(byte[] bytes) {
        if (bytes == null || bytes.length < 8) return null;
        if ((bytes[0] & 0xFF) == 0xFF && (bytes[1] & 0xFF) == 0xD8 && (bytes[2] & 0xFF) == 0xFF) return "image/jpeg";
        if ((bytes[0] & 0xFF) == 0x89 && (bytes[1] & 0xFF) == 0x50 && (bytes[2] & 0xFF) == 0x4E && (bytes[3] & 0xFF) == 0x47) return "image/png";
        if ((bytes[0] & 0xFF) == 0x47 && (bytes[1] & 0xFF) == 0x49 && (bytes[2] & 0xFF) == 0x46) return "image/gif";
        if ((bytes[0] & 0xFF) == 0x52 && (bytes[1] & 0xFF) == 0x49 && (bytes[2] & 0xFF) == 0x46 && (bytes[8] & 0xFF) == 0x57) return "image/webp";
        return null;
    }

    // Consulta el tamaño máximo permitido por la configuración de MySQL (max_allowed_packet).
    private long getDbMaxAllowedPacket() {
        String sql = "SELECT @@max_allowed_packet AS val";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getLong("val");
        } catch (Exception ignored) {}
        return -1L;
    }
}
