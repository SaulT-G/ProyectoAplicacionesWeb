package controlador;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import dao.UsuarioDAO;
import modelo.entities.Usuario;

/**
 * ========================================================================
 * CONTROLADOR: LoginServlet (Servlet MVC)
 * ========================================================================
 * 
 * Este servlet maneja la autenticación de usuarios en el sistema.
 * Implementa el patrón MVC para login y registro de usuarios.
 * 
 * @author Arquitecto de Software Senior
 * @version 1.0
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private UsuarioDAO usuarioDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        // Inicializar DAO
        usuarioDAO = new UsuarioDAO();
    }

    /**
     * Procesa peticiones GET - Muestra formulario de login
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Redirigir a la página de login
        request.getRequestDispatcher("/vista/login.jsp").forward(request, response);
    }

    /**
     * Procesa peticiones POST - Procesa login de usuario
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Obtener parámetros del formulario
        String correo = request.getParameter("correo");
        String contrasena = request.getParameter("contrasena");
        
        try {
            // Validar que los campos no estén vacíos
            if (correo == null || correo.trim().isEmpty() || 
                contrasena == null || contrasena.trim().isEmpty()) {
                
                request.setAttribute("error", "Debe completar todos los campos");
                request.getRequestDispatcher("/vista/login.jsp").forward(request, response);
                return;
            }
            
            // Validar credenciales con el DAO
            Usuario usuario = usuarioDAO.validarLogin(correo, contrasena);
            
            if (usuario != null) {
                // Login exitoso - Crear sesión
                HttpSession session = request.getSession();
                session.setAttribute("usuario", usuario);
                session.setAttribute("usuarioId", usuario.getIdUsuario());
                session.setAttribute("usuarioNombre", usuario.getNombre());
                session.setAttribute("usuarioRol", usuario.getRol());
                
                // Redirigir según el rol del usuario
                if ("ADMIN".equals(usuario.getRol())) {
                    // Redirigir al panel de administrador
                    response.sendRedirect(request.getContextPath() + "/vista/PanelAdministrador.jsp");
                } else {
                    // Redirigir al panel principal del comprador
                    response.sendRedirect(request.getContextPath() + "/vista/PanelPrincipalComprador.jsp");
                }
                
            } else {
                // Login fallido - Credenciales incorrectas
                request.setAttribute("error", "Correo o contraseña incorrectos");
                request.getRequestDispatcher("/vista/login.jsp").forward(request, response);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error al procesar login: " + e.getMessage());
            request.getRequestDispatcher("/vista/login.jsp").forward(request, response);
        }
    }
}

