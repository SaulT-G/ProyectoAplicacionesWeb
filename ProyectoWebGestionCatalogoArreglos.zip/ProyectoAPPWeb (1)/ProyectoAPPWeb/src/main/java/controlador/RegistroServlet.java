package controlador;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

import dao.UsuarioDAO;
import modelo.entities.Comprador;
import modelo.entities.Usuario;

/**
 * ========================================================================
 * CONTROLADOR: RegistroServlet (Servlet MVC)
 * ========================================================================
 * 
 * Este servlet maneja el registro de nuevos usuarios en el sistema.
 * Permite crear cuentas de comprador.
 * 
 * @author Arquitecto de Software Senior
 * @version 1.0
 */
@WebServlet("/RegistroServlet")
public class RegistroServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private UsuarioDAO usuarioDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        // Inicializar DAO
        usuarioDAO = new UsuarioDAO();
    }

    /**
     * Procesa peticiones GET - Muestra formulario de registro
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Redirigir a la página de registro (Inicio.jsp)
        request.getRequestDispatcher("/vista/Inicio.jsp").forward(request, response);
    }

    /**
     * Procesa peticiones POST - Procesa registro de nuevo usuario
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Obtener parámetros del formulario
        String nombre = request.getParameter("nombre");
        String correo = request.getParameter("correo");
        String contrasena = request.getParameter("contrasena");
        String telefono = request.getParameter("telefono");
        
        try {
            // Validar que los campos obligatorios no estén vacíos
            if (nombre == null || nombre.trim().isEmpty() || 
                correo == null || correo.trim().isEmpty() || 
                contrasena == null || contrasena.trim().isEmpty()) {
                
                request.setAttribute("error", "Debe completar todos los campos obligatorios");
                request.getRequestDispatcher("/vista/Inicio.jsp").forward(request, response);
                return;
            }
            
            // Verificar si el correo ya existe
            Usuario usuarioExistente = usuarioDAO.buscarPorCorreo(correo);
            if (usuarioExistente != null) {
                request.setAttribute("error", "El correo electrónico ya está registrado");
                request.getRequestDispatcher("/vista/Inicio.jsp").forward(request, response);
                return;
            }
            
            // Crear nuevo comprador
            Comprador nuevoComprador = new Comprador(
                nombre,
                correo,
                contrasena,
                telefono,
                "ACTIVO"
            );
            
            // Registrar en la base de datos
            usuarioDAO.registrarComprador(nuevoComprador);
            
            // Registro exitoso - Redirigir al login con mensaje
            request.setAttribute("mensaje", "Registro exitoso. Por favor inicie sesión.");
            request.getRequestDispatcher("/vista/login.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error al registrar usuario: " + e.getMessage());
            request.getRequestDispatcher("/vista/Inicio.jsp").forward(request, response);
        }
    }
}
