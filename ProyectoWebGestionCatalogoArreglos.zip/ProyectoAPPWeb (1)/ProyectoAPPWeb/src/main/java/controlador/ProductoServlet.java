package controlador;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import dao.ProductoDAO;
import modelo.entities.Producto;

/**
 * Servlet implementation class ProductoServlet
 * Maneja la carga de productos y sus imágenes
 */
@WebServlet("/ProductoServlet")
public class ProductoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ProductoDAO dao = new ProductoDAO();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductoServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String op = request.getParameter("op");
		
		// Si se solicita una imagen
		if ("imagen".equals(op)) {
			cargarImagen(request, response);
			return;
		}
		
		// Por defecto, listar productos
		try {
			List<Producto> productos = dao.obtenerListadoDeProductos();
			request.setAttribute("productos", productos);
			request.getRequestDispatcher("/vista/ListaProductos.jsp").forward(request, response);
		} catch (Exception e) {
			throw new ServletException(e);
		}
	}
	
	/**
	 * Método para cargar y mostrar imágenes de productos
	 */
	private void cargarImagen(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			// Obtener ID del producto
			String idParam = request.getParameter("id");
			if (idParam == null) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID de producto no especificado");
				return;
			}
			
			int id = Integer.parseInt(idParam);
			
			// Obtener producto desde la base de datos
			Producto producto = dao.obtenerDatosProducto(id);
			
			if (producto == null || producto.getImagen() == null || producto.getImagen().isEmpty()) {
				// Si no hay producto o no tiene imagen, enviar imagen por defecto
				response.sendError(HttpServletResponse.SC_NOT_FOUND, "Imagen no encontrada");
				return;
			}
			
			// Construir la ruta completa de la imagen
			String imagePath = getServletContext().getRealPath("/vista/imagenes/" + producto.getImagen());
			File imageFile = new File(imagePath);
			
			// Verificar si el archivo existe
			if (!imageFile.exists()) {
				response.sendError(HttpServletResponse.SC_NOT_FOUND, "Archivo de imagen no encontrado");
				return;
			}
			
			// Determinar el tipo MIME de la imagen
			String mimeType = getServletContext().getMimeType(imageFile.getName());
			if (mimeType == null) {
				mimeType = "application/octet-stream";
			}
			
			// Configurar la respuesta
			response.setContentType(mimeType);
			response.setContentLength((int) imageFile.length());
			
			// Leer el archivo y escribirlo en la respuesta
			try (FileInputStream fis = new FileInputStream(imageFile);
			     OutputStream out = response.getOutputStream()) {
				
				byte[] buffer = new byte[4096];
				int bytesRead;
				
				while ((bytesRead = fis.read(buffer)) != -1) {
					out.write(buffer, 0, bytesRead);
				}
			}
			
		} catch (NumberFormatException e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID de producto inválido");
		} catch (Exception e) {
			throw new ServletException("Error al cargar imagen: " + e.getMessage(), e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
