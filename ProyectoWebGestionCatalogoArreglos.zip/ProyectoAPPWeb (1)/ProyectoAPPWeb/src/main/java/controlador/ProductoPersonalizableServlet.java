package controlador;

import dao.ProductoPersonalizableDAO;
import dao.SeccionDePersonalizacionDAO;
import dao.DBUtil;
import modelo.entities.ProductoPersonalizable;
import modelo.entities.SeccionDePersonalizacion;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.List;

@WebServlet(name = "ProductoPersonalizableServlet", urlPatterns = {"/ProductoPersonalizable"})
@MultipartConfig(maxFileSize = 5 * 1024 * 1024) // 5MB
public class ProductoPersonalizableServlet extends HttpServlet {

    private long getDbMaxAllowedPacket() {
        String sql = "SELECT @@max_allowed_packet AS val";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getLong("val");
        } catch (Exception ignored) {}
        return -1L;
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String msg = null;
        String type = "exito";
        try {
            ProductoPersonalizableDAO dao = new ProductoPersonalizableDAO();
            SeccionDePersonalizacionDAO sdao = new SeccionDePersonalizacionDAO();

            if ("create".equals(action)) {
                ProductoPersonalizable p = new ProductoPersonalizable();
                p.setNombre(request.getParameter("nombre"));
                p.setPrecio(Double.parseDouble(request.getParameter("precio")));
                p.setDescripcion(request.getParameter("descripcion"));
                p.setStock(Integer.parseInt(request.getParameter("stock")));
                String seccionId = request.getParameter("seccionId");
                if (seccionId != null && !seccionId.isEmpty()) {
                    SeccionDePersonalizacion s = sdao.obtenerPorId(Integer.parseInt(seccionId));
                    p.setSeccion(s);
                }
                // Handle uploaded image and store bytes in DB (single 'imagen' column)
                Part imagenPart = request.getPart("imagen");
                if (imagenPart != null && imagenPart.getSize() > 0) {
                    long dbMax = getDbMaxAllowedPacket();
                    long partSize = imagenPart.getSize();
                    if (dbMax > 0 && partSize > dbMax) {
                        msg = "El archivo es demasiado grande para la configuración del servidor DB (" + partSize + " bytes > max_allowed_packet=" + dbMax + "). Incrementa 'max_allowed_packet' en MySQL o sube una imagen más pequeña.";
                        type = "error";
                        String url = request.getContextPath() + "/GestionarProductosPersonalizacion?msg=" + URLEncoder.encode(msg, StandardCharsets.UTF_8) + "&type=" + URLEncoder.encode(type, StandardCharsets.UTF_8);
                        response.sendRedirect(url);
                        return;
                    }
                    try (InputStream is = imagenPart.getInputStream()) {
                        byte[] buf = is.readAllBytes();
                        p.setImagen(buf);
                    }
                }
                // Usar método existente del DAO
                dao.guardarPersonalizable(p.getNombre(), p.getSeccion(), p.getPrecio(), p.getStock(), p.getImagen(), p.getDescripcion());
                msg = "Producto creado correctamente";
                type = "exito";
                String url = request.getContextPath() + "/GestionarProductosPersonalizacion?msg=" + URLEncoder.encode(msg, StandardCharsets.UTF_8) + "&type=" + URLEncoder.encode(type, StandardCharsets.UTF_8);
                response.sendRedirect(url);
                return;
            } else if ("update".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                ProductoPersonalizable p = dao.obtenerPersonalizable(id);
                if (p == null) throw new ServletException("Producto no encontrado: " + id);
                p.setNombre(request.getParameter("nombre"));
                p.setPrecio(Double.parseDouble(request.getParameter("precio")));
                p.setDescripcion(request.getParameter("descripcion"));
                p.setStock(Integer.parseInt(request.getParameter("stock")));
                String seccionId = request.getParameter("seccionId");
                if (seccionId != null && !seccionId.isEmpty()) {
                    SeccionDePersonalizacion s = sdao.obtenerPorId(Integer.parseInt(seccionId));
                    p.setSeccion(s);
                } else {
                    p.setSeccion(null);
                }
                Part imagenPart = request.getPart("imagen");
                if (imagenPart != null && imagenPart.getSize() > 0) {
                    long dbMax = getDbMaxAllowedPacket();
                    long partSize = imagenPart.getSize();
                    if (dbMax > 0 && partSize > dbMax) {
                        msg = "El archivo es demasiado grande para la configuración del servidor DB (" + partSize + " bytes > max_allowed_packet=" + dbMax + "). Incrementa 'max_allowed_packet' en MySQL o sube una imagen más pequeña.";
                        type = "error";
                        String url = request.getContextPath() + "/GestionarProductosPersonalizacion?msg=" + URLEncoder.encode(msg, StandardCharsets.UTF_8) + "&type=" + URLEncoder.encode(type, StandardCharsets.UTF_8);
                        response.sendRedirect(url);
                        return;
                    }
                    try (InputStream is = imagenPart.getInputStream()) {
                        byte[] buf = is.readAllBytes();
                        p.setImagen(buf);
                    }
                }
                // Usar método existente del DAO
                dao.actualizarPersonalizable(p.getId(), p.getNombre(), p.getSeccion(), p.getPrecio(), p.getStock(), p.getImagen(), p.getDescripcion());
                msg = "Producto actualizado correctamente";
                type = "exito";
                String url = request.getContextPath() + "/GestionarProductosPersonalizacion?msg=" + URLEncoder.encode(msg, StandardCharsets.UTF_8) + "&type=" + URLEncoder.encode(type, StandardCharsets.UTF_8);
                response.sendRedirect(url);
                return;
            } else if ("delete".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                dao.eliminarPersonalizable(id);
                msg = "Producto eliminado correctamente";
                type = "exito";
                String url = request.getContextPath() + "/GestionarProductosPersonalizacion?msg=" + URLEncoder.encode(msg, StandardCharsets.UTF_8) + "&type=" + URLEncoder.encode(type, StandardCharsets.UTF_8);
                response.sendRedirect(url);
                return;
            }

        } catch (Exception e) {
            // on error, redirect with message
            String errorMsg = e.getMessage() != null ? e.getMessage() : "Error interno";
            String url = request.getContextPath() + "/GestionarProductosPersonalizacion?msg=" + URLEncoder.encode(errorMsg, StandardCharsets.UTF_8) + "&type=error";
            response.sendRedirect(url);
            return;
        }
        response.sendRedirect("GestionarProductosPersonalizacion");
    }

    // Soportar ver por GET (obtener datos JSON simple o servir imagen desde BD blob)
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String op = request.getParameter("op");
        try {
            ProductoPersonalizableDAO dao = new ProductoPersonalizableDAO();
            SeccionDePersonalizacionDAO sdao = new SeccionDePersonalizacionDAO();
            if ("obtener".equals(op)) {
                int id = Integer.parseInt(request.getParameter("id"));
                ProductoPersonalizable p = dao.obtenerPersonalizable(id);
                // devolver simple JSON
                response.setContentType("application/json; charset=utf-8");
                StringBuilder sb = new StringBuilder();
                sb.append("{");
                sb.append("\"id\":").append(p.getId()).append(',');
                sb.append("\"nombre\":\"").append(escape(p.getNombre())).append("\",");
                sb.append("\"precio\":").append(p.getPrecio()).append(',');
                sb.append("\"descripcion\":\"").append(escape(p.getDescripcion())).append("\",");
                sb.append("\"stock\":").append(p.getStock()).append(',');
                if (p.getSeccion()!=null) sb.append("\"seccionId\":").append(p.getSeccion().getId()); else sb.append("\"seccionId\":null");
                sb.append("}");
                response.getWriter().write(sb.toString());
                return;
            } else if ("imagen".equals(op)) {
                int id = Integer.parseInt(request.getParameter("id"));
                ProductoPersonalizable p = dao.obtenerPersonalizable(id);
                if (p!=null) {
                    byte[] img = p.getImagen();
                    if (img != null && img.length > 0) {
                        String mime = detectMime(img);
                        if (mime == null) mime = "application/octet-stream";
                        response.setContentType(mime);
                        try (OutputStream os = response.getOutputStream()) {
                            os.write(img);
                        }
                        return;
                    }
                }
            } else if ("formNuevo".equals(op)) {
                // cargar secciones y forward al JSP del formulario nuevo
                List<SeccionDePersonalizacion> secciones = sdao.obtenerSeccionesPersonalizacion();
                request.setAttribute("secciones", secciones);
                request.getRequestDispatcher("/vista/FormularioNuevoPersonalizable.jsp").forward(request, response);
                return;
            } else if ("formEditar".equals(op)) {
                String idp = request.getParameter("id");
                if (idp != null) {
                    int id = Integer.parseInt(idp);
                    ProductoPersonalizable p = dao.obtenerPersonalizable(id);
                    List<SeccionDePersonalizacion> secciones = sdao.obtenerSeccionesPersonalizacion();
                    request.setAttribute("producto", p);
                    request.setAttribute("secciones", secciones);
                    request.getRequestDispatcher("/vista/FormularioActualizacionPersonalizable.jsp").forward(request, response);
                    return;
                }
            }
            // por defecto redirigir
            response.sendRedirect("GestionarProductosPersonalizacion");
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    private String escape(String s) {
        if (s==null) return "";
        return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n");
    }

    // Simple MIME detection from magic bytes for common image types
    private String detectMime(byte[] bytes) {
        if (bytes == null || bytes.length < 8) return null;
        // JPEG: FF D8 FF
        if ((bytes[0] & 0xFF) == 0xFF && (bytes[1] & 0xFF) == 0xD8 && (bytes[2] & 0xFF) == 0xFF) return "image/jpeg";
        // PNG: 89 50 4E 47 0D 0A 1A 0A
        if ((bytes[0] & 0xFF) == 0x89 && (bytes[1] & 0xFF) == 0x50 && (bytes[2] & 0xFF) == 0x4E && (bytes[3] & 0xFF) == 0x47) return "image/png";
        // GIF: 47 49 46 38
        if ((bytes[0] & 0xFF) == 0x47 && (bytes[1] & 0xFF) == 0x49 && (bytes[2] & 0xFF) == 0x46) return "image/gif";
        // WebP: RIFF....WEBP
        if ((bytes[0] & 0xFF) == 0x52 && (bytes[1] & 0xFF) == 0x49 && (bytes[2] & 0xFF) == 0x46 && (bytes[8] & 0xFF) == 0x57) return "image/webp";
        return null;
    }
}