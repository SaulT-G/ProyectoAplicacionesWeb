package modelo.entities;

import jakarta.persistence.*;
import java.util.List;

/**
 * ========================================================================
 * ENTIDAD: ProductoPersonalizado
 * ========================================================================
 * Representa un producto que el comprador ha personalizado seleccionando
 * opciones de diferentes secciones de personalización.
 * 
 * Relaciones:
 * - ManyToOne con SeccionDePersonalizacion
 * - OneToMany con ProductoPersonalizable (opciones seleccionadas)
 */
@Entity
@Table(name = "producto_personalizado")
public class ProductoPersonalizado {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    
    @ManyToOne
    @JoinColumn(name = "seccion_id")
    private SeccionDePersonalizacion seccion;
    
    @ManyToMany
    @JoinTable(
        name = "producto_personalizado_opciones",
        joinColumns = @JoinColumn(name = "producto_personalizado_id"),
        inverseJoinColumns = @JoinColumn(name = "opcion_id")
    )
    private List<ProductoPersonalizable> opciones;
    
    @Column(name = "precio")
    private Double precio;

    // Constructor vacío (requerido por JPA)
    public ProductoPersonalizado() {
    }

    // Getters y Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public SeccionDePersonalizacion getSeccion() {
        return seccion;
    }

    public void setSeccion(SeccionDePersonalizacion seccion) {
        this.seccion = seccion;
    }

    public List<ProductoPersonalizable> getOpciones() {
        return opciones;
    }

    public void setOpciones(List<ProductoPersonalizable> opciones) {
        this.opciones = opciones;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }
}
