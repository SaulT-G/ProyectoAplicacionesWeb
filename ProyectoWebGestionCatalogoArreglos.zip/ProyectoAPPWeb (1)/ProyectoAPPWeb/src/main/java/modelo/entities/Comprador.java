package modelo.entities;

import jakarta.persistence.*;
import java.io.Serializable;

/**
 * Clase Comprador - Subclase de Usuario según el diagrama de clases
 * Representa el comprador que explora el catálogo
 */
@Entity
@Table(name = "comprador")
@PrimaryKeyJoinColumn(name = "id_usuario")
public class Comprador extends Usuario implements Serializable {
    private static final long serialVersionUID = 1L;

    // Constructores
    public Comprador() {
        super();
    }

    public Comprador(String nombre, String correoElectronico, String contrasena, String telefono, String estado) {
        super(nombre, correoElectronico, contrasena, telefono, estado, "COMPRADOR");
    }

    @Override
    public String toString() {
        return "Comprador{" +
                "idUsuario=" + getIdUsuario() +
                ", nombre='" + getNombre() + '\'' +
                ", correoElectronico='" + getCorreoElectronico() + '\'' +
                ", telefono='" + getTelefono() + '\'' +
                ", estado='" + getEstado() + '\'' +
                '}';
    }
}
