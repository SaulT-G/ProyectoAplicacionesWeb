package modelo.conection;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * ========================================================================
 * CLASE: PersistenciaBDD (Patrón Singleton)
 * ========================================================================
 * 
 * Esta clase implementa el patrón Singleton para gestionar la conexión
 * con la base de datos a través de JPA/Hibernate.
 * 
 * PATRÓN SINGLETON:
 * - Garantiza que solo exista UNA instancia de EntityManagerFactory
 * - Proporciona un punto de acceso global a través de getInstance()
 * - Gestiona eficientemente los recursos de conexión a la BD
 * 
 * VENTAJAS:
 * ✓ Una sola conexión al pool de base de datos
 * ✓ Recursos compartidos eficientemente
 * ✓ Fácil acceso desde cualquier clase (DAO, Servlet, etc.)
 * ✓ Cierre controlado de conexiones
 * 
 * USO:
 * EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
 * 
 * @author Arquitecto de Software
 * @version 1.0
 */
public class PersistenciaBDD {
    
    // ═════════════════════════════════════════════════════════════════════
    // ATRIBUTOS DEL SINGLETON
    // ═════════════════════════════════════════════════════════════════════
    
    /**
     * Instancia única de la clase (Singleton)
     * volatile: Garantiza visibilidad entre hilos (thread-safe)
     */
    private static volatile PersistenciaBDD instancia;
    
    /**
     * EntityManagerFactory: Fábrica de EntityManagers
     * Es thread-safe y costoso de crear, por eso se crea una sola vez
     */
    private EntityManagerFactory emf;
    
    /**
     * Nombre de la unidad de persistencia definida en persistence.xml
     */
    private static final String PERSISTENCE_UNIT = "EncantoEA_PU";
    
    // ═════════════════════════════════════════════════════════════════════
    // CONSTRUCTOR PRIVADO (Patrón Singleton)
    // ═════════════════════════════════════════════════════════════════════
    
    /**
     * Constructor privado para evitar instanciación externa.
     * Solo se puede crear una instancia a través de getInstance()
     */
    private PersistenciaBDD() {
        try {
            // Crear EntityManagerFactory leyendo configuración de persistence.xml
            // Esto establece el pool de conexiones a MySQL
            this.emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT);
            
            System.out.println("✅ PersistenciaBDD: EntityManagerFactory creado exitosamente");
            System.out.println("📊 Conectado a MySQL: localhost:3306/encantoea");
            
        } catch (Exception e) {
            System.err.println("❌ Error al crear EntityManagerFactory: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("No se pudo inicializar la conexión a la base de datos", e);
        }
    }
    
    // ═════════════════════════════════════════════════════════════════════
    // MÉTODO getInstance() - Patrón Singleton con Double-Checked Locking
    // ═════════════════════════════════════════════════════════════════════
    
    /**
     * Obtiene la instancia única de PersistenciaBDD (Singleton)
     * 
     * Implementa Double-Checked Locking para thread-safety:
     * - Primera verificación: Evita sincronización innecesaria
     * - Bloque synchronized: Garantiza que solo un hilo cree la instancia
     * - Segunda verificación: Dentro del bloque sincronizado
     * 
     * @return Instancia única de PersistenciaBDD
     */
    public static PersistenciaBDD getInstance() {
        // Primera verificación (sin sincronización)
        if (instancia == null) {
            // Sincronizar solo si la instancia no existe
            synchronized (PersistenciaBDD.class) {
                // Segunda verificación (con sincronización)
                if (instancia == null) {
                    instancia = new PersistenciaBDD();
                }
            }
        }
        return instancia;
    }
    
    // ═════════════════════════════════════════════════════════════════════
    // MÉTODO getEntityManager() - Obtener conexión a la BD
    // ═════════════════════════════════════════════════════════════════════
    
    /**
     * Obtiene un EntityManager para realizar operaciones en la BD
     * 
     * IMPORTANTE: 
     * - Cada EntityManager debe cerrarse después de usarse (em.close())
     * - No compartir EntityManager entre hilos
     * - Usar en bloque try-finally para garantizar cierre
     * 
     * Ejemplo de uso:
     * <pre>
     * EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
     * try {
     *     // Operaciones con la BD
     *     List<Producto> productos = em.createQuery("...", Producto.class).getResultList();
     * } finally {
     *     em.close();
     * }
     * </pre>
     * 
     * @return EntityManager nuevo para operaciones con la BD
     * @throws IllegalStateException si el EntityManagerFactory está cerrado
     */
    public EntityManager getEntityManager() {
        if (emf == null || !emf.isOpen()) {
            throw new IllegalStateException("EntityManagerFactory no está disponible");
        }
        return emf.createEntityManager();
    }
    
    // ═════════════════════════════════════════════════════════════════════
    // MÉTODO close() - Cerrar conexión al finalizar aplicación
    // ═════════════════════════════════════════════════════════════════════
    
    /**
     * Cierra el EntityManagerFactory y libera recursos
     * 
     * Este método debe llamarse al finalizar la aplicación
     * (por ejemplo, en ServletContextListener)
     * 
     * Una vez cerrado, no se pueden crear más EntityManagers
     */
    public void close() {
        if (emf != null && emf.isOpen()) {
            emf.close();
            System.out.println("🔒 PersistenciaBDD: EntityManagerFactory cerrado");
        }
    }
    
    // ═════════════════════════════════════════════════════════════════════
    // MÉTODO isOpen() - Verificar estado de la conexión
    // ═════════════════════════════════════════════════════════════════════
    
    /**
     * Verifica si el EntityManagerFactory está abierto y disponible
     * 
     * @return true si está abierto, false si está cerrado
     */
    public boolean isOpen() {
        return emf != null && emf.isOpen();
    }
    
    // ═════════════════════════════════════════════════════════════════════
    // INFORMACIÓN DE LA CONEXIÓN
    // ═════════════════════════════════════════════════════════════════════
    
    /**
     * Obtiene información sobre la configuración de la conexión
     * Útil para debugging
     * 
     * @return String con información de la conexión
     */
    public String getInfo() {
        StringBuilder info = new StringBuilder();
        info.append("=== INFORMACIÓN DE PERSISTENCIABDD ===\n");
        info.append("Unidad de Persistencia: ").append(PERSISTENCE_UNIT).append("\n");
        info.append("Estado EntityManagerFactory: ").append(isOpen() ? "ABIERTO" : "CERRADO").append("\n");
        info.append("Base de Datos: MySQL\n");
        info.append("URL: jdbc:mysql://localhost:3306/encantoea\n");
        info.append("Proveedor JPA: Hibernate\n");
        return info.toString();
    }
    
    /**
     * Imprime información de la conexión en consola
     */
    public void printInfo() {
        System.out.println(getInfo());
    }
}
