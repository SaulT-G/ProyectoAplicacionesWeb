package dao;

/**
 * Clase de prueba para verificar conexión a BD y EntityManagerFactory
 * Ejecutar antes de desplegar en Tomcat
 */
public class TestConexion {
    
    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("PRUEBA DE CONEXIÓN BD Y JPA");
        System.out.println("========================================\n");
        
        try {
            // Test 1: Verificar que persistence.xml se puede leer
            System.out.println("1. Buscando persistence.xml...");
            var stream = TestConexion.class.getResourceAsStream("/META-INF/persistence.xml");
            if (stream != null) {
                System.out.println("   ✓ persistence.xml encontrado");
                stream.close();
            } else {
                System.out.println("   ❌ persistence.xml NO encontrado");
                return;
            }
            
            // Test 2: Crear EntityManagerFactory
            System.out.println("\n2. Creando EntityManagerFactory...");
            var em = JPAUtil.getEntityManager();
            System.out.println("   ✓ EntityManager creado exitosamente");
            
            // Test 3: Probar conexión
            System.out.println("\n3. Probando conexión a BD...");
            em.getTransaction().begin();
            em.createNativeQuery("SELECT 1").getSingleResult();
            em.getTransaction().commit();
            System.out.println("   ✓ Conexión a MySQL exitosa");
            
            em.close();
            
            System.out.println("\n========================================");
            System.out.println("✓ TODAS LAS PRUEBAS PASARON");
            System.out.println("========================================");
            System.out.println("\nAhora puedes desplegar en Tomcat sin errores.");
            
        } catch (Exception e) {
            System.err.println("\n========================================");
            System.err.println("❌ ERROR EN PRUEBAS");
            System.err.println("========================================");
            System.err.println("\nMensaje: " + e.getMessage());
            e.printStackTrace();
            
            System.err.println("\n=== SOLUCIONES POSIBLES ===");
            System.err.println("1. Verifica que MySQL esté corriendo");
            System.err.println("2. Verifica usuario/password en persistence.xml");
            System.err.println("3. Ejecuta: mysql -u root -p");
            System.err.println("4. Crea la BD: CREATE DATABASE encantoea;");
        } finally {
            JPAUtil.close();
        }
    }
}
