package dao;

import modelo.entities.ProductoPersonalizable;
import modelo.entities.SeccionDePersonalizacion;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

import java.util.List;

public class ProductoPersonalizableDAO {

    // ----------------- Métodos públicos (implementados con JPA) -----------------

    // Devuelve la lista completa de productos personalizables ordenada por id.
    public List<ProductoPersonalizable> obtenerProductosPersonalizables() throws Exception {
        EntityManager em = null;
        try {
            em = JPAUtil.getEntityManager();
            TypedQuery<ProductoPersonalizable> q = em.createQuery("SELECT p FROM ProductoPersonalizable p ORDER BY p.id", ProductoPersonalizable.class);
            return q.getResultList();
        } finally {
            if (em != null) em.close();
        }
    }

    // Crea y persiste un nuevo producto personalizable con sus atributos y sección.
    public boolean guardarPersonalizable(String nombre, SeccionDePersonalizacion seccion, double prec, int stock, byte[] img, String desc) throws Exception {
        EntityManager em = null;
        try {
            em = JPAUtil.getEntityManager();
            em.getTransaction().begin();
            ProductoPersonalizable p = new ProductoPersonalizable();
            p.setNombre(nombre);
            p.setPrecio(prec);
            p.setDescripcion(desc);
            p.setStock(stock);
            p.setImagen(img);
            if (seccion != null && seccion.getId() != null) {
                SeccionDePersonalizacion sManaged = em.find(SeccionDePersonalizacion.class, seccion.getId());
                p.setSeccion(sManaged);
            } else {
                p.setSeccion(null);
            }
            em.persist(p);
            em.getTransaction().commit();
            return p.getId() != null;
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) em.getTransaction().rollback();
            throw e;
        } finally {
            if (em != null) em.close();
        }
    }

    // Actualiza los datos de un producto existente identificado por su id.
    public boolean actualizarPersonalizable(int id, String nombre, SeccionDePersonalizacion seccion, double prec, int stock, byte[] img, String desc) throws Exception {
        EntityManager em = null;
        try {
            em = JPAUtil.getEntityManager();
            em.getTransaction().begin();
            ProductoPersonalizable p = em.find(ProductoPersonalizable.class, id);
            if (p == null) {
                em.getTransaction().rollback();
                return false;
            }
            p.setNombre(nombre);
            p.setPrecio(prec);
            p.setDescripcion(desc);
            p.setStock(stock);
            if (img != null) p.setImagen(img);
            if (seccion != null && seccion.getId() != null) {
                SeccionDePersonalizacion sManaged = em.find(SeccionDePersonalizacion.class, seccion.getId());
                p.setSeccion(sManaged);
            } else {
                p.setSeccion(null);
            }
            em.merge(p);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) em.getTransaction().rollback();
            throw e;
        } finally {
            if (em != null) em.close();
        }
    }

    // Elimina un producto personalizable por su id.
    public boolean eliminarPersonalizable(int id) throws Exception {
        EntityManager em = null;
        try {
            em = JPAUtil.getEntityManager();
            em.getTransaction().begin();
            ProductoPersonalizable p = em.find(ProductoPersonalizable.class, id);
            if (p == null) {
                em.getTransaction().rollback();
                return false;
            }
            em.remove(p);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) em.getTransaction().rollback();
            throw e;
        } finally {
            if (em != null) em.close();
        }
    }

    // Recupera un producto por su id o retorna null si no existe.
    public ProductoPersonalizable obtenerPersonalizable(int id) throws Exception {
        EntityManager em = null;
        try {
            em = JPAUtil.getEntityManager();
            return em.find(ProductoPersonalizable.class, id);
        } finally {
            if (em != null) em.close();
        }
    }
}