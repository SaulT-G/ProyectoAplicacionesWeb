package dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;
import modelo.entities.Categoria;

/**
 * CategoriaDAO - Métodos según diagrama de robustez
 * Solo contiene el método obtenerCategorias
 */
public class CategoriaDAO {

    /**
     * MÉTODO DEL DIAGRAMA: obtenerCategorias
     * Obtiene todas las categorías disponibles
     */
    public List<Categoria> obtenerCategorias() {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            TypedQuery<Categoria> query = em.createQuery("SELECT c FROM Categoria c ORDER BY c.nombre", Categoria.class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }
}
