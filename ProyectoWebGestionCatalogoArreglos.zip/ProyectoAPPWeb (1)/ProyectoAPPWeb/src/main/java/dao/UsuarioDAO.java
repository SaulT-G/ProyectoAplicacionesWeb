package dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;

import modelo.entities.Usuario;
import modelo.entities.Comprador;
import modelo.conection.PersistenciaBDD;

/**
 * UsuarioDAO - Data Access Object para gestionar usuarios y compradores
 * Implementa operaciones de login, registro y búsqueda según los diagramas
 */
public class UsuarioDAO {

    /**
     * Método para validar login de usuario
     * Busca usuario por correo y verifica contraseña
     * @param correo Correo electrónico del usuario
     * @param contrasena Contraseña del usuario
     * @return Usuario si las credenciales son válidas, null si no
     */
    public Usuario validarLogin(String correo, String contrasena) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        try {
            TypedQuery<Usuario> query = em.createQuery(
                "SELECT u FROM Usuario u WHERE u.correoElectronico = :correo AND u.contrasena = :contrasena", 
                Usuario.class
            );
            query.setParameter("correo", correo);
            query.setParameter("contrasena", contrasena);
            
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            em.close();
        }
    }

    /**
     * Método para registrar un nuevo usuario
     * @param usuario Usuario a registrar
     * @throws RuntimeException si hay error al guardar
     */
    public void registrar(Usuario usuario) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            em.persist(usuario);
            tx.commit();
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            throw new RuntimeException("Error al registrar usuario: " + e.getMessage(), e);
        } finally {
            em.close();
        }
    }

    /**
     * Método para buscar usuario por correo electrónico
     * @param correo Correo electrónico
     * @return Usuario encontrado o null
     */
    public Usuario buscarPorCorreo(String correo) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        try {
            TypedQuery<Usuario> query = em.createQuery(
                "SELECT u FROM Usuario u WHERE u.correoElectronico = :correo", 
                Usuario.class
            );
            query.setParameter("correo", correo);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            em.close();
        }
    }

    /**
     * Método para buscar usuario por ID
     * @param id ID del usuario
     * @return Usuario encontrado o null
     */
    public Usuario buscarPorId(Integer id) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        try {
            return em.find(Usuario.class, id);
        } finally {
            em.close();
        }
    }

    /**
     * Método para registrar un comprador
     * @param comprador Comprador a registrar
     */
    public void registrarComprador(Comprador comprador) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            em.persist(comprador);
            tx.commit();
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            throw new RuntimeException("Error al registrar comprador: " + e.getMessage(), e);
        } finally {
            em.close();
        }
    }
}
