package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import modelo.entities.ProductoPersonalizable;
import modelo.entities.SeccionDePersonalizacion;

public class TestConexionProductosPersonalizables {
    public static void main(String[] args) {
        System.out.println("=== PRUEBA DE CONEXIÓN Y DATOS ===");
        System.out.println();
        
        try {
            // Probar conexión
            System.out.println("1. Probando conexión a MySQL...");
            Connection conn = DBUtil.getConnection();
            System.out.println("✓ Conexión exitosa!");
            System.out.println("   Database: " + conn.getCatalog());
            System.out.println();
            
            // Verificar tabla seccion_personalizacion
            System.out.println("2. Verificando tabla 'seccion_personalizacion'...");
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as total FROM seccion_personalizacion");
            if (rs.next()) {
                int total = rs.getInt("total");
                System.out.println("✓ Tabla existe. Total secciones: " + total);
                
                if (total == 0) {
                    System.out.println("⚠ WARNING: No hay secciones en la base de datos!");
                    System.out.println("   Ejecuta: src/main/resources/database/crear_productos_personalizables.sql");
                } else {
                    // Mostrar secciones
                    rs = stmt.executeQuery("SELECT id, nombre, descripcion FROM seccion_personalizacion");
                    System.out.println("\n   Secciones encontradas:");
                    while (rs.next()) {
                        System.out.println("   - ID: " + rs.getInt("id") + 
                                         " | Nombre: " + rs.getString("nombre") +
                                         " | Descripción: " + rs.getString("descripcion"));
                    }
                }
            }
            System.out.println();
            
            // Verificar tabla producto_personalizable
            System.out.println("3. Verificando tabla 'producto_personalizable'...");
            rs = stmt.executeQuery("SELECT COUNT(*) as total FROM producto_personalizable");
            int totalProductos = 0;
            if (rs.next()) {
                totalProductos = rs.getInt("total");
                System.out.println("✓ Tabla existe. Total productos: " + totalProductos);
                
                if (totalProductos == 0) {
                    System.out.println("⚠ WARNING: No hay productos personalizables en la base de datos!");
                    System.out.println("   Debes insertar datos manualmente o ejecutar un script SQL.");
                } else {
                    // Mostrar productos
                    rs = stmt.executeQuery("SELECT p.id, p.nombre, p.precio, p.stock, s.nombre as seccion " +
                                          "FROM producto_personalizable p " +
                                          "LEFT JOIN seccion_personalizacion s ON p.seccion_id = s.id");
                    System.out.println("\n   Productos encontrados:");
                    while (rs.next()) {
                        System.out.println("   - ID: " + rs.getInt("id") + 
                                         " | Nombre: " + rs.getString("nombre") +
                                         " | Precio: $" + rs.getDouble("precio") +
                                         " | Stock: " + rs.getInt("stock") +
                                         " | Sección: " + rs.getString("seccion"));
                    }
                }
            }
            System.out.println();
            
            // Probar DAO
            System.out.println("4. Probando ProductoPersonalizableDAO...");
            ProductoPersonalizableDAO dao = new ProductoPersonalizableDAO();
            List<ProductoPersonalizable> productos = dao.obtenerProductosPersonalizables();
            System.out.println("✓ DAO funciona correctamente");
            System.out.println("   Productos recuperados por DAO: " + productos.size());
            
            if (productos.isEmpty()) {
                System.out.println("⚠ El DAO no retorna productos. Verifica la consulta SQL.");
            } else {
                System.out.println("\n   Productos del DAO:");
                for (ProductoPersonalizable p : productos) {
                    System.out.println("   - " + p.getNombre() + 
                                     " ($" + p.getPrecio() + 
                                     ") - Sección: " + (p.getSeccion() != null ? p.getSeccion().getNombre() : "Sin sección"));
                }
            }
            System.out.println();
            
            // Probar SeccionDePersonalizacionDAO
            System.out.println("5. Probando SeccionDePersonalizacionDAO...");
            SeccionDePersonalizacionDAO sdao = new SeccionDePersonalizacionDAO();
            List<SeccionDePersonalizacion> secciones = sdao.obtenerSeccionesPersonalizacion();
            System.out.println("✓ SeccionDePersonalizacionDAO funciona correctamente");
            System.out.println("   Secciones recuperadas: " + secciones.size());
            System.out.println();
            
            System.out.println("=== PRUEBA COMPLETADA ===");
            System.out.println();
            
            // Resumen
            if (productos.isEmpty() && totalProductos > 0) {
                System.out.println("❌ PROBLEMA DETECTADO:");
                System.out.println("   - Hay productos en la BD pero el DAO no los recupera");
                System.out.println("   - Revisa la consulta SQL en ProductoPersonalizableDAO.listar()");
            } else if (productos.isEmpty()) {
                System.out.println("⚠ ACCIÓN REQUERIDA:");
                System.out.println("   - No hay productos en la base de datos");
                System.out.println("   - Ejecuta el script: crear_productos_personalizables.sql");
                System.out.println("   - O inserta productos manualmente desde la aplicación");
            } else {
                System.out.println("✓ TODO CORRECTO:");
                System.out.println("   - Conexión OK");
                System.out.println("   - Tablas OK");
                System.out.println("   - Datos OK");
                System.out.println("   - DAOs OK");
            }
            
            conn.close();
            
        } catch (Exception e) {
            System.out.println("❌ ERROR:");
            System.out.println("   " + e.getMessage());
            e.printStackTrace();
        }
    }
}
