-- ============================================================================
-- SCRIPT SQL - MÓDULO PROCESAR COMPRA
-- ============================================================================
-- Descripción: Crea las tablas necesarias para el módulo de Procesar Compra
-- Fecha: 2026-01-19
-- Base de datos: MySQL 8.x
-- Charset: utf8mb4
-- ============================================================================

-- Crear tabla pago_transferencia
CREATE TABLE IF NOT EXISTS pago_transferencia (
    id_pago INT AUTO_INCREMENT PRIMARY KEY,
    monto DOUBLE NOT NULL,
    fecha_pago TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    banco VARCHAR(100),
    titular VARCHAR(150),
    numero_cuenta VARCHAR(50),
    tipo_cuenta VARCHAR(50),
    ruc VARCHAR(13),
    estado VARCHAR(50) DEFAULT 'PENDIENTE',
    id_pedido INT,
    CONSTRAINT fk_pago_pedido FOREIGN KEY (id_pedido) REFERENCES pedido(id_pedido) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_pago_estado (estado),
    INDEX idx_pago_fecha (fecha_pago)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Crear tabla comprobante_pago
CREATE TABLE IF NOT EXISTS comprobante_pago (
    id_comprobante INT AUTO_INCREMENT PRIMARY KEY,
    nombre_comprador VARCHAR(150),
    numero_comprobante VARCHAR(50),
    fecha_emision TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    imagen LONGBLOB,
    nombre_archivo VARCHAR(255),
    tipo_mime VARCHAR(100),
    id_pago INT,
    CONSTRAINT fk_comprobante_pago FOREIGN KEY (id_pago) REFERENCES pago_transferencia(id_pago) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_comprobante_numero (numero_comprobante),
    INDEX idx_comprobante_fecha (fecha_emision)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- COMENTARIOS DE TABLAS Y COLUMNAS
-- ============================================================================

-- Comentarios para pago_transferencia
ALTER TABLE pago_transferencia 
    COMMENT = 'Almacena información de pagos por transferencia bancaria';

ALTER TABLE pago_transferencia 
    MODIFY COLUMN id_pago INT AUTO_INCREMENT COMMENT 'ID único del pago',
    MODIFY COLUMN monto DOUBLE NOT NULL COMMENT 'Monto total del pago',
    MODIFY COLUMN fecha_pago TIMESTAMP NOT NULL COMMENT 'Fecha y hora del pago',
    MODIFY COLUMN banco VARCHAR(100) COMMENT 'Nombre del banco origen',
    MODIFY COLUMN titular VARCHAR(150) COMMENT 'Nombre del titular de la cuenta',
    MODIFY COLUMN numero_cuenta VARCHAR(50) COMMENT 'Número de cuenta bancaria',
    MODIFY COLUMN tipo_cuenta VARCHAR(50) COMMENT 'Tipo: Ahorros o Corriente',
    MODIFY COLUMN ruc VARCHAR(13) COMMENT 'RUC o Cédula del titular',
    MODIFY COLUMN estado VARCHAR(50) COMMENT 'PENDIENTE, CONFIRMADO, APROBADO, RECHAZADO',
    MODIFY COLUMN id_pedido INT COMMENT 'Referencia al pedido asociado';

-- Comentarios para comprobante_pago
ALTER TABLE comprobante_pago 
    COMMENT = 'Almacena los comprobantes de pago adjuntados por los compradores';

ALTER TABLE comprobante_pago 
    MODIFY COLUMN id_comprobante INT AUTO_INCREMENT COMMENT 'ID único del comprobante',
    MODIFY COLUMN nombre_comprador VARCHAR(150) COMMENT 'Nombre del comprador',
    MODIFY COLUMN numero_comprobante VARCHAR(50) COMMENT 'Número del voucher/comprobante',
    MODIFY COLUMN fecha_emision TIMESTAMP NOT NULL COMMENT 'Fecha de emisión del comprobante',
    MODIFY COLUMN imagen LONGBLOB COMMENT 'Imagen del comprobante en bytes',
    MODIFY COLUMN nombre_archivo VARCHAR(255) COMMENT 'Nombre del archivo original',
    MODIFY COLUMN tipo_mime VARCHAR(100) COMMENT 'Tipo MIME (image/jpeg, image/png, etc.)',
    MODIFY COLUMN id_pago INT COMMENT 'Referencia al pago asociado';

-- ============================================================================
-- DATOS DE PRUEBA (OPCIONAL)
-- ============================================================================

-- Insertar un pago de prueba (requiere que exista un pedido)
-- INSERT INTO pago_transferencia (monto, banco, titular, numero_cuenta, tipo_cuenta, ruc, estado, id_pedido)
-- VALUES (150.00, 'Banco Pichincha', 'Juan Pérez', '2100123456', 'Ahorros', '1234567890001', 'PENDIENTE', 1);

-- Insertar un comprobante de prueba (requiere que exista un pago)
-- INSERT INTO comprobante_pago (nombre_comprador, numero_comprobante, nombre_archivo, tipo_mime, id_pago)
-- VALUES ('Juan Pérez', 'COMP-2026-001', 'comprobante.jpg', 'image/jpeg', 1);

-- ============================================================================
-- CONSULTAS ÚTILES
-- ============================================================================

-- Ver todos los pagos pendientes
-- SELECT p.*, ped.numero_pedido, ped.total 
-- FROM pago_transferencia p
-- INNER JOIN pedido ped ON p.id_pedido = ped.id_pedido
-- WHERE p.estado = 'PENDIENTE'
-- ORDER BY p.fecha_pago DESC;

-- Ver comprobantes con sus pagos
-- SELECT c.*, p.banco, p.monto, p.estado
-- FROM comprobante_pago c
-- INNER JOIN pago_transferencia p ON c.id_pago = p.id_pago
-- ORDER BY c.fecha_emision DESC;

-- Actualizar estado de un pago
-- UPDATE pago_transferencia 
-- SET estado = 'APROBADO' 
-- WHERE id_pago = 1;

-- Contar pagos por estado
-- SELECT estado, COUNT(*) as total
-- FROM pago_transferencia
-- GROUP BY estado;

-- ============================================================================
-- PROCEDIMIENTOS ALMACENADOS (OPCIONAL)
-- ============================================================================

DELIMITER //

-- Procedimiento para aprobar un pago
CREATE PROCEDURE IF NOT EXISTS sp_aprobar_pago(IN p_id_pago INT)
BEGIN
    DECLARE v_id_pedido INT;
    
    -- Obtener el ID del pedido
    SELECT id_pedido INTO v_id_pedido 
    FROM pago_transferencia 
    WHERE id_pago = p_id_pago;
    
    -- Actualizar estado del pago
    UPDATE pago_transferencia 
    SET estado = 'APROBADO' 
    WHERE id_pago = p_id_pago;
    
    -- Actualizar estado del pedido
    UPDATE pedido 
    SET estado = 'PAGO_APROBADO' 
    WHERE id_pedido = v_id_pedido;
    
    SELECT 'Pago aprobado exitosamente' AS mensaje;
END //

-- Procedimiento para rechazar un pago
CREATE PROCEDURE IF NOT EXISTS sp_rechazar_pago(IN p_id_pago INT)
BEGIN
    DECLARE v_id_pedido INT;
    
    -- Obtener el ID del pedido
    SELECT id_pedido INTO v_id_pedido 
    FROM pago_transferencia 
    WHERE id_pago = p_id_pago;
    
    -- Actualizar estado del pago
    UPDATE pago_transferencia 
    SET estado = 'RECHAZADO' 
    WHERE id_pago = p_id_pago;
    
    -- Actualizar estado del pedido
    UPDATE pedido 
    SET estado = 'PAGO_RECHAZADO' 
    WHERE id_pedido = v_id_pedido;
    
    SELECT 'Pago rechazado' AS mensaje;
END //

DELIMITER ;

-- ============================================================================
-- VISTAS ÚTILES
-- ============================================================================

-- Vista de pagos con información completa
CREATE OR REPLACE VIEW v_pagos_completos AS
SELECT 
    p.id_pago,
    p.monto,
    p.fecha_pago,
    p.banco,
    p.titular,
    p.numero_cuenta,
    p.tipo_cuenta,
    p.ruc,
    p.estado AS estado_pago,
    ped.id_pedido,
    ped.numero_pedido,
    ped.total AS total_pedido,
    ped.estado AS estado_pedido,
    comp.nombre_comprador,
    comp.numero_comprobante,
    comp.fecha_emision,
    CASE 
        WHEN comp.imagen IS NOT NULL THEN 'Sí'
        ELSE 'No'
    END AS tiene_comprobante
FROM pago_transferencia p
INNER JOIN pedido ped ON p.id_pedido = ped.id_pedido
LEFT JOIN comprobante_pago comp ON p.id_pago = comp.id_pago;

-- Vista de pagos pendientes de revisión
CREATE OR REPLACE VIEW v_pagos_pendientes AS
SELECT 
    p.id_pago,
    p.monto,
    p.fecha_pago,
    p.banco,
    p.titular,
    ped.numero_pedido,
    comp.numero_comprobante,
    TIMESTAMPDIFF(HOUR, p.fecha_pago, NOW()) AS horas_pendiente
FROM pago_transferencia p
INNER JOIN pedido ped ON p.id_pedido = ped.id_pedido
LEFT JOIN comprobante_pago comp ON p.id_pago = comp.id_pago
WHERE p.estado = 'PENDIENTE'
ORDER BY p.fecha_pago ASC;

-- ============================================================================
-- TRIGGERS (OPCIONAL)
-- ============================================================================

-- Trigger para actualizar automáticamente la fecha de pago
DELIMITER //

CREATE TRIGGER IF NOT EXISTS trg_pago_before_insert
BEFORE INSERT ON pago_transferencia
FOR EACH ROW
BEGIN
    IF NEW.fecha_pago IS NULL THEN
        SET NEW.fecha_pago = NOW();
    END IF;
    
    IF NEW.estado IS NULL THEN
        SET NEW.estado = 'PENDIENTE';
    END IF;
END //

-- Trigger para log de cambios de estado
CREATE TRIGGER IF NOT EXISTS trg_pago_after_update
AFTER UPDATE ON pago_transferencia
FOR EACH ROW
BEGIN
    IF OLD.estado != NEW.estado THEN
        -- Aquí podrías insertar en una tabla de log
        -- INSERT INTO log_cambios_pago (id_pago, estado_anterior, estado_nuevo, fecha_cambio)
        -- VALUES (NEW.id_pago, OLD.estado, NEW.estado, NOW());
        SELECT CONCAT('Estado actualizado de ', OLD.estado, ' a ', NEW.estado) AS log_info;
    END IF;
END //

DELIMITER ;

-- ============================================================================
-- ÍNDICES ADICIONALES PARA OPTIMIZACIÓN
-- ============================================================================

-- Índice para búsquedas por comprador
CREATE INDEX idx_comprobante_comprador ON comprobante_pago(nombre_comprador);

-- Índice para búsquedas por banco
CREATE INDEX idx_pago_banco ON pago_transferencia(banco);

-- Índice compuesto para búsquedas frecuentes
CREATE INDEX idx_pago_estado_fecha ON pago_transferencia(estado, fecha_pago);

-- ============================================================================
-- PERMISOS (AJUSTAR SEGÚN TU USUARIO)
-- ============================================================================

-- Asegurarse de que el usuario de la aplicación tenga los permisos necesarios
-- GRANT SELECT, INSERT, UPDATE ON pago_transferencia TO 'usuario_app'@'localhost';
-- GRANT SELECT, INSERT, UPDATE ON comprobante_pago TO 'usuario_app'@'localhost';

-- ============================================================================
-- VERIFICACIÓN DE INSTALACIÓN
-- ============================================================================

-- Verificar que las tablas se crearon correctamente
SELECT 
    TABLE_NAME,
    ENGINE,
    TABLE_ROWS,
    CREATE_TIME
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
AND TABLE_NAME IN ('pago_transferencia', 'comprobante_pago');

-- Verificar las foreign keys
SELECT 
    CONSTRAINT_NAME,
    TABLE_NAME,
    COLUMN_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM information_schema.KEY_COLUMN_USAGE
WHERE TABLE_SCHEMA = DATABASE()
AND TABLE_NAME IN ('pago_transferencia', 'comprobante_pago')
AND REFERENCED_TABLE_NAME IS NOT NULL;

-- ============================================================================
-- LIMPIEZA (SOLO SI NECESITAS REINSTALAR)
-- ============================================================================

-- ¡CUIDADO! Esto eliminará todas las tablas y datos
-- DROP VIEW IF EXISTS v_pagos_completos;
-- DROP VIEW IF EXISTS v_pagos_pendientes;
-- DROP PROCEDURE IF EXISTS sp_aprobar_pago;
-- DROP PROCEDURE IF EXISTS sp_rechazar_pago;
-- DROP TABLE IF EXISTS comprobante_pago;
-- DROP TABLE IF EXISTS pago_transferencia;

-- ============================================================================
-- FIN DEL SCRIPT
-- ============================================================================

-- Confirmar que todo se ejecutó correctamente
SELECT 'Script ejecutado exitosamente. Tablas creadas.' AS resultado;
