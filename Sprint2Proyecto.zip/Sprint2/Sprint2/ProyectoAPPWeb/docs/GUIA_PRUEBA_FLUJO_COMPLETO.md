# ⚡ GUÍA RÁPIDA - PRUEBA DEL FLUJO INTEGRADO

## 🎯 CÓMO PROBAR EL FLUJO COMPLETO

### **PASO 1: Preparación**
```
✓ Iniciar sesión como comprador
✓ Tener productos en el catálogo
✓ Configurar servidor SMTP (ya está configurado)
```

---

### **PASO 2: Agregar al Carrito**
1. Ve a: `/ControladorCatalogo?accion=explorar`
2. Selecciona productos
3. Agrégalos al carrito
4. Ve a: `/GestionarCarrito?action=acceder`
5. **Haz clic en "Procesar Pedido"**

**Resultado esperado:**
- ✅ Redirige a `/ProcesarPedido?action=solicitarProcesarPedido`
- ✅ Muestra `FormularioDatosEntrega.jsp`

---

### **PASO 3: Datos de Entrega**
1. Completa el formulario:
   ```
   Nombre: Juan Pérez
   Teléfono: 0999999999
   Fecha: [Selecciona una fecha futura]
   Calle: Av. Principal 123
   Ciudad: Quito
   Provincia: Pichincha
   Código Postal: 170101
   Método de envío: [Selecciona uno]
   ```
2. **Haz clic en "Continuar"**

**Resultado esperado:**
- ✅ Redirige a `ResumenPedido.jsp`
- ✅ Muestra resumen completo del pedido

---

### **PASO 4: Confirmar Pedido (ResumenPedido.jsp)**
1. Revisa la información mostrada:
   - ✅ Destinatario: Juan Pérez
   - ✅ Dirección: Av. Principal 123, Quito, Pichincha
   - ✅ Productos del pedido
   - ✅ Totales (Subtotal, IGV, Envío, Total)
2. **Haz clic en "✓ Procesar Compra"**

**Resultado esperado:**
- ✅ Pedido se guarda en base de datos
- ✅ Se genera número: PED-20260119-XXXX
- ✅ Carrito se vacía automáticamente
- ✅ **Redirige a `/ProcesarCompra?action=procesarCompraPedido`**
- ✅ Muestra `AdjuntarComprobante.jsp`

---

### **PASO 5: Adjuntar Comprobante (AdjuntarComprobante.jsp)**
1. Verifica que se muestre:
   - ✅ Resumen del pedido guardado
   - ✅ Número de pedido
   - ✅ Total a pagar
2. Completa el formulario:
   ```
   Banco: Banco Pichincha
   Titular: Juan Pérez Gómez
   Número de cuenta: 2100123456
   Tipo de cuenta: Ahorros
   RUC: 1234567890001 (opcional)
   Número de comprobante: COMP-2026-001
   Imagen: [Selecciona una imagen JPG/PNG]
   ```
3. **Haz clic en "Enviar Comprobante"**

**Resultado esperado:**
- ✅ Pago se guarda en BD (estado: PENDIENTE)
- ✅ Comprobante se guarda con la imagen
- ✅ **Se envía correo a rochaximena1502@gmail.com**
- ✅ Redirige a `MensajeExito.jsp`

---

### **PASO 6: Verificar Correo del Administrador**
1. Abre Gmail: https://gmail.com
2. Inicia sesión con: rochaximena1502@gmail.com
3. Busca el correo: "Nuevo Comprobante de Pago"
4. Verifica que contenga:
   - ✅ Información del pedido
   - ✅ Información del pago
   - ✅ Comprobante adjunto (imagen)
   - ✅ **Botón verde: [✓ APROBAR PAGO]**
   - ✅ **Botón rojo: [✗ RECHAZAR PAGO]**

---

### **PASO 7: Aprobar Pago (Desde el Correo)**
1. En el correo, **haz clic en [✓ APROBAR PAGO]**
2. Se abre en el navegador: `/ProcesarCompra?action=aprobarPago&idPago=X`

**Resultado esperado:**
- ✅ Pago se actualiza a: APROBADO
- ✅ Pedido se actualiza a: PAGO_APROBADO
- ✅ **Se envía correo al comprador** con confirmación
- ✅ Muestra `ConfirmacionAprobacion.jsp`

---

### **PASO 8: Verificar Correo del Comprador**
1. Revisa el correo del comprador (el que usaste para iniciar sesión)
2. Busca: "✓ Pago Aprobado - Pedido #XXX"
3. Verifica que contenga:
   - ✅ Confirmación de aprobación
   - ✅ Número de pedido
   - ✅ Total pagado
   - ✅ Mensaje de que será enviado

---

## 🔍 VERIFICACIÓN EN BASE DE DATOS

### **Tabla: pedido**
```sql
SELECT * FROM pedido ORDER BY id_pedido DESC LIMIT 1;
```
**Debe mostrar:**
- ✅ numero_pedido: PED-20260119-XXXX
- ✅ estado: PAGO_APROBADO
- ✅ total: [El total calculado]

### **Tabla: pago_transferencia**
```sql
SELECT * FROM pago_transferencia ORDER BY id_pago DESC LIMIT 1;
```
**Debe mostrar:**
- ✅ banco: Banco Pichincha
- ✅ titular: Juan Pérez Gómez
- ✅ estado: APROBADO
- ✅ id_pedido: [ID del pedido creado]

### **Tabla: comprobante_pago**
```sql
SELECT id_comprobante, numero_comprobante, nombre_comprador, nombre_archivo 
FROM comprobante_pago ORDER BY id_comprobante DESC LIMIT 1;
```
**Debe mostrar:**
- ✅ numero_comprobante: COMP-2026-001
- ✅ nombre_comprador: Juan Pérez (o el usuario)
- ✅ nombre_archivo: [nombre de la imagen subida]
- ✅ imagen: [LONGBLOB con datos]

---

## 🚨 POSIBLES PROBLEMAS Y SOLUCIONES

### **Problema 1: No redirige a AdjuntarComprobante.jsp**
**Causa:** Pedido no se guardó correctamente  
**Solución:**
1. Verifica que el pedido esté en BD
2. Revisa logs de consola para errores
3. Verifica que `pedidoActual` esté en sesión

### **Problema 2: No se envía el correo**
**Causa:** Configuración SMTP incorrecta  
**Solución:**
1. Verifica conexión a internet
2. Verifica credenciales en EmailUtil.java:
   ```java
   EMAIL_FROM = "rochaximena1502@gmail.com"
   EMAIL_PASSWORD = "pvuh oroj figx wfza"
   ```
3. Revisa logs de consola para errores SMTP

### **Problema 3: Error al subir imagen**
**Causa:** Imagen muy grande o formato no soportado  
**Solución:**
1. Usar imagen menor a 5MB
2. Formatos: JPG, PNG
3. Verificar que el form tenga: `enctype="multipart/form-data"`

### **Problema 4: Botones del correo no funcionan**
**Causa:** URL incorrecta  
**Solución:**
1. Verifica que la URL tenga el formato:
   ```
   http://localhost:8080/ProyectoAPPWeb/ProcesarCompra?action=aprobarPago&idPago=1
   ```
2. Verifica que el servidor esté corriendo
3. Prueba la URL manualmente en el navegador

---

## ✅ CHECKLIST DE VERIFICACIÓN

- [ ] Productos agregados al carrito
- [ ] Botón "Procesar Pedido" funciona
- [ ] Formulario de datos de entrega se muestra
- [ ] ResumenPedido.jsp muestra datos correctos
- [ ] Botón "Procesar Compra" funciona
- [ ] **Redirige a AdjuntarComprobante.jsp**
- [ ] Formulario de comprobante se muestra
- [ ] Se puede adjuntar imagen
- [ ] Al enviar, muestra MensajeExito.jsp
- [ ] **Correo llegó al administrador**
- [ ] Correo tiene comprobante adjunto
- [ ] **Botones del correo funcionan**
- [ ] Al aprobar, se envía correo al comprador
- [ ] Estados en BD se actualizan correctamente

---

## 📱 CAPTURAS ESPERADAS

### **1. ResumenPedido.jsp**
- Header rosa con logo
- Pasos del proceso (3 activo)
- Información de entrega en tarjetas
- Lista de productos
- Totales calculados
- **Botón "✓ Procesar Compra"**

### **2. AdjuntarComprobante.jsp**
- Header morado con título
- Resumen del pedido en caja gris
- Formulario de datos bancarios
- Campo para subir imagen
- Preview de imagen
- **Botón "Enviar Comprobante"**

### **3. MensajeExito.jsp**
- Header verde con check animado
- Mensaje de éxito
- 4 pasos del proceso
- Tiempo estimado: 24-48 hrs
- Botones de navegación

### **4. Correo del Administrador**
- Asunto: "Nuevo Comprobante de Pago - Pedido #XXX"
- Información del pedido (tarjeta)
- Información del pago (tarjeta)
- Comprobante adjunto
- **Botón verde: [✓ APROBAR PAGO]**
- **Botón rojo: [✗ RECHAZAR PAGO]**

### **5. Correo del Comprador**
- Asunto: "✓ Pago Aprobado - Pedido #XXX"
- Confirmación de aprobación
- Número de pedido
- Total pagado
- Mensaje de agradecimiento

---

## 🎉 ¡FLUJO COMPLETADO!

Si todos los pasos funcionan correctamente, **¡el flujo está 100% operativo!**

---

**Última actualización:** 2026-01-19  
**Estado:** ✅ LISTO PARA PRUEBAS
