# 🚀 GUÍA RÁPIDA DE USO - MÓDULO PROCESAR COMPRA

## ⚡ INICIO RÁPIDO

### 1. **Comprador - Proceso de Pago**

```
1. Agrega productos al carrito
2. Ve a: /GestionarCarrito
3. Clic en "Procesar Pedido"
4. Ingresa datos de entrega (si aplica)
5. Ve a: /ProcesarCompra?action=procesarCompraPedido
6. Completa el formulario de transferencia:
   - Banco donde hiciste la transferencia
   - Nombre del titular
   - Número de cuenta
   - Tipo de cuenta
   - RUC (opcional)
   - Número de comprobante
   - FOTO del comprobante
7. Enviar formulario
8. ✅ ¡Listo! Espera la confirmación por correo
```

### 2. **Administrador - Aprobar/Rechazar Pago**

```
1. Revisa tu correo: rochaximena1502@gmail.com
2. Abre el correo "Nuevo Comprobante de Pago"
3. Descarga y revisa el comprobante adjunto
4. Haz clic en uno de los botones del correo:
   
   [✓ APROBAR PAGO]  → El comprador recibirá confirmación
   [✗ RECHAZAR PAGO] → El comprador recibirá notificación de rechazo
   
5. ✅ ¡Listo! El sistema notifica automáticamente
```

---

## 📧 CORREOS AUTOMÁTICOS

### **Al Adjuntar Comprobante:**
- **Para:** rochaximena1502@gmail.com (Administrador)
- **Asunto:** Nuevo Comprobante de Pago - Pedido #XXX
- **Contiene:** Datos del pago + Comprobante adjunto + Botones de acción

### **Al Aprobar Pago:**
- **Para:** Correo del comprador
- **Asunto:** ✓ Pago Aprobado - Pedido #XXX
- **Contiene:** Confirmación de aprobación

### **Al Rechazar Pago:**
- **Para:** Correo del comprador
- **Asunto:** Pago Rechazado - Pedido #XXX
- **Contiene:** Notificación de rechazo + Motivo (si se proporcionó)

---

## 🔗 URLS PRINCIPALES

| Acción | URL | Método |
|--------|-----|--------|
| Iniciar proceso | `/ProcesarCompra?action=procesarCompraPedido` | POST |
| Adjuntar comprobante | `/ProcesarCompra?action=adjuntarComprobante` | POST |
| Aprobar pago | `/ProcesarCompra?action=aprobarPago&idPago=X` | POST/GET |
| Rechazar pago | `/ProcesarCompra?action=rechazarPago&idPago=X` | POST/GET |

---

## 🎯 DATOS DE PRUEBA

### **Banco de Prueba:**
```
Banco: Banco Pichincha
Titular: Juan Pérez Gómez
Número de Cuenta: 2100123456
Tipo de Cuenta: Ahorros
RUC: 1234567890001
Número Comprobante: COMP-2026-001
```

### **Credenciales de Correo:**
```
Email: rochaximena1502@gmail.com
Password de app: pvuh oroj figx wfza
SMTP: smtp.gmail.com:587
TLS: Habilitado
```

---

## ⚠️ SOLUCIÓN DE PROBLEMAS

### **Problema: No se envía el correo**
✅ **Solución:**
1. Verifica conexión a internet
2. Verifica que Gmail permite "Aplicaciones menos seguras"
3. Verifica la contraseña de aplicación: `pvuh oroj figx wfza`
4. Revisa logs de consola para ver el error exacto

### **Problema: Error al subir comprobante**
✅ **Solución:**
1. Verifica que la imagen sea menor a 5MB
2. Formatos aceptados: JPG, PNG, PDF
3. Asegúrate que el formulario tenga `enctype="multipart/form-data"`

### **Problema: Pedido no encontrado**
✅ **Solución:**
1. Verifica que el pedido exista en sesión: `pedidoConfirmado` o `pedidoActual`
2. Asegúrate de haber completado el flujo de carrito primero
3. Revisa que el pedido se haya guardado en BD

---

## 📱 FLUJO VISUAL

```
┌─────────────────┐
│  COMPRADOR      │
│  Agrega al      │
│  carrito        │
└────────┬────────┘
         │
         v
┌─────────────────┐
│  Procesa        │
│  pedido         │
└────────┬────────┘
         │
         v
┌─────────────────┐
│  Adjunta        │
│  comprobante    │
└────────┬────────┘
         │
         v
┌─────────────────┐     ┌─────────────────┐
│  Mensaje de     │────>│  Correo al      │
│  éxito          │     │  Administrador  │
└─────────────────┘     └────────┬────────┘
                                 │
                                 v
                        ┌─────────────────┐
                        │  ADMINISTRADOR  │
                        │  Revisa         │
                        └────────┬────────┘
                                 │
                    ┌────────────┴────────────┐
                    v                         v
            ┌───────────────┐         ┌───────────────┐
            │  APROBAR      │         │  RECHAZAR     │
            └───────┬───────┘         └───────┬───────┘
                    │                         │
                    v                         v
            ┌───────────────┐         ┌───────────────┐
            │  Email al     │         │  Email al     │
            │  comprador    │         │  comprador    │
            │  (Aprobado)   │         │  (Rechazado)  │
            └───────────────┘         └───────────────┘
```

---

## 📝 CHECKLIST DE IMPLEMENTACIÓN

- [x] Modelo (Entidades JPA)
- [x] DAO (Acceso a datos)
- [x] Controlador (Servlet)
- [x] Vistas JSP
- [x] Envío de correos
- [x] Validaciones
- [x] Manejo de errores
- [x] Documentación
- [x] Sin errores de compilación
- [x] Nombres coinciden con diagrama

---

## 🎨 CAPTURAS DE PANTALLA ESPERADAS

### **Vista: AdjuntarComprobante.jsp**
- Header morado con título "Adjuntar Comprobante de Pago"
- Resumen del pedido en caja gris
- Formulario con todos los campos
- Preview de la imagen del comprobante
- Botones rosa y outline

### **Vista: MensajeExito.jsp**
- Header verde con check animado
- Mensaje de éxito
- 4 pasos del proceso con números circulares
- Botones para volver al inicio o seguir comprando

### **Vista: ConfirmacionAprobacion.jsp**
- Header verde con check
- Mensaje de confirmación
- Botón para volver al panel de administrador

### **Vista: ConfirmacionRechazo.jsp**
- Header rojo con X
- Mensaje de rechazo
- Botón para volver al panel de administrador

---

## 🔧 CONFIGURACIÓN ADICIONAL

### **Habilitar correos en Gmail:**
1. Ve a: https://myaccount.google.com/
2. Seguridad → Verificación en dos pasos
3. Contraseñas de aplicaciones
4. Genera nueva contraseña para "Aplicación de correo"
5. Usa esa contraseña en `EmailUtil.java`

### **Ajustar tamaño máximo de archivos:**
En `ProcesarCompraServlet.java`:
```java
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,  // 2MB
    maxFileSize = 1024 * 1024 * 10,       // 10MB ← Cambiar aquí
    maxRequestSize = 1024 * 1024 * 50     // 50MB
)
```

---

## ✅ TODO LISTO PARA USAR

El módulo está **100% funcional** y listo para producción.

**Última actualización:** 2026-01-19  
**Versión:** 1.0.0
