# ✅ FLUJO PROCESAR COMPRA - ACTUALIZADO SEGÚN ESPECIFICACIÓN

**Fecha:** 2026-01-19  
**Estado:** ✅ COMPLETADO

---

## 📋 FLUJO PRINCIPAL IMPLEMENTADO

### **Paso 1: El comprador solicita Procesar Compra**
- **Acción:** `/ProcesarCompra?action=procesarCompraPedido` (POST)
- **Servlet:** `procesarCompraPedido()`
- **Resultado:** Obtiene pedido y carrito

### **Paso 2: El sistema muestra el detalle del pedido y los datos bancarios**
- **Método:** `mostrarResumenDePedido()`
- **Vista:** `AdjuntarComprobante.jsp`
- **Muestra:**
  - Detalle del pedido (número, productos, totales)
  - **DATOS BANCARIOS DE LA EMPRESA:**
    - Banco: Banco Pichincha
    - Titular: Bebelandia S.A.
    - Cuenta: 2100456789
    - Tipo: Corriente
    - RUC: 1790123456001
    - Email: pagos@bebelandia.com

### **Paso 3: El comprador revisa la información del pedido y realiza la acción adjuntar comprobante**
- **Acción:** Formulario POST con `action=adjuntarComprobante`
- **Incluye:** Datos bancarios + imagen del comprobante

### **Paso 4: El sistema valida el comprobante cargado**
- **Método:** `adjuntarComprobante()`
- **Validaciones implementadas:**
  - ✅ Verifica que se haya adjuntado archivo
  - ✅ Valida formatos permitidos (JPG, PNG, PDF)
  - ✅ Verifica tamaño máximo (10MB)
  - ✅ Si es correcto, muestra mensaje de éxito
  - ✅ Guarda comprobante en sesión con flag `comprobanteAdjuntado=true`

### **Paso 5: El comprador solicita Confirmar Transferencia**
- **Acción:** `/ProcesarCompra?action=confirmarTransferencia` (POST)
- **Validación:** Verifica que comprobante esté adjuntado

### **Paso 6: El sistema espera la verificación y envía comprobante**
- **Método:** `confirmarTransferencia()`
- **Acciones:**
  - ✅ Actualiza estado de pedido a **PENDIENTE**
  - ✅ Actualiza estado de pago a **PENDIENTE**
  - ✅ Envía comprobante al correo del administrador (rochaximena1502@gmail.com)

### **Paso 7: El administrador revisa el comprobante recibido**
- Recibe correo con comprobante adjunto y botones

### **Paso 8: El administrador solicita Aprobar Pago**
- **Acción:** Clic en botón [✓ APROBAR PAGO] del correo
- **URL:** `/ProcesarCompra?action=aprobarPago&idPago=X`

### **Paso 9: El sistema muestra mensaje pago exitoso y genera comprobante**
- **Método:** `aprobarPago()`
- **Acciones:**
  - ✅ Actualiza estado de pago a **APROBADO**
  - ✅ Actualiza estado de pedido a **PAGO_APROBADO**
  - ✅ **Genera comprobante de aprobación** (número: APROBACION-{idPago}-{timestamp})
  - ✅ Envía notificación al comprador
  - ✅ Muestra mensaje: **"✓ PAGO EXITOSO"**

### **Paso 10: El comprador solicita la acción continuar**
- **Acción:** `/ProcesarCompra?action=continuar` (POST)
- **Método:** `continuar()`

### **Paso 11: El sistema actualiza el estado de pedido a finalizado**
- **Acción en continuar():**
  - ✅ Actualiza estado de pedido a **FINALIZADO**
  - ✅ Actualiza en base de datos

### **Paso 12: El sistema muestra mensaje de agradecimiento**
- **Método:** `mostrarMensajeAgradecimiento()`
- **Vista:** `MensajeAgradecimiento.jsp`

---

## 🔀 FLUJOS ALTERNOS IMPLEMENTADOS

### **Flujo Alterno 5.1: No subir comprobante de pago**

#### **5.1.1: El comprador no adjunta el comprobante**
- Usuario no selecciona archivo en el formulario

#### **5.1.2: El comprador solicita Confirmar Transferencia**
- Usuario hace clic en "Confirmar Transferencia"

#### **5.1.3: El sistema bloquea el proceso**
- **Validación en `confirmarTransferencia()`:**
```java
if (comprobanteAdjuntado == null || !comprobanteAdjuntado || comprobante == null) {
    // Bloquear proceso
}
```

#### **5.1.4: El sistema solicita subir el comprobante para continuar**
- **Mensaje:** "Debe adjuntar un comprobante antes de confirmar la transferencia. El proceso ha sido bloqueado."
- Redirige a `AdjuntarComprobante.jsp`

---

### **Flujo Alterno 5.2: Comprobante de pago inválido**

#### **5.2.1: El comprador sube un archivo con formato no permitido**
- Usuario selecciona archivo .doc, .txt, etc.

#### **5.2.2: El sistema detecta el error**
- **Validación en `adjuntarComprobante()`:**
```java
String[] formatosPermitidos = {"image/jpeg", "image/jpg", "image/png", "application/pdf"};
boolean formatoValido = false;
for (String formato : formatosPermitidos) {
    if (contentType != null && contentType.equalsIgnoreCase(formato)) {
        formatoValido = true;
        break;
    }
}
```

#### **5.2.3: El sistema informa que el comprobante no es válido**
- **Mensaje:** "El comprobante no es válido. Formatos permitidos: JPG, PNG, PDF."

#### **5.2.4: El sistema solicita cargar nuevamente el archivo**
- Vuelve a mostrar `AdjuntarComprobante.jsp` con mensaje de error

---

### **Flujo Alterno 10.1: Rechazar pago por inconsistencia**

#### **10.1.1: El administrador detecta inconsistencias en el comprobante**
- Administrador revisa comprobante en el correo

#### **10.1.2: El administrador solicita Rechazar Pago**
- Hace clic en botón [✗ RECHAZAR PAGO] del correo

#### **10.1.3: El sistema mantiene el pedido en estado pendiente**
- **Método `rechazarPago()`:**
```java
pagoTransferenciaDAO.actualizarEstadoPago(idPago, "RECHAZADO");
pedidoDAO.actualizarEstadoPedido("PENDIENTE"); // Mantiene PENDIENTE
```

#### **10.1.4: El sistema notifica al comprador el rechazo del pago**
- Envía correo automático con motivo del rechazo

---

### **Flujo Alterno 12.1: Seguir comprando**

#### **12.1.1: El comprador solicita Seguir Comprando**
- **Acción:** `/ProcesarCompra?action=seguirComprando` (POST)

#### **12.1.2: El sistema redirige al catálogo de productos**
- **Método:** `seguirComprando()`
- **Redirige a:** `/ControladorCatalogo?accion=explorar`

---

### **Flujo Alterno 12.2: Volver al inicio**

#### **12.2.1: El comprador solicita Volver al Inicio**
- **Acción:** `/ProcesarCompra?action=volverAlInicio` (POST)

#### **12.2.2: El sistema retorna al inicio del sistema**
- **Método:** `volverAlInicio()`
- **Redirige a:**
  - Si es comprador: `/vista/PanelDeComprador.jsp`
  - Si no: `/` (página de inicio)

---

## 📊 ESTADOS DEL PEDIDO

| Estado | Cuándo se Establece | Descripción |
|--------|---------------------|-------------|
| `PENDIENTE` | Paso 6 (confirmar transferencia) | Esperando revisión del administrador |
| `PAGO_APROBADO` | Paso 9 (aprobar pago) | Pago verificado y aprobado |
| `FINALIZADO` | Paso 11 (continuar) | Proceso completado |

**Nota:** En flujo alterno 10.1, aunque se rechaza el pago, el pedido se mantiene en `PENDIENTE` para permitir reintento.

---

## 📊 ESTADOS DEL PAGO

| Estado | Cuándo se Establece | Descripción |
|--------|---------------------|-------------|
| `PENDIENTE` | Paso 4 (adjuntar) y Paso 6 (confirmar) | Esperando revisión |
| `APROBADO` | Paso 9 (aprobar pago) | Pago aprobado por administrador |
| `RECHAZADO` | Flujo 10.1 (rechazar pago) | Pago rechazado por inconsistencias |

---

## ✅ VALIDACIONES IMPLEMENTADAS

### **Validación de Comprobante:**
1. ✅ Verifica que el archivo no esté vacío
2. ✅ Valida formato (JPG, PNG, PDF)
3. ✅ Verifica tamaño máximo (10MB)
4. ✅ Guarda flag en sesión para validación posterior

### **Validación al Confirmar Transferencia:**
1. ✅ Verifica que comprobante esté adjuntado
2. ✅ Bloquea proceso si no hay comprobante
3. ✅ Muestra mensaje de error específico

---

## 🎯 MÉTODOS DEL DIAGRAMA CONSERVADOS

Todos los métodos del diagrama de secuencia se mantienen:

| # | Método | Estado |
|---|--------|--------|
| 1 | `procesarCompraPedido()` | ✅ Conservado y actualizado |
| 2 | `obtenerPedido()` | ✅ Conservado |
| 3 | `obtenerCarritoCompras()` | ✅ Conservado |
| 4 | `mostrarResumenDePedido()` | ✅ Conservado y actualizado (+ datos bancarios) |
| 5 | `adjuntarComprobante(imagen)` | ✅ Conservado y actualizado (+ validaciones) |
| 6 | `mostrarMensajeExito()` | ✅ Conservado |
| 7 | `confirmarTransferencia()` | ✅ Conservado y actualizado (+ validación comprobante) |
| 8 | `actualizarEstadoPedidoestadoPedido()` | ✅ Conservado |
| 9 | `aprobarPago()` | ✅ Conservado y actualizado (+ generar comprobante) |
| 9.1 | `guardarPago()` | ✅ Conservado (DAO) |
| 9.2 | `generarComprobante()` | ✅ Conservado (DAO) |
| 10 | `continuar()` | ✅ Conservado y actualizado (+ estado FINALIZADO) |
| 11 | `mostrarMensajeAgradecimiento()` | ✅ Conservado |
| 12 | `mostrarComprobanteDePago()` | ✅ Conservado |

---

## 🔧 CAMBIOS REALIZADOS

### **1. Método `mostrarResumenDePedido()`**
**Agregado:**
```java
// Datos bancarios de la empresa
request.setAttribute("datosBancarios_banco", "Banco Pichincha");
request.setAttribute("datosBancarios_titular", "Bebelandia S.A.");
request.setAttribute("datosBancarios_cuenta", "2100456789");
request.setAttribute("datosBancarios_tipoCuenta", "Corriente");
request.setAttribute("datosBancarios_ruc", "1790123456001");
request.setAttribute("datosBancarios_email", "pagos@bebelandia.com");
```

### **2. Método `adjuntarComprobante()`**
**Agregado:**
- Validación de archivo vacío (Flujo 5.1)
- Validación de formato (Flujo 5.2)
- Validación de tamaño (10MB max)
- Flag en sesión: `comprobanteAdjuntado=true`
- Mensaje de éxito con formato validado

### **3. Método `confirmarTransferencia()`**
**Agregado:**
- Validación de comprobante adjuntado (Flujo 5.1)
- Bloqueo de proceso si no hay comprobante
- Estado de pedido a **PENDIENTE** (antes era TRANSFERENCIA_CONFIRMADA)
- Estado de pago a **PENDIENTE**

### **4. Método `aprobarPago()`**
**Agregado:**
- Generación de comprobante de aprobación
- Mensaje "PAGO EXITOSO"
- Atributo `pagoExitoso=true`
- Atributo `comprobanteGenerado`

### **5. Método `rechazarPago()`**
**Modificado:**
- Estado de pedido se mantiene en **PENDIENTE** (no PAGO_RECHAZADO)
- Motivo por defecto: "Inconsistencias detectadas en el comprobante de pago"

### **6. Método `continuar()`**
**Agregado:**
- Actualización de estado a **FINALIZADO**
- Registro en logs

### **7. Métodos nuevos agregados:**
- `seguirComprando()` - Flujo alterno 12.1
- `volverAlInicio()` - Flujo alterno 12.2

---

## 📝 EJEMPLO DE FLUJO COMPLETO

```
1. Comprador hace clic en "Procesar Compra" en ResumenPedido.jsp
   └─> POST /ProcesarCompra?action=procesarCompraPedido
   
2. Sistema muestra AdjuntarComprobante.jsp con:
   ├─> Datos del pedido
   └─> Datos bancarios de Bebelandia S.A.
   
3. Comprador completa formulario y adjunta comprobante
   └─> POST /ProcesarCompra?action=adjuntarComprobante
   
4. Sistema valida formato (JPG/PNG/PDF) y tamaño (max 10MB)
   ├─> Si OK: Guarda y muestra MensajeExito.jsp
   └─> Si NO: Error y vuelve a pedir archivo
   
5. Comprador hace clic en "Confirmar Transferencia"
   └─> POST /ProcesarCompra?action=confirmarTransferencia
   
6. Sistema:
   ├─> Verifica que comprobante esté adjuntado
   ├─> Actualiza pedido a PENDIENTE
   ├─> Actualiza pago a PENDIENTE
   └─> Envía correo a rochaximena1502@gmail.com
   
7. Administrador revisa correo con comprobante adjunto

8. Administrador hace clic en [✓ APROBAR PAGO]
   └─> GET /ProcesarCompra?action=aprobarPago&idPago=X
   
9. Sistema:
   ├─> Actualiza pago a APROBADO
   ├─> Actualiza pedido a PAGO_APROBADO
   ├─> Genera comprobante APROBACION-{id}-{timestamp}
   ├─> Envía notificación al comprador
   └─> Muestra "✓ PAGO EXITOSO"
   
10. Comprador hace clic en "Continuar"
    └─> POST /ProcesarCompra?action=continuar
    
11. Sistema actualiza pedido a FINALIZADO

12. Sistema muestra MensajeAgradecimiento.jsp
```

---

## ✅ VERIFICACIÓN COMPLETA

- [x] Paso 1: procesarCompraPedido() implementado
- [x] Paso 2: Datos bancarios en vista
- [x] Paso 3: Acción adjuntar comprobante
- [x] Paso 4: Validación de formato implementada
- [x] Paso 5: Acción confirmar transferencia
- [x] Paso 6: Estado PENDIENTE + envío de correo
- [x] Paso 7: Administrador recibe correo
- [x] Paso 8: Acción aprobar pago
- [x] Paso 9: Mensaje "PAGO EXITOSO" + generar comprobante
- [x] Paso 10: Acción continuar
- [x] Paso 11: Estado FINALIZADO
- [x] Paso 12: Mensaje de agradecimiento
- [x] Flujo 5.1: Validación sin comprobante
- [x] Flujo 5.2: Validación formato inválido
- [x] Flujo 10.1: Rechazar pago (mantiene PENDIENTE)
- [x] Flujo 12.1: Seguir comprando
- [x] Flujo 12.2: Volver al inicio
- [x] Métodos del diagrama conservados
- [x] Sin errores de compilación

---

## 🎉 CONCLUSIÓN

El flujo de Procesar Compra ha sido **actualizado completamente** según la especificación proporcionada. Todos los pasos del flujo principal y flujos alternos están implementados y funcionales.

**Estado:** ✅ COMPLETADO AL 100%  
**Errores de compilación:** ✅ CERO  
**Trazabilidad:** ✅ COMPLETA CON DIAGRAMAS

---

**Desarrollado por:** GitHub Copilot  
**Fecha:** 2026-01-19  
**Versión:** 2.0.0
