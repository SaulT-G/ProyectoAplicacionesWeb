-- =====================================================
-- SCRIPT: Insertar Métodos de Envío
-- Base de datos: EncantoEA
-- Fecha: 2026-01-17
-- =====================================================

-- Crear tabla si no existe
CREATE TABLE IF NOT EXISTS metodo_envio (
    id_metodo_envio INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(50) NOT NULL,
    descripcion VARCHAR(255),
    costo DOUBLE NOT NULL,
    tiempo_estimado VARCHAR(100)
);

-- Eliminar datos existentes (opcional, comentar si no se desea)
-- DELETE FROM metodo_envio;

-- Insertar métodos de envío
INSERT INTO metodo_envio (id_metodo_envio, tipo, descripcion, costo, tiempo_estimado) VALUES 
(1, 'Envío Estándar', 'Entrega a domicilio en horario regular de lunes a viernes', 15.00, '3-5 días hábiles'),
(2, 'Envío Express', 'Entrega rápida a domicilio con prioridad', 25.00, '1-2 días hábiles'),
(3, 'Envío Premium', 'Entrega el mismo día en zonas seleccionadas', 40.00, 'Mismo día (antes de las 6pm)'),
(4, 'Recojo en Tienda', 'Recoge tu pedido en nuestra tienda sin costo adicional', 0.00, 'Disponible en 24 horas')
ON DUPLICATE KEY UPDATE 
    tipo = VALUES(tipo),
    descripcion = VALUES(descripcion),
    costo = VALUES(costo),
    tiempo_estimado = VALUES(tiempo_estimado);

-- Verificar los datos insertados
SELECT * FROM metodo_envio ORDER BY costo ASC;
