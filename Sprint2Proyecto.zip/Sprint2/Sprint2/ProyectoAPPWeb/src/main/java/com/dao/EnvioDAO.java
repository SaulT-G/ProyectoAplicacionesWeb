package com.dao;

import com.modelo.conection.PersistenciaBDD;
import com.modelo.entities.Envio;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.Date;

/**
 * ========================================================================
 * DAO: EnvioDAO
 * ========================================================================
 * Según el diagrama de clases:
 * +guardarInfoEnvio(nombredestinatario : String, telefono : String, fechaentrega : Date) : boolean
 */
public class EnvioDAO {

    /**
     * Guarda la información de envío
     * Según diagrama: +guardarInfoEnvio(nombredestinatario : String, telefono : String, fechaentrega : Date) : boolean
     * @param nombredestinatario Nombre del destinatario
     * @param telefono Teléfono de contacto
     * @param fechaentrega Fecha de entrega
     * @return true si se guardó exitosamente
     */
    public boolean guardarInfoEnvio(String nombredestinatario, String telefono, Date fechaentrega) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            
            Envio envio = new Envio(nombredestinatario, telefono, fechaentrega);
            em.persist(envio);
            
            tx.commit();
            System.out.println("✓ Información de envío guardada exitosamente");
            return true;
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            System.err.println("❌ Error al guardar información de envío: " + e.getMessage());
            return false;
        } finally {
            em.close();
        }
    }

  
}
