package com.modelo.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import jakarta.persistence.*;

/**
 * ========================================================================
 * ENTIDAD: ItemVenta (Clase Padre)
 * ========================================================================
 * Clase abstracta que representa un item de venta genérico.
 * Es la clase padre de Producto y ProductoPersonalizado.
 * 
 * Atributos:
 * - id: Identificador único
 * - nombre: Nombre del item
 * - precio: Precio del item
 */
@Entity
@Table(name = "item_venta")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class ItemVenta implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected int id;

    @Column(name = "nombre", nullable = false, length = 255)
    protected String nombre;

    @Column(name = "precio", nullable = false, precision = 10, scale = 2)
    protected BigDecimal precio;

    @Lob
    @Column(name = "imagen", columnDefinition = "MEDIUMBLOB")
    protected byte[] imagen;

    // Constructor vacío (requerido por JPA)
    public ItemVenta() {
    }

    // Constructor con parámetros
    public ItemVenta(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = BigDecimal.valueOf(precio);
    }

    // Constructor con id
    public ItemVenta(int id, String nombre, double precio) {
        this.id = id;
        this.nombre = nombre;
        this.precio = BigDecimal.valueOf(precio);
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public BigDecimal getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = BigDecimal.valueOf(precio);
    }
    
    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    public byte[] getImagen() {
        return imagen;
    }

    public void setImagen(byte[] imagen) {
        this.imagen = imagen;
    }
}
