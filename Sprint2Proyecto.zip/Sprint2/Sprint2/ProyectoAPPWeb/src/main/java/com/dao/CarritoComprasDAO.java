package com.dao;

import com.modelo.entities.CarritoCompras;
import com.modelo.entities.ItemCarrito;

/**
 * ========================================================================
 * DAO: CarritoComprasDAO
 * ========================================================================
 * Según el diagrama de clases:
 * +obtenerCarritoDeCompras() : CarritoCompras
 * +eliminarItemDelCarrito(itemCarritoId : int) : void
 * +quitarTodosLosItems(carritoCompras : CarritoCompras) : void
 * +recalcularSubtotal() : double
 */
public class CarritoComprasDAO {

    /**
     * Obtiene el carrito de compras
     * Según diagrama: +obtenerCarritoDeCompras() : CarritoCompras
     */
    public CarritoCompras obtenerCarritoDeCompras(CarritoCompras carrito) {
        if (carrito == null) {
            return new CarritoCompras();
        }
        return carrito;
    }

    /**
     * Elimina un item del carrito por su ID
     * Según diagrama: +eliminarItemDelCarrito(itemCarritoId : int) : void
     */
    public void eliminarItemDelCarrito(CarritoCompras carrito, int itemCarritoId) {
        if (carrito != null) {
            carrito.eliminarItem(itemCarritoId);
        }
    }

    /**
     * Quita todos los items del carrito
     * Según diagrama: +quitarTodosLosItems(carritoCompras : CarritoCompras) : void
     */
    public void quitarTodosLosItems(CarritoCompras carritoCompras) {
        if (carritoCompras != null) {
            carritoCompras.vaciarCarrito();
        }
    }

    /**
     * Recalcula el subtotal del carrito
     * Según diagrama: +recalcularSubtotal() : double
     */
    public double recalcularSubtotal(CarritoCompras carrito) {
        if (carrito != null) {
            carrito.recalcularTotal();
            return carrito.getSubtotal();
        }
        return 0.0;
    }

    /**
     * Guarda un item en el carrito
     * Según diagrama de robustez: guardarItemCarrito(itemcarrito)
     */
    public void guardarItemCarrito(CarritoCompras carrito, ItemCarrito itemCarrito) {
        if (carrito != null && itemCarrito != null) {
            carrito.agregarItem(itemCarrito);
        }
    }
}
