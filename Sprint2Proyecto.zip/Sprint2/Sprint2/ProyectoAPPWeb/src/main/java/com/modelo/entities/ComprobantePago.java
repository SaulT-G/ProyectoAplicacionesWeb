package com.modelo.entities;

import jakarta.persistence.*;
import java.util.Date;

/**
 * Entidad ComprobantePago
 * Representa el comprobante de pago adjuntado según el diagrama
 */
@Entity
@Table(name = "comprobante_pago")
public class ComprobantePago {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_comprobante")
    private Integer idComprobante;
    
    @Column(name = "nombre_comprador", length = 150)
    private String nombreComprador;
    
    @Column(name = "numero_comprobante", length = 50)
    private String numeroComprobante;
    
    @Column(name = "fecha_emision", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaEmision;
    
    @Lob
    @Column(name = "imagen", columnDefinition = "LONGBLOB")
    private byte[] imagen;
    
    @Column(name = "nombre_archivo", length = 255)
    private String nombreArchivo;
    
    @Column(name = "tipo_mime", length = 100)
    private String tipoMime;
    
    @OneToOne
    @JoinColumn(name = "id_pago")
    private PagoTransferencia pagoTransferencia;
    
    // Constructores
    public ComprobantePago() {
        this.fechaEmision = new Date();
    }
    
    public ComprobantePago(String nombreComprador, String numeroComprobante, Date fechaEmision) {
        this();
        this.nombreComprador = nombreComprador;
        this.numeroComprobante = numeroComprobante;
        this.fechaEmision = fechaEmision;
    }
    
    // Getters y Setters
    public Integer getIdComprobante() {
        return idComprobante;
    }
    
    public void setIdComprobante(Integer idComprobante) {
        this.idComprobante = idComprobante;
    }
    
    public String getNombreComprador() {
        return nombreComprador;
    }
    
    public void setNombreComprador(String nombreComprador) {
        this.nombreComprador = nombreComprador;
    }
    
    public String getNumeroComprobante() {
        return numeroComprobante;
    }
    
    public void setNumeroComprobante(String numeroComprobante) {
        this.numeroComprobante = numeroComprobante;
    }
    
    public Date getFechaEmision() {
        return fechaEmision;
    }
    
    public void setFechaEmision(Date fechaEmision) {
        this.fechaEmision = fechaEmision;
    }
    
    public byte[] getImagen() {
        return imagen;
    }
    
    public void setImagen(byte[] imagen) {
        this.imagen = imagen;
    }
    
    public String getNombreArchivo() {
        return nombreArchivo;
    }
    
    public void setNombreArchivo(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }
    
    public String getTipoMime() {
        return tipoMime;
    }
    
    public void setTipoMime(String tipoMime) {
        this.tipoMime = tipoMime;
    }
    
    public PagoTransferencia getPagoTransferencia() {
        return pagoTransferencia;
    }
    
    public void setPagoTransferencia(PagoTransferencia pagoTransferencia) {
        this.pagoTransferencia = pagoTransferencia;
    }
    
    /**
     * Método según diagrama: generarComprobante(nombreComprador, numeroComprobante, fechaEmision)
     */
    public ComprobantePago generarComprobante(String nombreComprador, String numeroComprobante, Date fechaEmision) {
        this.nombreComprador = nombreComprador;
        this.numeroComprobante = numeroComprobante;
        this.fechaEmision = fechaEmision;
        return this;
    }
    
    /**
     * Método según diagrama: mostrarComprobanteDePago()
     */
    public void mostrarComprobanteDePago() {
        System.out.println("Comprobante #" + numeroComprobante + " - Comprador: " + nombreComprador);
    }
}
