package com.controlador;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import com.dao.ProductoDAO;
import com.modelo.entities.Producto;

/**
 * Servlet implementation class ProductoServlet
 * Maneja la carga de productos y sus imágenes
 */
@WebServlet("/ProductoServlet")
public class ProductoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ProductoDAO dao = new ProductoDAO();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductoServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String op = request.getParameter("op");
		
		// Si se solicita una imagen
		if ("imagen".equals(op)) {
			cargarImagen(request, response);
			return;
		}
		
		// Por defecto, listar productos
		try {
			List<Producto> productos = dao.obtenerListadoDeProductos();
			request.setAttribute("productos", productos);
			request.getRequestDispatcher("/vista/ListaProductos.jsp").forward(request, response);
		} catch (Exception e) {
			throw new ServletException(e);
		}
	}
	
	/**
	 * Método para cargar y mostrar imágenes de productos desde la BD
	 */
	private void cargarImagen(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			// Obtener ID del producto
			String idParam = request.getParameter("id");
			if (idParam == null) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID de producto no especificado");
				return;
			}
			
			int id = Integer.parseInt(idParam);
			
			// Obtener producto desde la base de datos
			Producto producto = dao.obtenerDatosProducto(id);
			
			if (producto == null || producto.getImagen() == null || producto.getImagen().length == 0) {
				// Si no hay producto o no tiene imagen, enviar error
				response.sendError(HttpServletResponse.SC_NOT_FOUND, "Imagen no encontrada");
				return;
			}
			
			// Obtener los bytes de la imagen desde la BD
			byte[] imagenBytes = producto.getImagen();
			
			// Determinar el tipo MIME de la imagen
			String mimeType = "image/jpeg"; // Por defecto
			if (imagenBytes.length > 8) {
				// Detectar tipo por magic bytes
				if (imagenBytes[0] == (byte) 0x89 && imagenBytes[1] == (byte) 0x50) {
					mimeType = "image/png";
				} else if (imagenBytes[0] == (byte) 0x47 && imagenBytes[1] == (byte) 0x49) {
					mimeType = "image/gif";
				} else if (imagenBytes[0] == (byte) 0xFF && imagenBytes[1] == (byte) 0xD8) {
					mimeType = "image/jpeg";
				} else if (imagenBytes[0] == (byte) 0x52 && imagenBytes[1] == (byte) 0x49) {
					mimeType = "image/webp";
				}
			}
			
			// Configurar la respuesta
			response.setContentType(mimeType);
			response.setContentLength(imagenBytes.length);
			
			// Escribir la imagen en la respuesta
			try (OutputStream out = response.getOutputStream()) {
				out.write(imagenBytes);
			}
			
		} catch (NumberFormatException e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID de producto inválido");
		} catch (Exception e) {
			throw new ServletException("Error al cargar imagen: " + e.getMessage(), e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
