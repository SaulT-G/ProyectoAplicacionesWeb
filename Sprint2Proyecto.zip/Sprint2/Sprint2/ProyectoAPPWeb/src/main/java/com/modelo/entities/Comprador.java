package com.modelo.entities;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase Comprador - Subclase de Usuario según el diagrama de clases
 * Representa el comprador que explora el catálogo
 * Incluye relación con Direccion según el diagrama de Gestionar Clientes
 */
@Entity
@Table(name = "comprador")
@PrimaryKeyJoinColumn(name = "id_usuario")
public class Comprador extends Usuario implements Serializable {
    private static final long serialVersionUID = 1L;

    @OneToMany(mappedBy = "comprador", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private List<Direccion> direcciones = new ArrayList<>();

    // Constructores
    public Comprador() {
        super();
    }

    public Comprador(String nombre, String correoElectronico, String contrasena, String telefono, String estado) {
        super(nombre, correoElectronico, contrasena, telefono, estado, "COMPRADOR");
    }

    // Getters y Setters para direcciones
    public List<Direccion> getDirecciones() {
        return direcciones;
    }

    public void setDirecciones(List<Direccion> direcciones) {
        this.direcciones = direcciones;
    }

    /**
     * Agrega una dirección al comprador
     * @param direccion Direccion a agregar
     */
    public void agregarDireccion(Direccion direccion) {
        direcciones.add(direccion);
        direccion.setComprador(this);
    }

    /**
     * Elimina una dirección del comprador
     * @param direccion Direccion a eliminar
     */
    public void eliminarDireccion(Direccion direccion) {
        direcciones.remove(direccion);
        direccion.setComprador(null);
    }

    /**
     * Obtiene la dirección principal (primera en la lista)
     * @return Direccion principal o null si no tiene
     */
    public Direccion getDireccionPrincipal() {
        return direcciones.isEmpty() ? null : direcciones.get(0);
    }

    @Override
    public String toString() {
        return "Comprador{" +
                "idUsuario=" + getIdUsuario() +
                ", nombre='" + getNombre() + '\'' +
                ", correoElectronico='" + getCorreoElectronico() + '\'' +
                ", telefono='" + getTelefono() + '\'' +
                ", estado='" + getEstado() + '\'' +
                ", direcciones=" + direcciones.size() +
                '}';
    }
}
