package com.dao;

import java.util.List;

import com.modelo.entities.ItemCarrito;

/**
 * ========================================================================
 * DAO: ItemCarritoDAO
 * ========================================================================
 * Según el diagrama de clases:
 * +obtenerItemsDelCarrito() : List<ItemCarrito>
 */
public class ItemCarritoDAO {

    /**
     * Obtiene los items del carrito
     * Según diagrama: +obtenerItemsDelCarrito() : List<ItemCarrito>
     */
    public List<ItemCarrito> obtenerItemsDelCarrito(List<ItemCarrito> items) {
        return items;
    }
}
