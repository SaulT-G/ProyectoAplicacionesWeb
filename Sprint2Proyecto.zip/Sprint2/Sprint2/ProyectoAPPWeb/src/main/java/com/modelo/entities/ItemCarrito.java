package com.modelo.entities;

import java.io.Serializable;

/**
 * ========================================================================
 * ENTIDAD: ItemCarrito
 * ========================================================================
 * Representa un item dentro del carrito de compras.
 * Según el diagrama de clases:
 * - idItem : int
 * - cantidad : int
 * - precioUnitario : double
 * - subtotalPorCantidad : double
 * - item : ItemVenta
 */
public class ItemCarrito implements Serializable {
    private static final long serialVersionUID = 1L;

    private int idItem;
    private int cantidad;
    private double precioUnitario;
    private double subtotalPorCantidad;
    private ItemVenta item;

    // Constructor vacío
    public ItemCarrito() {
        this.cantidad = 1;
    }

    // Constructor con parámetros
    public ItemCarrito(int idItem, ItemVenta item, int cantidad) {
        this.idItem = idItem;
        this.item = item;
        this.cantidad = cantidad;
        this.precioUnitario = item.getPrecio().doubleValue();
        this.subtotalPorCantidad = this.precioUnitario * this.cantidad;
    }

    // Constructor con item solamente
    public ItemCarrito(ItemVenta item) {
        this.item = item;
        this.cantidad = 1;
        this.precioUnitario = item.getPrecio().doubleValue();
        this.subtotalPorCantidad = this.precioUnitario * this.cantidad;
    }

    // Getters y Setters
    public int getIdItem() {
        return idItem;
    }

    public void setIdItem(int idItem) {
        this.idItem = idItem;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
        recalcularSubtotal();
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public double getSubtotalPorCantidad() {
        return subtotalPorCantidad;
    }

    public void setSubtotalPorCantidad(double subtotalPorCantidad) {
        this.subtotalPorCantidad = subtotalPorCantidad;
    }

    public ItemVenta getItem() {
        return item;
    }

    public void setItem(ItemVenta item) {
        this.item = item;
        if (item != null) {
            this.precioUnitario = item.getPrecio().doubleValue();
            recalcularSubtotal();
        }
    }

    /**
     * Recalcula el subtotal según la cantidad
     */
    private void recalcularSubtotal() {
        this.subtotalPorCantidad = this.precioUnitario * this.cantidad;
    }

    /**
     * Incrementa la cantidad en 1
     */
    public void incrementarCantidad() {
        this.cantidad++;
        recalcularSubtotal();
    }

    /**
     * Decrementa la cantidad en 1 (mínimo 1)
     */
    public void decrementarCantidad() {
        if (this.cantidad > 1) {
            this.cantidad--;
            recalcularSubtotal();
        }
    }
}
