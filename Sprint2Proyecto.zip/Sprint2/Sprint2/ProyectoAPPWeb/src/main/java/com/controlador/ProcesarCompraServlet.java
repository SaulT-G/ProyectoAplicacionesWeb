package com.controlador;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.dao.CarritoComprasDAO;
import com.dao.ComprobantePagoDAO;
import com.dao.DireccionDAO;
import com.dao.EnvioDAO;
import com.dao.MetodoEnvioDAO;
import com.dao.PagoTransferenciaDAO;
import com.dao.PedidoDAO;
import com.modelo.entities.CarritoCompras;
import com.modelo.entities.Comprador;
import com.modelo.entities.ComprobantePago;
import com.modelo.entities.Direccion;
import com.modelo.entities.Envio;
import com.modelo.entities.MetodoEnvio;
import com.modelo.entities.PagoTransferencia;
import com.modelo.entities.Pedido;
import com.modelo.entities.Usuario;
import com.utils.EmailUtil;

/**
 * ========================================================================
 * CONTROLADOR: ProcesarCompra (Servlet)
 * ========================================================================
 * Implementa el flujo de Procesar Compra según los diagramas de robustez y secuencia.
 * 
 * Métodos según diagrama de clases:
 * +procesarCompraPedido() : void
 * +obtenerPedido() : Pedido
 * +obtenerCarritoCompras() : CarritoCompras
 * +adjuntarComprobante(imagen : String) : void
 * +confirmarTransferencia() : void
 * +actualizarEstadoPedidoestadoPedido(estadoPedido : String) : void
 * +aprobarPago() : void
 * +continuar() : void
 * +mostrarMensajeExito() : void
 * +mostrarMensajeAgradecimiento() : void
 * +mostrarComprobanteDePago() : void
 * 
 * Flujo según diagrama de secuencia (procesarcompra.png):
 * 1: procesarCompraPedido() : void
 * 2: obtenerPedido() : Pedido
 * 3: obtenerCarritoCompras() : carritocompras
 * 4: mostrarResumenDePedido() : void
 * 5: adjuntarComprobante(imagen : String) : void
 * 6: mostrarMensajeExito() : void
 * 7: confirmarTransferencia() : void
 * 8: actualizarEstadoPedidoestadoPedido(estadopedido : String) : void
 * 9: aprobarPago() : void
 * 9.1: guardarPago(...) : boolean
 * 9.2: generarComprobante(nombrecomprador, numerocomprobante, fechaemision) : Comprobante
 * 10: continuar() : void
 * 11: mostrarMensajeAgradecimiento() : void
 * 12: mostrarComprobanteDePago() : void
 */
@WebServlet(name = "ProcesarCompraServlet", urlPatterns = {"/ProcesarCompra"})
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,  // 2MB
    maxFileSize = 1024 * 1024 * 10,       // 10MB
    maxRequestSize = 1024 * 1024 * 50     // 50MB
)
public class ProcesarCompraServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private MetodoEnvioDAO metodoEnvioDAO;
    private CarritoComprasDAO carritoComprasDAO;
    private PedidoDAO pedidoDAO;
    private EnvioDAO envioDAO;
    private DireccionDAO direccionDAO;
    private PagoTransferenciaDAO pagoTransferenciaDAO;
    private ComprobantePagoDAO comprobantePagoDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        metodoEnvioDAO = new MetodoEnvioDAO();
        carritoComprasDAO = new CarritoComprasDAO();
        pedidoDAO = new PedidoDAO();
        envioDAO = new EnvioDAO();
        direccionDAO = new DireccionDAO();
        pagoTransferenciaDAO = new PagoTransferenciaDAO();
        comprobantePagoDAO = new ComprobantePagoDAO();
    }

    /**
     * Maneja las solicitudes GET
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        try {
            if ("procesarCompraPedido".equals(action)) {
                // Paso 1: El comprador solicita Procesar Compra (viene de redirect)
                procesarCompraPedido(request, response);
            } else if ("aprobarPago".equals(action)) {
                // Paso 8: El administrador solicita Aprobar Pago (viene del correo)
                aprobarPago(request, response);
            } else if ("rechazarPago".equals(action)) {
                // Flujo alterno 10.1: Rechazar pago (viene del correo)
                rechazarPago(request, response);
            } else if ("continuar".equals(action)) {
                // Paso 10: El comprador solicita continuar
                continuar(request, response);
            } else if (action == null || "solicitarProcesarPedido".equals(action)) {
                // Flujo antiguo
                solicitarProcesarPedido(request, response);
            } else {
                solicitarProcesarPedido(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error: " + e.getMessage());
            System.err.println("❌ Error en doGet: " + e.getMessage());
            e.printStackTrace();
            mostrarMensajeAgradecimiento(request, response);
        }
    }

    /**
     * Maneja las solicitudes POST
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        try {
            if ("procesarCompraPedido".equals(action)) {
                // Paso 1: El comprador solicita Procesar Compra
                procesarCompraPedido(request, response);
            } else if ("adjuntarComprobante".equals(action)) {
                // Paso 3: El comprador adjunta comprobante
                adjuntarComprobante(request, response);
            } else if ("confirmarTransferencia".equals(action)) {
                // Paso 5: El comprador solicita Confirmar Transferencia
                confirmarTransferencia(request, response);
            } else if ("aprobarPago".equals(action)) {
                // Paso 8: El administrador solicita Aprobar Pago
                aprobarPago(request, response);
            } else if ("rechazarPago".equals(action)) {
                // Flujo alterno 10.1: Rechazar pago por inconsistencia
                rechazarPago(request, response);
            } else if ("continuar".equals(action)) {
                // Paso 10: El comprador solicita continuar
                continuar(request, response);
            } else if ("seguirComprando".equals(action)) {
                // Flujo alterno 12.1: Seguir comprando
                seguirComprando(request, response);
            } else if ("volverAlInicio".equals(action)) {
                // Flujo alterno 12.2: Volver al inicio
                volverAlInicio(request, response);
            } else {
                procesarCompraPedido(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error al procesar: " + e.getMessage());
            mostrarMensajeAgradecimiento(request, response);
        }
    }

    // =========================================================================
    // MÉTODO 1: solicitarProcesarPedido() - Diagrama de robustez paso 1
    // =========================================================================
    /**
     * Solicita procesar el pedido.
     * Diagrama de secuencia:
     * 1: solicitarProcesarPedido() : void
     * 1.1: obtenerMetodoDeEnvio() : List<MetodoEnvio>
     * 1.2: mostrarFormularioDatosEntrega() : void
     */
    private void solicitarProcesarPedido(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
        
        // Verificar que hay productos en el carrito
        if (carrito == null || carrito.estaVacio()) {
            request.setAttribute("error", "El carrito está vacío. Agregue productos antes de procesar el pedido.");
            response.sendRedirect(request.getContextPath() + "/GestionarCarrito");
            return;
        }
        
        // 1.1: obtenerMetodoDeEnvio() : List<MetodoEnvio>
        List<MetodoEnvio> metodosEnvio = metodoEnvioDAO.obtenerMetodoDeEnvio();
        request.setAttribute("metodosEnvio", metodosEnvio);
        
        // Obtener direcciones del comprador si está logueado
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        if (usuario != null && usuario instanceof Comprador) {
            Comprador comprador = (Comprador) usuario;
            request.setAttribute("direccionesComprador", comprador.getDirecciones());
        }
        
        // Calcular totales para mostrar
        double subtotal = carrito.getSubtotal();
        double iva = subtotal * 0.15;
        double envio = 5.00;
        double total = subtotal + iva + envio;
        
        request.setAttribute("carrito", carrito);
        request.setAttribute("subtotal", subtotal);
        request.setAttribute("iva", iva);
        request.setAttribute("costoEnvio", envio);
        request.setAttribute("total", total);
        
        // 1.2: mostrarFormularioDatosEntrega() : void
        request.getRequestDispatcher("/vista/FormularioDatosEntrega.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO 2: ingresarDatosEntrega() - Diagrama de robustez paso 4
    // =========================================================================
    /**
     * Procesa los datos de entrega ingresados.
     * Diagrama de secuencia:
     * 2: ingresarDatosEntrega(nombredestinatario, fechaentrega, telefono, direccion, metodoenvio)
     * 2.1: obtenerCarritoDeCompras() : CarritoCompras
     * 2.2: mostrarResumenDePedido() : void
     */
    private void ingresarDatosEntrega(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        
        // Obtener parámetros del formulario
        String nombredestinatario = request.getParameter("nombredestinatario");
        String telefono = request.getParameter("telefono");
        String fechaentregaStr = request.getParameter("fechaentrega");
        String metodoenvioId = request.getParameter("metodoenvio");
        
        // Datos de dirección
        String calle = request.getParameter("calle");
        String ciudad = request.getParameter("ciudad");
        String provincia = request.getParameter("provincia");
        String codigoPostal = request.getParameter("codigoPostal");
        String referencia = request.getParameter("referencia");
        
        // Validar datos obligatorios
        if (nombredestinatario == null || nombredestinatario.trim().isEmpty() ||
            telefono == null || telefono.trim().isEmpty() ||
            fechaentregaStr == null || fechaentregaStr.trim().isEmpty() ||
            metodoenvioId == null || metodoenvioId.trim().isEmpty()) {
            
            request.setAttribute("error", "Todos los campos obligatorios deben ser completados.");
            solicitarProcesarPedido(request, response);
            return;
        }
        
        // Parsear fecha de entrega
        Date fechaentrega;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            fechaentrega = sdf.parse(fechaentregaStr);
        } catch (ParseException e) {
            request.setAttribute("error", "Formato de fecha inválido.");
            solicitarProcesarPedido(request, response);
            return;
        }
        
        // Crear dirección de entrega
        Direccion direccion = new Direccion(calle, provincia, ciudad, codigoPostal, referencia);
        
        // Obtener método de envío
        MetodoEnvio metodoEnvio = metodoEnvioDAO.obtenerPorId(Integer.parseInt(metodoenvioId));
        
        // Guardar datos en sesión para el siguiente paso
        session.setAttribute("nombredestinatario", nombredestinatario);
        session.setAttribute("telefono", telefono);
        session.setAttribute("fechaentrega", fechaentrega);
        session.setAttribute("direccionEntrega", direccion);
        session.setAttribute("metodoEnvio", metodoEnvio);
        
        // 2.1: obtenerCarritoDeCompras() : CarritoCompras
        CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
        carrito = carritoComprasDAO.obtenerCarritoDeCompras(carrito);
        
        // Calcular totales
        double subtotal = carrito.getSubtotal();
        double iva = subtotal * 0.15;
        double costoEnvio = metodoEnvio != null ? metodoEnvio.getCosto() : 5.00;
        double total = subtotal + iva + costoEnvio;
        
        request.setAttribute("carrito", carrito);
        request.setAttribute("subtotal", subtotal);
        request.setAttribute("iva", iva);
        request.setAttribute("costoEnvio", costoEnvio);
        request.setAttribute("total", total);
        request.setAttribute("nombredestinatario", nombredestinatario);
        request.setAttribute("telefono", telefono);
        request.setAttribute("fechaentrega", fechaentrega);
        request.setAttribute("direccion", direccion);
        request.setAttribute("metodoEnvio", metodoEnvio);
        
        // 2.2: mostrarResumenDePedido() : void
        request.getRequestDispatcher("/vista/ResumenPedido.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO 3: procesarCompra() - Diagrama de robustez paso 7
    // =========================================================================
    /**
     * Procesa la compra del pedido.
     * Según diagrama: +procesarCompraPedido() : void
     * Diagrama de secuencia:
     * 3: procesarCompra() : void
     * 3.1: enviarPedido(pedido : Pedido) : void
     * 3.2: guardarPedido(...) : boolean
     * 3.3: guardarInfoEnvio(...) : boolean
     * 3.4: guardarDireccionPedido(...) : boolean
     */
    private void procesarCompra(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        
        // Recuperar datos de la sesión
        String nombredestinatario = (String) session.getAttribute("nombredestinatario");
        String telefono = (String) session.getAttribute("telefono");
        Date fechaentrega = (Date) session.getAttribute("fechaentrega");
        Direccion direccion = (Direccion) session.getAttribute("direccionEntrega");
        MetodoEnvio metodoEnvio = (MetodoEnvio) session.getAttribute("metodoEnvio");
        CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        
        // Validar datos
        if (carrito == null || carrito.estaVacio()) {
            request.setAttribute("error", "El carrito está vacío.");
            response.sendRedirect(request.getContextPath() + "/GestionarCarrito");
            return;
        }
        
        // Calcular totales
        double subtotal = carrito.getSubtotal();
        double iva = subtotal * 0.15;
        double costoEnvio = metodoEnvio != null ? metodoEnvio.getCosto() : 5.00;
        double total = subtotal + iva + costoEnvio;
        
        // Crear envío
        Envio envio = new Envio(nombredestinatario, telefono, fechaentrega);
        envio.setMetodoEnvio(metodoEnvio);
        envio.setDireccionEntrega(direccion);
        
        // 3.3: guardarInfoEnvio(nombredestinatario, telefono, fechaentrega) : boolean
        envioDAO.guardarInfoEnvio(nombredestinatario, telefono, fechaentrega);
        
        // Crear pedido
        Pedido pedido = new Pedido();
        pedido.setSubtotal(subtotal);
        pedido.setImpuestos(iva);
        pedido.setTotal(total);
        pedido.setEnvio(envio);
        pedido.setEstado("PENDIENTE");
        
        // Asignar comprador si está logueado
        if (usuario != null && usuario instanceof Comprador) {
            pedido.setComprador((Comprador) usuario);
            direccion.setComprador((Comprador) usuario);
        }
        
        // Enviar items del carrito al pedido
        enviarItemsCarrito(carrito);
        
        // 3.1: enviarPedido(pedido : Pedido) : void
        // 3.2: guardarPedido(...) : boolean
        enviarPedido(pedido);
        
        Comprador comprador = (usuario != null && usuario instanceof Comprador) ? (Comprador) usuario : null;
        boolean guardadoExitoso = pedidoDAO.guardarPedido(pedido, comprador);
        Pedido pedidoGuardado = guardadoExitoso ? pedidoDAO.obtenerPedido() : null;
        
        if (pedidoGuardado != null) {
            // 3.4: guardarDireccionPedido(idPedido, direccion) : boolean
            direccionDAO.guardarDireccionPedido(pedidoGuardado.getIdPedido(), direccion);
            
            // Vaciar el carrito después de procesar
            carritoComprasDAO.quitarTodosLosItems(carrito);
            session.setAttribute("carritoCompras", carrito);
            
            // Limpiar datos de sesión del pedido
            session.removeAttribute("nombredestinatario");
            session.removeAttribute("telefono");
            session.removeAttribute("fechaentrega");
            session.removeAttribute("direccionEntrega");
            session.removeAttribute("metodoEnvio");
            
            // Guardar pedido en sesión para mostrar confirmación
            session.setAttribute("pedidoConfirmado", pedidoGuardado);
            
            request.setAttribute("pedido", pedidoGuardado);
            request.setAttribute("mensaje", "¡Pedido procesado exitosamente! Número de pedido: " + pedidoGuardado.getNumeroPedido());
            
            // Mostrar mensaje de agradecimiento
            request.getRequestDispatcher("/vista/MensajeAgradecimiento.jsp").forward(request, response);
        } else {
            request.setAttribute("error", "Error al procesar el pedido. Por favor, intente nuevamente.");
            solicitarProcesarPedido(request, response);
        }
    }

    // =========================================================================
    // MÉTODO 7: adjuntarComprobante(imagen) - Paso 3 del flujo
    // =========================================================================
    /**
     * Paso 3: El comprador revisa la información del pedido y realiza la acción adjuntar comprobante
     * Paso 4: El sistema valida el comprobante cargado, si es correcto el formato muestra un mensaje de éxito
     * Flujo alterno 5.2: Comprobante de pago inválido
     */
    private void adjuntarComprobante(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        Pedido pedido = (Pedido) session.getAttribute("pedidoActual");
        
        if (pedido == null) {
            pedido = (Pedido) session.getAttribute("pedidoConfirmado");
        }
        
        if (pedido == null) {
            request.setAttribute("error", "No se encontró el pedido.");
            response.sendRedirect(request.getContextPath() + "/vista/MensajeAgradecimiento.jsp");
            return;
        }
        
        try {
            // Paso 4: Validar el comprobante cargado
            Part filePart = request.getPart("imagen");
            
            // Flujo alterno 5.1.1: El comprador no adjunta el comprobante
            if (filePart == null || filePart.getSize() == 0) {
                // 5.1.4: El sistema solicita subir el comprobante para continuar
                request.setAttribute("error", "Debe adjuntar un comprobante para continuar. Por favor, seleccione un archivo.");
                request.setAttribute("pedido", pedido);
                mostrarResumenDePedido(request, response, pedido, (CarritoCompras) session.getAttribute("carritoCompras"));
                return;
            }
            
            // Paso 4: Validar formato del archivo
            String contentType = filePart.getContentType();
            String fileName = filePart.getSubmittedFileName();
            
            // Flujo alterno 5.2.1: El comprador sube un archivo con formato no permitido
            String[] formatosPermitidos = {"image/jpeg", "image/jpg", "image/png", "application/pdf"};
            boolean formatoValido = false;
            for (String formato : formatosPermitidos) {
                if (contentType != null && contentType.equalsIgnoreCase(formato)) {
                    formatoValido = true;
                    break;
                }
            }
            
            if (!formatoValido) {
                // 5.2.2: El sistema detecta el error
                // 5.2.3: El sistema informa que el comprobante no es válido
                // 5.2.4: El sistema solicita cargar nuevamente el archivo
                request.setAttribute("error", "El comprobante no es válido. Formatos permitidos: JPG, PNG, PDF. Por favor, cargue nuevamente el archivo.");
                request.setAttribute("pedido", pedido);
                mostrarResumenDePedido(request, response, pedido, (CarritoCompras) session.getAttribute("carritoCompras"));
                return;
            }
            
            // Validar tamaño del archivo (máx 10MB)
            if (filePart.getSize() > 10 * 1024 * 1024) {
                request.setAttribute("error", "El archivo es demasiado grande. Tamaño máximo: 10MB. Por favor, cargue un archivo más pequeño.");
                request.setAttribute("pedido", pedido);
                mostrarResumenDePedido(request, response, pedido, (CarritoCompras) session.getAttribute("carritoCompras"));
                return;
            }
            
            // Paso 4: Si es correcto el formato, continuar con el proceso
            // Leer la imagen
            InputStream fileContent = filePart.getInputStream();
            byte[] imagenBytes = fileContent.readAllBytes();
            
            // Obtener datos del pago
            String banco = request.getParameter("banco");
            String titular = request.getParameter("titular");
            String numeroCuenta = request.getParameter("numeroCuenta");
            String tipoCuenta = request.getParameter("tipoCuenta");
            String ruc = request.getParameter("ruc");
            String numeroComprobante = request.getParameter("numeroComprobante");
            
            System.out.println("🔍 DEBUG - Datos recibidos del formulario:");
            System.out.println("   - Banco: " + banco);
            System.out.println("   - Titular: " + titular);
            System.out.println("   - Número Cuenta: " + numeroCuenta);
            System.out.println("   - Tipo Cuenta: " + tipoCuenta);
            System.out.println("   - RUC: " + ruc);
            System.out.println("   - Número Comprobante: " + numeroComprobante);
            System.out.println("   - Archivo: " + fileName + " (" + contentType + ")");
            
            Usuario usuario = (Usuario) session.getAttribute("usuario");
            String nombreComprador = usuario != null ? usuario.getNombre() : "Cliente";
            
            // PASO 3-4: Solo validar y guardar TEMPORALMENTE en sesión
            // NO guardamos en BD hasta que confirme la transferencia
            
            // Crear objetos temporales
            PagoTransferencia pagoTemporal = new PagoTransferencia(
                pedido.getTotal(), 
                banco, 
                titular, 
                numeroCuenta, 
                tipoCuenta, 
                ruc
            );
            pagoTemporal.setPedido(pedido);
            pagoTemporal.setEstado("PENDIENTE");
            
            ComprobantePago comprobanteTemporal = new ComprobantePago(nombreComprador, numeroComprobante, new Date());
            comprobanteTemporal.setImagen(imagenBytes);
            comprobanteTemporal.setNombreArchivo(fileName);
            comprobanteTemporal.setTipoMime(contentType);
            comprobanteTemporal.setPagoTransferencia(pagoTemporal);
            
            // Guardar TEMPORALMENTE en sesión (no en BD)
            session.setAttribute("pagoTemporal", pagoTemporal);
            session.setAttribute("comprobanteTemporal", comprobanteTemporal);
            session.setAttribute("comprobanteAdjuntado", true); // Flag para validación
            
            System.out.println("✓ Comprobante validado y guardado temporalmente en sesión");
            
            // PASO 4: Mostrar mensaje de éxito - el formato es válido
            request.setAttribute("mensajeExito", "✓ Comprobante validado correctamente. Formato: " + contentType + ". Tamaño: " + (filePart.getSize() / 1024) + " KB. Ahora puede confirmar la transferencia.");
            request.setAttribute("comprobanteValido", true);
            mostrarMensajeExito(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("❌ Error al adjuntar comprobante: " + e.getMessage());
            request.setAttribute("error", "Error al adjuntar comprobante: " + e.getMessage());
            request.setAttribute("pedido", pedido);
            mostrarResumenDePedido(request, response, pedido, (CarritoCompras) session.getAttribute("carritoCompras"));
        }
    }

    // =========================================================================
    // MÉTODO 8: mostrarMensajeExito() - Diagrama de secuencia paso 6
    // =========================================================================
    /**
     * Muestra mensaje de éxito tras adjuntar comprobante
     * Según diagrama: 6: mostrarMensajeExito() : void
     */
    private void mostrarMensajeExito(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setAttribute("mensajeExito", "Comprobante adjuntado exitosamente. Se ha enviado al administrador para su revisión.");
        request.getRequestDispatcher("/vista/MensajeExito.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO 9: confirmarTransferencia() - Paso 5-6 del flujo
    // =========================================================================
    /**
     * Paso 5: El comprador solicita Confirmar Transferencia
     * Paso 6: El sistema espera la verificación de la transferencia y actualiza 
     * el estado de pedido a PENDIENTE y envía el comprobante al correo electrónico del administrador
     * Flujo alterno 5.1: No subir comprobante de pago
     */
    private void confirmarTransferencia(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        Pedido pedido = (Pedido) session.getAttribute("pedidoActual");
        
        // Obtener datos TEMPORALES de la sesión
        PagoTransferencia pagoTemporal = (PagoTransferencia) session.getAttribute("pagoTemporal");
        ComprobantePago comprobanteTemporal = (ComprobantePago) session.getAttribute("comprobanteTemporal");
        Boolean comprobanteAdjuntado = (Boolean) session.getAttribute("comprobanteAdjuntado");
        
        System.out.println("🔍 DEBUG - confirmarTransferencia:");
        System.out.println("   - Pedido: " + (pedido != null ? pedido.getIdPedido() : "null"));
        System.out.println("   - Pago temporal: " + (pagoTemporal != null ? "Sí" : "No"));
        System.out.println("   - Comprobante temporal: " + (comprobanteTemporal != null ? "Sí" : "No"));
        System.out.println("   - Flag adjuntado: " + comprobanteAdjuntado);
        
        // Flujo alterno 5.1.1: El comprador no adjunta el comprobante
        if (comprobanteAdjuntado == null || !comprobanteAdjuntado || comprobanteTemporal == null || pagoTemporal == null) {
            // 5.1.3: El sistema bloquea el proceso
            // 5.1.4: El sistema solicita subir el comprobante para continuar
            System.err.println("❌ Proceso bloqueado: No hay comprobante adjuntado");
            request.setAttribute("error", "Debe adjuntar un comprobante antes de confirmar la transferencia. El proceso ha sido bloqueado.");
            request.setAttribute("pedido", pedido);
            mostrarResumenDePedido(request, response, pedido, (CarritoCompras) session.getAttribute("carritoCompras"));
            return;
        }
        
        if (pedido == null) {
            request.setAttribute("error", "No se encontró el pedido.");
            response.sendRedirect(request.getContextPath() + "/vista/PanelDeComprador.jsp");
            return;
        }
        
        try {
            // PASO 5-6: AHORA SÍ GUARDAR EN BASE DE DATOS
            System.out.println("✓ Paso 5: Comprador confirma transferencia");
            System.out.println("✓ Paso 6: Guardando pago en BD...");
            
            // Guardar el pago en BD
            boolean pagoGuardado = pagoTransferenciaDAO.guardarPago(pagoTemporal, pedido);
            
            if (!pagoGuardado) {
                throw new Exception("No se pudo guardar el pago en la base de datos");
            }
            
            System.out.println("✓ Pago guardado en BD con ID: " + pagoTemporal.getIdPago());
            
            // Asociar el comprobante al pago guardado
            comprobanteTemporal.setPagoTransferencia(pagoTemporal);
            
            // Guardar el comprobante en BD
            boolean comprobanteGuardado = comprobantePagoDAO.guardarComprobante(comprobanteTemporal, pagoTemporal);
            
            if (!comprobanteGuardado) {
                throw new Exception("No se pudo guardar el comprobante en la base de datos");
            }
            
            System.out.println("✓ Comprobante guardado en BD con ID: " + comprobanteTemporal.getIdComprobante());
            
            // Paso 6: Actualizar el estado de pedido a PENDIENTE
            actualizarEstadoPedidoestadoPedido("PENDIENTE");
            pedido.setEstado("PENDIENTE");
            System.out.println("✓ Estado del pedido actualizado a: PENDIENTE");
            
            // Actualizar estado del pago
            pagoTransferenciaDAO.actualizarEstadoPago(pagoTemporal.getIdPago(), "PENDIENTE");
            pagoTemporal.setEstado("PENDIENTE");
            
            // Guardar en sesión como datos FINALES
            session.setAttribute("pagoActual", pagoTemporal);
            session.setAttribute("comprobanteActual", comprobanteTemporal);
            
            // Limpiar datos temporales
            session.removeAttribute("pagoTemporal");
            session.removeAttribute("comprobanteTemporal");
            
            // Paso 6: Enviar el comprobante al correo electrónico del administrador
            System.out.println("✓ Paso 6: Enviando comprobante al administrador...");
            String urlBase = request.getScheme() + "://" + request.getServerName() + ":" + 
                            request.getServerPort() + request.getContextPath();
            
            boolean correoEnviado = EmailUtil.enviarComprobanteConBotones(
                "rochaximena1502@gmail.com", 
                pagoTemporal, 
                comprobanteTemporal, 
                pedido, 
                urlBase
            );
            
            if (correoEnviado) {
                System.out.println("✓✓✓ Paso 6 COMPLETADO: Correo enviado al administrador");
                request.setAttribute("mensaje", "✓ Transferencia confirmada exitosamente. El comprobante ha sido enviado al administrador para su revisión. Estado del pedido: PENDIENTE.");
            } else {
                System.err.println("⚠ Advertencia: Correo no enviado, pero pago guardado");
                request.setAttribute("mensaje", "Transferencia confirmada. El pago fue guardado pero hubo un problema al enviar el correo. Estado del pedido: PENDIENTE.");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("❌ Error en confirmarTransferencia: " + e.getMessage());
            request.setAttribute("error", "Error al confirmar transferencia: " + e.getMessage());
        }
        
        // Mostrar mensaje de confirmación al comprador
        mostrarMensajeAgradecimiento(request, response);
    }

    // =========================================================================
    // MÉTODO 10: actualizarEstadoPedidoestadoPedido() - Diagrama de secuencia paso 8
    // =========================================================================
    /**
     * Actualiza el estado del pedido
     * Según diagrama: 8: actualizarEstadoPedidoestadoPedido(estadopedido : String) : void
     */
    private void actualizarEstadoPedidoestadoPedido(String estadoPedido) {
        pedidoDAO.actualizarEstadoPedido(estadoPedido);
        System.out.println("✓ Estado del pedido actualizado a: " + estadoPedido);
    }

    // =========================================================================
    // MÉTODO 11: aprobarPago() - Paso 8-9 del flujo
    // =========================================================================
    /**
     * Paso 7: El administrador revisa el comprobante recibido
     * Paso 8: El administrador solicita Aprobar Pago
     * Paso 9: El sistema muestra el mensaje pago exitoso y genera un comprobante
     * Flujo alterno 10.1: Rechazar pago por inconsistencia
     */
    private void aprobarPago(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String idPagoStr = request.getParameter("idPago");
        
        if (idPagoStr != null) {
            try {
                Integer idPago = Integer.parseInt(idPagoStr);
                PagoTransferencia pago = pagoTransferenciaDAO.obtenerPorId(idPago);
                
                if (pago != null && pago.getPedido() != null) {
                    // Paso 8: Aprobar el pago
                    pagoTransferenciaDAO.actualizarEstadoPago(idPago, "APROBADO");
                    pago.setEstado("APROBADO");
                    
                    // Actualizar estado del pedido
                    pedidoDAO.actualizarEstadoPedido("PAGO_APROBADO");
                    pago.getPedido().setEstado("PAGO_APROBADO");
                    
                    // Paso 9: Generar un comprobante de pago aprobado
                    ComprobantePago comprobanteAprobacion = comprobantePagoDAO.generarComprobante(
                        pago.getPedido().getComprador() != null ? pago.getPedido().getComprador().getNombre() : "Cliente",
                        "APROBACION-" + pago.getIdPago() + "-" + System.currentTimeMillis(),
                        new Date()
                    );
                    
                    System.out.println("✓ Paso 9: Comprobante de aprobación generado: " + comprobanteAprobacion.getNumeroComprobante());
                    
                    // Enviar notificación al comprador
                    if (pago.getPedido().getComprador() != null) {
                        EmailUtil.enviarNotificacionAprobacion(
                            pago.getPedido().getComprador().getCorreoElectronico(), 
                            pago.getPedido()
                        );
                    }
                    
                    // Paso 9: Mostrar mensaje de pago exitoso
                    request.setAttribute("mensaje", "✓ PAGO EXITOSO - El pago ha sido aprobado correctamente. Se ha generado el comprobante #" + comprobanteAprobacion.getNumeroComprobante() + " y se ha notificado al comprador.");
                    request.setAttribute("pagoExitoso", true);
                    request.setAttribute("comprobanteGenerado", comprobanteAprobacion);
                } else {
                    request.setAttribute("error", "No se encontró el pago.");
                }
            } catch (NumberFormatException e) {
                request.setAttribute("error", "ID de pago inválido.");
            } catch (Exception e) {
                request.setAttribute("error", "Error al aprobar el pago: " + e.getMessage());
                e.printStackTrace();
            }
        }
        
        // Mostrar confirmación
        request.getRequestDispatcher("/vista/ConfirmacionAprobacion.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO: rechazarPago() - Flujo alterno 10.1
    // =========================================================================
    /**
     * Flujo alterno 10.1: Rechazar pago por inconsistencia
     * 10.1.1: El administrador detecta inconsistencias en el comprobante
     * 10.1.2: El administrador solicita Rechazar Pago
     * 10.1.3: El sistema mantiene el pedido en estado pendiente
     * 10.1.4: El sistema notifica al comprador el rechazo del pago
     */
    private void rechazarPago(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String idPagoStr = request.getParameter("idPago");
        String motivo = request.getParameter("motivo");
        
        if (idPagoStr != null) {
            try {
                Integer idPago = Integer.parseInt(idPagoStr);
                PagoTransferencia pago = pagoTransferenciaDAO.obtenerPorId(idPago);
                
                if (pago != null && pago.getPedido() != null) {
                    // 10.1.2: Rechazar el pago
                    pagoTransferenciaDAO.actualizarEstadoPago(idPago, "RECHAZADO");
                    pago.setEstado("RECHAZADO");
                    
                    // 10.1.3: Mantener el pedido en estado PENDIENTE (no cambiar estado)
                    pedidoDAO.actualizarEstadoPedido("PENDIENTE");
                    pago.getPedido().setEstado("PENDIENTE");
                    System.out.println("✓ Flujo 10.1.3: Pedido mantenido en estado PENDIENTE");
                    
                    // 10.1.4: Notificar al comprador el rechazo del pago
                    if (pago.getPedido().getComprador() != null) {
                        EmailUtil.enviarNotificacionRechazo(
                            pago.getPedido().getComprador().getCorreoElectronico(), 
                            pago.getPedido(),
                            motivo != null ? motivo : "Inconsistencias detectadas en el comprobante de pago"
                        );
                        System.out.println("✓ Flujo 10.1.4: Notificación de rechazo enviada al comprador");
                    }
                    
                    request.setAttribute("mensaje", "Pago rechazado por inconsistencia. El pedido se mantiene en estado PENDIENTE y se ha notificado al comprador.");
                } else {
                    request.setAttribute("error", "No se encontró el pago.");
                }
            } catch (NumberFormatException e) {
                request.setAttribute("error", "ID de pago inválido.");
            }
        }
        
        // Mostrar confirmación
        request.getRequestDispatcher("/vista/ConfirmacionRechazo.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO 12: procesarCompraPedido() - Diagrama de secuencia paso 1
    // =========================================================================
    /**
     * Procesa la compra del pedido (inicio del flujo)
     * Según diagrama: 1: procesarCompraPedido() : void
     */
    private void procesarCompraPedido(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        
        // 2: obtenerPedido() : Pedido
        Pedido pedido = obtenerPedido(session);
        
        if (pedido == null) {
            request.setAttribute("error", "No se encontró un pedido para procesar.");
            response.sendRedirect(request.getContextPath() + "/GestionarCarrito");
            return;
        }
        
        // 3: obtenerCarritoCompras() : carritocompras
        CarritoCompras carrito = obtenerCarritoDeCompras(session);
        
        // Guardar datos en sesión
        session.setAttribute("pedidoActual", pedido);
        session.setAttribute("carritoCompras", carrito);
        
        // 4: mostrarResumenDePedido() : void
        mostrarResumenDePedido(request, response, pedido, carrito);
    }

    // =========================================================================
    // MÉTODO 13: obtenerPedido() - Diagrama de secuencia paso 2
    // =========================================================================
    /**
     * Obtiene el pedido actual
     * Según diagrama: 2: obtenerPedido() : Pedido
     */
    private Pedido obtenerPedido(HttpSession session) {
        // Primero buscar en pedidoActual (viene de ProcesarPedidoServlet)
        Pedido pedido = (Pedido) session.getAttribute("pedidoActual");
        
        // Si no está, buscar en pedidoConfirmado
        if (pedido == null) {
            pedido = (Pedido) session.getAttribute("pedidoConfirmado");
        }
        
        // Si aún no está, intentar obtener el último pedido de BD
        if (pedido == null) {
            pedido = pedidoDAO.obtenerPedido();
        }
        
        return pedido;
    }

    // =========================================================================
    // MÉTODO 14: obtenerCarritoDeCompras() - Diagrama de secuencia paso 3
    // =========================================================================
    /**
     * Obtiene el carrito de compras
     * Según diagrama: 3: obtenerCarritoCompras() : carritocompras
     */
    private CarritoCompras obtenerCarritoDeCompras(HttpSession session) {
        CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
        if (carrito != null) {
            carrito = carritoComprasDAO.obtenerCarritoDeCompras(carrito);
        }
        return carrito;
    }

    // =========================================================================
    // MÉTODO 15: mostrarResumenDePedido() - Paso 2 del flujo
    // =========================================================================
    /**
     * Paso 2: El sistema muestra el detalle del pedido y los datos bancarios
     * a los que se debe realizar el pago
     */
    private void mostrarResumenDePedido(HttpServletRequest request, HttpServletResponse response, 
                                        Pedido pedido, CarritoCompras carrito) 
            throws ServletException, IOException {
        
        // Datos del pedido
        request.setAttribute("pedido", pedido);
        request.setAttribute("carrito", carrito);
        request.setAttribute("subtotal", pedido != null ? pedido.getSubtotal() : 0.0);
        request.setAttribute("iva", pedido != null ? pedido.getImpuestos() : 0.0);
        request.setAttribute("total", pedido != null ? pedido.getTotal() : 0.0);
        
        // Paso 2: Datos bancarios de la empresa (donde el comprador debe transferir)
        request.setAttribute("datosBancarios_banco", "Banco Pichincha");
        request.setAttribute("datosBancarios_titular", "Bebelandia S.A.");
        request.setAttribute("datosBancarios_cuenta", "2100456789");
        request.setAttribute("datosBancarios_tipoCuenta", "Corriente");
        request.setAttribute("datosBancarios_ruc", "1790123456001");
        request.setAttribute("datosBancarios_email", "pagos@bebelandia.com");
        
        // Redirigir a la vista de adjuntar comprobante
        request.getRequestDispatcher("/vista/AdjuntarComprobante.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO 16: continuar() - Paso 10 del flujo
    // =========================================================================
    /**
     * Paso 10: El comprador solicita continuar
     * Paso 11: El sistema actualiza el estado de pedido a finalizado
     */
    private void continuar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        Pedido pedido = (Pedido) session.getAttribute("pedidoActual");
        
        if (pedido != null) {
            // Paso 11: Actualizar estado de pedido a FINALIZADO
            pedidoDAO.actualizarEstadoPedido("FINALIZADO");
            pedido.setEstado("FINALIZADO");
            System.out.println("✓ Estado del pedido actualizado a: FINALIZADO");
        }
        
        // Paso 12: mostrarMensajeAgradecimiento() : void
        mostrarMensajeAgradecimiento(request, response);
    }

    // =========================================================================
    // MÉTODO 17: mostrarMensajeAgradecimiento() - Paso 12 del flujo
    // =========================================================================
    /**
     * Paso 12: El sistema muestra mensaje de agradecimiento
     */
    private void mostrarMensajeAgradecimiento(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        Pedido pedido = (Pedido) session.getAttribute("pedidoActual");
        
        request.setAttribute("pedido", pedido);
        request.getRequestDispatcher("/vista/MensajeAgradecimiento.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO 18: mostrarComprobanteDePago() - Diagrama de secuencia paso 12
    // =========================================================================
    /**
     * Muestra el comprobante de pago
     * Según diagrama: 12: mostrarComprobanteDePago() : void
     */
    private void mostrarComprobanteDePago(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        ComprobantePago comprobante = (ComprobantePago) session.getAttribute("comprobanteActual");
        
        if (comprobante != null) {
            comprobantePagoDAO.mostrarComprobanteDePago(comprobante.getIdComprobante());
            request.setAttribute("comprobante", comprobante);
        }
        
        request.getRequestDispatcher("/vista/ComprobantePago.jsp").forward(request, response);
    }

    // =========================================================================
    // FLUJOS ALTERNOS
    // =========================================================================
    
    /**
     * Flujo alterno 12.1: Seguir comprando
     * 12.1.1: El comprador solicita Seguir Comprando
     * 12.1.2: El sistema redirige al comprador al catálogo de productos
     */
    private void seguirComprando(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        System.out.println("✓ Flujo alterno 12.1: Seguir comprando");
        response.sendRedirect(request.getContextPath() + "/ControladorCatalogo?accion=explorar");
    }

    /**
     * Flujo alterno 12.2: Volver al inicio
     * 12.2.1: El comprador solicita Volver al Inicio
     * 12.2.2: El sistema retorna al inicio del sistema
     */
    private void volverAlInicio(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        
        System.out.println("✓ Flujo alterno 12.2: Volver al inicio");
        
        // Redirigir según el tipo de usuario
        if (usuario != null && usuario instanceof Comprador) {
            response.sendRedirect(request.getContextPath() + "/vista/PanelDeComprador.jsp");
        } else {
            response.sendRedirect(request.getContextPath() + "/");
        }
    }

    // =========================================================================
    // MÉTODOS AUXILIARES - Del flujo anterior (mantener compatibilidad)
    // =========================================================================
    
    /**
     * Envía los items del carrito para el pedido
     */
    private void enviarItemsCarrito(CarritoCompras carritoCompras) {
        System.out.println("✓ Enviando items del carrito: " + carritoCompras.getItems().size() + " items");
    }

    /**
     * Envía el pedido para su procesamiento
     */
    private void enviarPedido(Pedido pedido) {
        System.out.println("✓ Enviando pedido: " + (pedido != null ? pedido.getNumeroPedido() : "N/A"));
        if (pedido != null) {
            pedido.setEstado("PROCESANDO");
        }
    }
}