package com.modelo.entities;

import java.io.Serializable;

import jakarta.persistence.*;

@Entity
@Table(name = "producto_personalizable")
public class ProductoPersonalizable implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "nombre", nullable = false, length = 255)
    private String nombre;

    @Column(name = "precio", nullable = false)
    private double precio;

    @Column(name = "descripcion", columnDefinition = "TEXT")
    private String descripcion;

    // Store image directly as a BLOB in the database
    @Lob
    @Column(name = "imagen", columnDefinition = "MEDIUMBLOB")
    private byte[] imagen;

    @Column(name = "stock", nullable = false)
    private int stock;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "seccion_id")
    private SeccionDePersonalizacion seccion;

    public ProductoPersonalizable() {}

    public ProductoPersonalizable(String nombre, double precio, String descripcion, byte[] imagen, int stock, SeccionDePersonalizacion seccion) {
        this.nombre = nombre;
        this.precio = precio;
        this.descripcion = descripcion;
        this.imagen = imagen;
        this.stock = stock;
        this.seccion = seccion;
    }

    // Getters y setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public byte[] getImagen() { return imagen; }
    public void setImagen(byte[] imagen) { this.imagen = imagen; }

    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }

    public SeccionDePersonalizacion getSeccion() { return seccion; }
    public void setSeccion(SeccionDePersonalizacion seccion) { this.seccion = seccion; }
}