package com.controlador;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.dao.CarritoComprasDAO;
import com.dao.DireccionDAO;
import com.dao.EnvioDAO;
import com.dao.MetodoEnvioDAO;
import com.dao.PedidoDAO;
import com.modelo.entities.CarritoCompras;
import com.modelo.entities.Comprador;
import com.modelo.entities.Direccion;
import com.modelo.entities.Envio;
import com.modelo.entities.MetodoEnvio;
import com.modelo.entities.Pedido;
import com.modelo.entities.Usuario;

/**
 * ========================================================================
 * CONTROLADOR: ProcesarPedido (Servlet)
 * ========================================================================
 * Implementa el flujo de Procesar Pedido según los diagramas de robustez y secuencia.
 * 
 * Métodos según diagrama de clases del controlador ProcesarPedido:
 * +solicitarProcesarPedido() : void
 * +ingresarDatosEntrega(nombredestinatario : String, fechaentrega : Date, telefono : String, 
 *                       direccion : Direccion, metodoenvio : MetodoEnvio) : void
 * +procesarCompra() : void
 * +enviarItemsCarrito(carritoCompras : CarritoCompras) : void
 * 
 * Flujo según diagrama de robustez:
 * 1: solicitarProcesarPedido
 * 2: obtenerMetodoDeEnvio:metodosenvio
 * 3: mostrarFormularioDatosEntrega
 * 4: ingresarDatosEntrega(nombredestinatario, fechaentrega, telefono, direccion, metodoenvio)
 * 5: obtenerCarritoCompras:carritocompras
 * 6: mostrarResumenDePedido
 * 7: procesarCompra
 * 8: enviarPedido(pedido)
 * 9: guardarPedido(nombredestinatario, fechaentrega, telefono, direccion, metodoenvio)
 * 10: guardarInfoEnvio(nombredestinatario, telefono, fechaentrega)
 * 11: guardarDireccionPedido(idpedido, direccion)
 */
@WebServlet(name = "ProcesarPedidoServlet", urlPatterns = {"/ProcesarPedido"})
public class ProcesarPedidoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private MetodoEnvioDAO metodoEnvioDAO;
    private CarritoComprasDAO carritoComprasDAO;
    private PedidoDAO pedidoDAO;
    private EnvioDAO envioDAO;
    private DireccionDAO direccionDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        metodoEnvioDAO = new MetodoEnvioDAO();
        carritoComprasDAO = new CarritoComprasDAO();
        pedidoDAO = new PedidoDAO();
        envioDAO = new EnvioDAO();
        direccionDAO = new DireccionDAO();
    }

    /**
     * Maneja las solicitudes GET
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        try {
            if (action == null || "solicitarProcesarPedido".equals(action)) {
                // 1: solicitarProcesarPedido
                solicitarProcesarPedido(request, response);
            } else {
                solicitarProcesarPedido(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error: " + e.getMessage());
            solicitarProcesarPedido(request, response);
        }
    }

    /**
     * Maneja las solicitudes POST
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        try {
            if ("ingresarDatosEntrega".equals(action)) {
                // 4: ingresarDatosEntrega
                ingresarDatosEntrega(request, response);
            } else if ("procesarCompra".equals(action)) {
                // 7: procesarCompra
                procesarCompra(request, response);
            } else {
                solicitarProcesarPedido(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error al procesar: " + e.getMessage());
            solicitarProcesarPedido(request, response);
        }
    }

    // =========================================================================
    // MÉTODO 1: solicitarProcesarPedido() - Diagrama de robustez paso 1
    // =========================================================================
    /**
     * Solicita procesar el pedido.
     * Según diagrama controlador: +solicitarProcesarPedido() : void
     * 
     * Diagrama de secuencia:
     * 1: solicitarProcesarPedido() : void
     * 1.1: obtenerMetodoDeEnvio() : List<MetodoEnvio>
     * 1.2: mostrarFormularioDatosEntrega() : void
     */
    private void solicitarProcesarPedido(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
        
        // Verificar que hay productos en el carrito
        if (carrito == null || carrito.estaVacio()) {
            request.setAttribute("error", "El carrito está vacío. Agregue productos antes de procesar el pedido.");
            response.sendRedirect(request.getContextPath() + "/GestionarCarrito");
            return;
        }
        
        // 1.1: obtenerMetodoDeEnvio() : List<MetodoEnvio>
        List<MetodoEnvio> metodosEnvio = metodoEnvioDAO.obtenerMetodoDeEnvio();
        request.setAttribute("metodosEnvio", metodosEnvio);
        
        // Obtener direcciones del comprador si está logueado
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        if (usuario != null && usuario instanceof Comprador) {
            Comprador comprador = (Comprador) usuario;
            // Filtrar direcciones duplicadas por idDireccion y por contenido
            List<Direccion> direccionesUnicas = new ArrayList<>();
            java.util.HashSet<String> claves = new java.util.HashSet<>();
            for (Direccion d : comprador.getDirecciones()) {
                if (d.getIdDireccion() != null) {
                    // Clave única por id y datos principales
                    String clave = d.getIdDireccion() + ":" + (d.getCalle() != null ? d.getCalle() : "") + ":" + (d.getCiudad() != null ? d.getCiudad() : "") + ":" + (d.getProvincia() != null ? d.getProvincia() : "");
                    if (claves.add(clave)) {
                        direccionesUnicas.add(d);
                    }
                }
            }
            request.setAttribute("direccionesComprador", direccionesUnicas);
        }
        
        // Calcular totales para mostrar
        double subtotal = carrito.getSubtotal();
        double iva = subtotal * 0.15;
        // Usar el costo del primer método de envío si existe, de lo contrario usar valor por defecto
        double envio = (metodosEnvio != null && !metodosEnvio.isEmpty()) ? metodosEnvio.get(0).getCosto() : 15.00;
        double total = subtotal + iva + envio;
        
        request.setAttribute("carrito", carrito);
        request.setAttribute("subtotal", subtotal);
        request.setAttribute("iva", iva);
        request.setAttribute("costoEnvio", envio);
        request.setAttribute("total", total);
        
        // 1.2: mostrarFormularioDatosEntrega() : void
        request.getRequestDispatcher("/vista/FormularioDatosEntrega.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO 2: ingresarDatosEntrega() - Diagrama de robustez paso 4
    // =========================================================================
    /**
     * Procesa los datos de entrega ingresados.
     * Según diagrama controlador: +ingresarDatosEntrega(nombredestinatario : String, 
     *     fechaentrega : Date, telefono : String, direccion : Direccion, metodoenvio : MetodoEnvio) : void
     * 
     * Diagrama de secuencia:
     * 2: ingresarDatosEntrega(nombredestinatario, fechaentrega, telefono, direccion, metodoenvio)
     * 2.1: obtenerCarritoDeCompras() : CarritoCompras
     * 2.2: mostrarResumenDePedido() : void
     */
    private void ingresarDatosEntrega(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        
        // Obtener parámetros del formulario
        String nombredestinatario = request.getParameter("nombredestinatario");
        String telefono = request.getParameter("telefono");
        String fechaentregaStr = request.getParameter("fechaentrega");
        String metodoenvioId = request.getParameter("metodoenvio");
        
        // Datos de dirección
        String calle = request.getParameter("calle");
        String ciudad = request.getParameter("ciudad");
        String provincia = request.getParameter("provincia");
        String codigoPostal = request.getParameter("codigoPostal");
        String referencia = request.getParameter("referencia");
        
        // Validar datos obligatorios
        if (nombredestinatario == null || nombredestinatario.trim().isEmpty() ||
            telefono == null || telefono.trim().isEmpty() ||
            fechaentregaStr == null || fechaentregaStr.trim().isEmpty() ||
            metodoenvioId == null || metodoenvioId.trim().isEmpty()) {
            
            request.setAttribute("error", "Todos los campos obligatorios deben ser completados.");
            solicitarProcesarPedido(request, response);
            return;
        }
        
        // Parsear fecha de entrega
        Date fechaentrega;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            fechaentrega = sdf.parse(fechaentregaStr);
        } catch (ParseException e) {
            request.setAttribute("error", "Formato de fecha inválido.");
            solicitarProcesarPedido(request, response);
            return;
        }
        
        // Crear dirección de entrega
        Direccion direccion = new Direccion(calle, provincia, ciudad, codigoPostal, referencia);
        
        // Obtener método de envío
        MetodoEnvio metodoEnvio = metodoEnvioDAO.obtenerPorId(Integer.parseInt(metodoenvioId));
        
        // Guardar datos en sesión para el siguiente paso
        session.setAttribute("nombredestinatario", nombredestinatario);
        session.setAttribute("telefono", telefono);
        session.setAttribute("fechaentrega", fechaentrega);
        session.setAttribute("direccionEntrega", direccion);
        session.setAttribute("metodoEnvio", metodoEnvio);
        
        // 2.1: obtenerCarritoDeCompras() : CarritoCompras
        CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
        carrito = carritoComprasDAO.obtenerCarritoDeCompras(carrito);
        
        // Calcular totales
        double subtotal = carrito.getSubtotal();
        double iva = subtotal * 0.15;
        double costoEnvio = metodoEnvio != null ? metodoEnvio.getCosto() : 15.00;
        double total = subtotal + iva + costoEnvio;
        
        request.setAttribute("carrito", carrito);
        request.setAttribute("subtotal", subtotal);
        request.setAttribute("iva", iva);
        request.setAttribute("costoEnvio", costoEnvio);
        request.setAttribute("total", total);
        request.setAttribute("nombredestinatario", nombredestinatario);
        request.setAttribute("telefono", telefono);
        request.setAttribute("fechaentrega", fechaentrega);
        request.setAttribute("direccion", direccion);
        request.setAttribute("metodoEnvio", metodoEnvio);
        
        // 2.2: mostrarResumenDePedido() : void
        request.getRequestDispatcher("/vista/ResumenPedido.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO 3: procesarCompra() - Diagrama de robustez paso 7
    // =========================================================================
    /**
     * Procesa la compra del pedido.
     * Según diagrama controlador: +procesarCompra() : void
     * 
     * Diagrama de secuencia:
     * 3: procesarCompra() : void
     * 3.1: enviarPedido(pedido : Pedido) : void
     * 3.2: guardarPedido(...) : boolean
     * 3.3: guardarInfoEnvio(...) : boolean
     * 3.4: guardarDireccionPedido(...) : boolean
     */
    private void procesarCompra(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        
        // Recuperar datos de la sesión
        String nombredestinatario = (String) session.getAttribute("nombredestinatario");
        String telefono = (String) session.getAttribute("telefono");
        Date fechaentrega = (Date) session.getAttribute("fechaentrega");
        Direccion direccion = (Direccion) session.getAttribute("direccionEntrega");
        MetodoEnvio metodoEnvio = (MetodoEnvio) session.getAttribute("metodoEnvio");
        CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        
        // Validar que el usuario sea un comprador
        if (usuario == null || !(usuario instanceof Comprador)) {
            request.setAttribute("error", "Debe iniciar sesión como comprador para procesar el pedido.");
            response.sendRedirect(request.getContextPath() + "/GestionarInicioDeSesionServlet");
            return;
        }
        
        Comprador comprador = (Comprador) usuario;
        
        // Validar datos
        if (carrito == null || carrito.estaVacio()) {
            request.setAttribute("error", "El carrito está vacío.");
            response.sendRedirect(request.getContextPath() + "/GestionarCarrito");
            return;
        }
        
        // Validar datos de entrega
        if (nombredestinatario == null || telefono == null || fechaentrega == null || metodoEnvio == null) {
            request.setAttribute("error", "Faltan datos de entrega. Por favor, complete el formulario nuevamente.");
            solicitarProcesarPedido(request, response);
            return;
        }
        
        // Recargar el método de envío desde la base de datos para asegurar que está gestionado
        MetodoEnvio metodoEnvioDb = metodoEnvioDAO.obtenerPorId(metodoEnvio.getIdMetodoEnvio());
        if (metodoEnvioDb == null) {
            request.setAttribute("error", "Método de envío no válido. Seleccione otro método.");
            solicitarProcesarPedido(request, response);
            return;
        }
        
        // Calcular totales
        double subtotal = carrito.getSubtotal();
        double iva = subtotal * 0.15;
        double costoEnvio = metodoEnvioDb.getCosto();
        double total = subtotal + iva + costoEnvio;
        
        try {
            // Asignar el comprador a la dirección si es nueva
            if (direccion != null && direccion.getComprador() == null) {
                direccion.setComprador(comprador);
            }
            
            // Crear envío con datos validados
            Envio envio = new Envio(nombredestinatario, telefono, fechaentrega);
            envio.setMetodoEnvio(metodoEnvioDb);
            envio.setDireccionEntrega(direccion);
            
            // Crear pedido
            Pedido pedido = new Pedido();
            pedido.setSubtotal(subtotal);
            pedido.setImpuestos(iva);
            pedido.setTotal(total);
            pedido.setEnvio(envio);
            pedido.setEstado("PENDIENTE");
            pedido.setComprador(comprador);
            
            // 3.1: enviarPedido(pedido) - A través de enviarItemsCarrito
            enviarItemsCarrito(carrito);
            
            // 3.2: guardarPedido(...) : boolean
            boolean guardadoExitoso = pedidoDAO.guardarPedido(pedido, comprador);
            Pedido pedidoGuardado = guardadoExitoso ? pedidoDAO.obtenerPedido() : null;
            
            if (pedidoGuardado != null && pedidoGuardado.getIdPedido() != null) {
                // Vaciar el carrito después de procesar
                carritoComprasDAO.quitarTodosLosItems(carrito);
                session.setAttribute("carritoCompras", carrito);
                
                // Limpiar datos de sesión del pedido
                session.removeAttribute("nombredestinatario");
                session.removeAttribute("telefono");
                session.removeAttribute("fechaentrega");
                session.removeAttribute("direccionEntrega");
                session.removeAttribute("metodoEnvio");
                
                // Guardar pedido en sesión para mostrar confirmación
                session.setAttribute("pedidoConfirmado", pedidoGuardado);
                
                // Preparar datos para mostrar el resumen del pedido procesado
                request.setAttribute("pedido", pedidoGuardado);
                request.setAttribute("mensaje", "¡Pedido procesado exitosamente! Número de pedido: " + pedidoGuardado.getNumeroPedido());
                request.setAttribute("subtotal", subtotal);
                request.setAttribute("iva", iva);
                request.setAttribute("costoEnvio", costoEnvio);
                request.setAttribute("total", total);
                request.setAttribute("nombredestinatario", nombredestinatario);
                request.setAttribute("telefono", telefono);
                request.setAttribute("fechaentrega", fechaentrega);
                request.setAttribute("direccion", direccion);
                request.setAttribute("metodoEnvio", metodoEnvioDb);
                request.setAttribute("carrito", carrito);
                
                // Guardar también como pedidoActual para el módulo de ProcesarCompra
                session.setAttribute("pedidoActual", pedidoGuardado);
                
                // Redirigir al módulo de ProcesarCompra para adjuntar comprobante
                // Según el diagrama de secuencia, después de procesar el pedido viene el adjuntar comprobante
                response.sendRedirect(request.getContextPath() + "/ProcesarCompra?action=procesarCompraPedido");
            } else {
                request.setAttribute("error", "Error al procesar el pedido. Por favor, intente nuevamente.");
                solicitarProcesarPedido(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("❌ Error al procesar compra: " + e.getMessage());
            request.setAttribute("error", "Error al procesar el pedido: " + e.getMessage());
            solicitarProcesarPedido(request, response);
        }
    }

    // =========================================================================
    // MÉTODO 4: enviarItemsCarrito() - Diagrama de controlador
    // =========================================================================
    /**
     * Envía los items del carrito para procesamiento.
     * Según diagrama controlador: +enviarItemsCarrito(carritoCompras : CarritoCompras) : void
     */
    private void enviarItemsCarrito(CarritoCompras carritoCompras) {
        // Lógica de envío de items del carrito
        System.out.println("✓ Enviando items del carrito para procesamiento");
        System.out.println("  - Total de items: " + carritoCompras.getCantidadItems());
        System.out.println("  - Subtotal: S/ " + carritoCompras.getSubtotal());
    }
}
