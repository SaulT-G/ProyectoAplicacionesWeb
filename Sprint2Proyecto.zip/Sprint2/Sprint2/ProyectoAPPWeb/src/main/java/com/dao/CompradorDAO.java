package com.dao;

import com.modelo.conection.PersistenciaBDD;
import com.modelo.entities.Comprador;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;

import java.util.ArrayList;
import java.util.List;

/**
 * CompradoDAO - Data Access Object para gestionar clientes/compradores
 * Implementa los métodos según el diagrama de clases:
 * - obtenerListadoDeClientes(): List<Comprador>
 * - guardarRegistro(cliente: Comprador): void
 * - actualizarCliente(cliente: Comprador): void
 * - eliminar(cliente: Comprador): void
 * - obtenerDatosCliente(id: int): Comprador
 * - obtenerClientesPorFiltro(filtro: String): List<Comprador>
 */
public class CompradorDAO {

    /**
     * Método 1.2 del diagrama de secuencia: obtenerListadoDeClientes()
     * Obtiene el listado completo de clientes/compradores
     * @return Lista de compradores
     */
    public List<Comprador> obtenerListadoDeClientes() {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        try {
            TypedQuery<Comprador> query = em.createQuery(
                "SELECT c FROM Comprador c", 
                Comprador.class
            );
            return query.getResultList();
        } catch (Exception e) {
            System.err.println("Error al obtener listado de clientes: " + e.getMessage());
            return new ArrayList<>();
        } finally {
            em.close();
        }
    }

    /**
     * Método 2.1.4 del diagrama de secuencia: guardarRegistro(comprador)
     * Guarda un nuevo registro de cliente/comprador
     * @param cliente Comprador a registrar
     */
    public void guardarRegistro(Comprador cliente) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            em.persist(cliente);
            tx.commit();
            System.out.println("✓ Cliente registrado exitosamente: " + cliente.getNombre());
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            System.err.println("❌ Error al guardar registro de cliente: " + e.getMessage());
            throw new RuntimeException("Error al guardar registro de cliente: " + e.getMessage(), e);
        } finally {
            em.close();
        }
    }

    /**
     * Método 2.2.4 del diagrama de secuencia: actualizarCliente(cliente)
     * Actualiza la información de un cliente existente
     * @param cliente Comprador con datos actualizados
     */
    public void actualizarCliente(Comprador cliente) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            em.merge(cliente);
            tx.commit();
            System.out.println("✓ Cliente actualizado exitosamente: " + cliente.getNombre());
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            System.err.println("❌ Error al actualizar cliente: " + e.getMessage());
            throw new RuntimeException("Error al actualizar cliente: " + e.getMessage(), e);
        } finally {
            em.close();
        }
    }

    /**
     * Método 2.3.3 del diagrama de secuencia: eliminar(cliente)
     * Elimina un cliente del sistema
     * @param cliente Comprador a eliminar
     */
    public void eliminar(Comprador cliente) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            // Buscar el cliente gestionado por este EntityManager
            Comprador clienteGestionado = em.find(Comprador.class, cliente.getIdUsuario());
            if (clienteGestionado != null) {
                em.remove(clienteGestionado);
            }
            tx.commit();
            System.out.println("✓ Cliente eliminado exitosamente: " + cliente.getNombre());
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            System.err.println("❌ Error al eliminar cliente: " + e.getMessage());
            throw new RuntimeException("Error al eliminar cliente: " + e.getMessage(), e);
        } finally {
            em.close();
        }
    }

    /**
     * Método 2.4.2 del diagrama de secuencia: obtenerDatosCliente(id)
     * Obtiene los datos de un cliente específico por su ID
     * @param id ID del cliente
     * @return Comprador encontrado o null
     */
    public Comprador obtenerDatosCliente(int id) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        try {
            return em.find(Comprador.class, id);
        } catch (Exception e) {
            System.err.println("Error al obtener datos del cliente: " + e.getMessage());
            return null;
        } finally {
            em.close();
        }
    }

    /**
     * Método 2.5.2 del diagrama de secuencia: obtenerClientesPorFiltro(filtro)
     * Busca clientes aplicando filtros por nombre, correo, estado, provincia o ciudad
     * @param filtro Texto de búsqueda
     * @return Lista de compradores que coinciden con el filtro
     */
    public List<Comprador> obtenerClientesPorFiltro(String filtro) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        try {
            String jpql = "SELECT DISTINCT c FROM Comprador c LEFT JOIN c.direcciones d " +
                          "WHERE LOWER(c.nombre) LIKE LOWER(:filtro) " +
                          "OR LOWER(c.correoElectronico) LIKE LOWER(:filtro) " +
                          "OR LOWER(c.estado) LIKE LOWER(:filtro) " +
                          "OR LOWER(d.provincia) LIKE LOWER(:filtro) " +
                          "OR LOWER(d.ciudad) LIKE LOWER(:filtro)";
            
            TypedQuery<Comprador> query = em.createQuery(jpql, Comprador.class);
            query.setParameter("filtro", "%" + filtro + "%");
            return query.getResultList();
        } catch (Exception e) {
            System.err.println("Error al buscar clientes por filtro: " + e.getMessage());
            return new ArrayList<>();
        } finally {
            em.close();
        }
    }

    /**
     * Verifica si existe un correo electrónico registrado
     * @param correo Correo a verificar
     * @return true si existe, false si no
     */
    public boolean existeCorreo(String correo) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        try {
            TypedQuery<Long> query = em.createQuery(
                "SELECT COUNT(c) FROM Comprador c WHERE c.correoElectronico = :correo",
                Long.class
            );
            query.setParameter("correo", correo);
            return query.getSingleResult() > 0;
        } catch (Exception e) {
            return false;
        } finally {
            em.close();
        }
    }

    /**
     * Verifica si existe un correo registrado excluyendo un ID específico (para actualizaciones)
     * @param correo Correo a verificar
     * @param idExcluir ID del cliente a excluir de la verificación
     * @return true si existe otro cliente con ese correo, false si no
     */
    public boolean existeCorreoExcluyendoId(String correo, int idExcluir) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        try {
            TypedQuery<Long> query = em.createQuery(
                "SELECT COUNT(c) FROM Comprador c WHERE c.correoElectronico = :correo AND c.idUsuario != :id",
                Long.class
            );
            query.setParameter("correo", correo);
            query.setParameter("id", idExcluir);
            return query.getSingleResult() > 0;
        } catch (Exception e) {
            return false;
        } finally {
            em.close();
        }
    }
}
