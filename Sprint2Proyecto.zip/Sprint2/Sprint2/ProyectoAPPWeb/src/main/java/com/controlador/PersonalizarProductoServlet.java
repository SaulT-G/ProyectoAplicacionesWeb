package com.controlador;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.dao.CarritoComprasDAO;
import com.dao.ProductoPersonalizableDAO;
import com.dao.SeccionDePersonalizacionDAO;
import com.modelo.entities.CarritoCompras;
import com.modelo.entities.ItemCarrito;
import com.modelo.entities.ProductoPersonalizable;
import com.modelo.entities.ProductoPersonalizado;
import com.modelo.entities.SeccionDePersonalizacion;

/**
 * CONTROLADOR: PersonalizarProductoServlet
 * 2 métodos según diagrama de robustez
 */
@WebServlet("/PersonalizarProducto")
public class PersonalizarProductoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private SeccionDePersonalizacionDAO seccionDAO;
    private ProductoPersonalizableDAO productoPersonalizableDAO;
    private CarritoComprasDAO carritoComprasDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        seccionDAO = new SeccionDePersonalizacionDAO();
        productoPersonalizableDAO = new ProductoPersonalizableDAO();
        carritoComprasDAO = new CarritoComprasDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        try {
            personalizarMiProducto(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error: " + e.getMessage());
            request.getRequestDispatcher("/vista/error.jsp").forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            // Obtener datos del formulario
            String opcionIdStr = request.getParameter("opcionId");
            String seccionIdStr = request.getParameter("seccionId");
            String accion = request.getParameter("accion");
            
            // Manejar acción de limpiar
            if ("limpiar".equals(accion)) {
                HttpSession session = request.getSession();
                session.setAttribute("opcionesSeleccionadas", new ArrayList<ProductoPersonalizable>());
                session.setAttribute("precioTotal", 0.0);
                request.setAttribute("mensaje", "Selección limpiada exitosamente");
                request.setAttribute("tipoMensaje", "exito");
                personalizarMiProducto(request, response);
                return;
            }
            
            // Manejar acción de agregar al carrito (según diagrama de robustez flujopersonalizarproducto)
            if ("agregarAlCarrito".equals(accion)) {
                agregarPersonalizadoAlCarrito(request, response);
                return;
            }
            
            if (opcionIdStr != null && seccionIdStr != null) {
                int opcionId = Integer.parseInt(opcionIdStr);
                int seccionId = Integer.parseInt(seccionIdStr);
                
                // Obtener opción y sección
                ProductoPersonalizable opcion = productoPersonalizableDAO.obtenerPersonalizable(opcionId);
                SeccionDePersonalizacion seccion = seccionDAO.obtenerPorId(seccionId);
                
                if (opcion != null && seccion != null) {
                    seleccionarOpcionesPorSeccion(request, response, opcion, seccion);
                } else {
                    personalizarMiProducto(request, response);
                }
            } else {
                personalizarMiProducto(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error: " + e.getMessage());
            request.getRequestDispatcher("/vista/error.jsp").forward(request, response);
        }
    }

    /**
     * MÉTODO 1 DEL DIAGRAMA: personalizarMiProducto()
     * Muestra el formulario con todas las secciones y opciones de personalización
     */
    private void personalizarMiProducto(HttpServletRequest request, HttpServletResponse response) 
            throws Exception {
        
        // Obtener todas las secciones con sus productos
        List<SeccionDePersonalizacion> secciones = seccionDAO.obtenerSeccionesPersonalizacion();
        
        // Inicializar sesión si no existe
        HttpSession session = request.getSession();
        if (session.getAttribute("opcionesSeleccionadas") == null) {
            session.setAttribute("opcionesSeleccionadas", new ArrayList<ProductoPersonalizable>());
            session.setAttribute("precioTotal", 0.0);
        }
        
        request.setAttribute("secciones", secciones);
        request.getRequestDispatcher("/vista/FormularioPersonalizacion.jsp").forward(request, response);
    }

    /**
     * MÉTODO 2 DEL DIAGRAMA: seleccionarOpcionesPorSeccion(ProductoPersonalizable, Seccion)
     * Selecciona una opción de personalización para una sección específica
     * Si ya existe una opción de la misma sección, la reemplaza
     */
    @SuppressWarnings("unchecked")
    private void seleccionarOpcionesPorSeccion(HttpServletRequest request, HttpServletResponse response, 
            ProductoPersonalizable opcion, SeccionDePersonalizacion seccion) throws Exception {
        
        HttpSession session = request.getSession();
        
        // Obtener lista de opciones seleccionadas de la sesión
        List<ProductoPersonalizable> opcionesSeleccionadas = 
            (List<ProductoPersonalizable>) session.getAttribute("opcionesSeleccionadas");
        
        if (opcionesSeleccionadas == null) {
            opcionesSeleccionadas = new ArrayList<>();
        }
        
        // Remover opción anterior de la misma sección si existe
        ProductoPersonalizable opcionAnterior = null;
        for (ProductoPersonalizable p : opcionesSeleccionadas) {
            if (p.getSeccion() != null && seccion != null && 
                p.getSeccion().getId().equals(seccion.getId())) {
                opcionAnterior = p;
                break;
            }
        }
        
        if (opcionAnterior != null) {
            opcionesSeleccionadas.remove(opcionAnterior);
        }
        
        // Agregar la nueva opción seleccionada
        opcionesSeleccionadas.add(opcion);
        
        // Calcular precio total
        double precioTotal = 0.0;
        for (ProductoPersonalizable p : opcionesSeleccionadas) {
            precioTotal += p.getPrecio();
        }
        
        // Actualizar sesión
        session.setAttribute("opcionesSeleccionadas", opcionesSeleccionadas);
        session.setAttribute("precioTotal", precioTotal);
        
        // Mensaje de confirmación
        String mensajeTexto;
        if (opcionAnterior != null) {
            mensajeTexto = "Opción de " + seccion.getNombre() + " actualizada: " + opcion.getNombre() + ". Precio total: $" + String.format("%.2f", precioTotal);
        } else {
            mensajeTexto = "Opción de " + seccion.getNombre() + " agregada: " + opcion.getNombre() + ". Precio total: $" + String.format("%.2f", precioTotal);
        }
        
        request.setAttribute("mensaje", mensajeTexto);
        request.setAttribute("tipoMensaje", "exito");
        
        // Redirigir de vuelta al formulario de personalización
        personalizarMiProducto(request, response);
    }

    /**
     * MÉTODO SEGÚN DIAGRAMA DE ROBUSTEZ flujopersonalizarproducto:
     * 1.5: guardarProductoPersonalizado(productopersonalizable, seccion)
     * 1.6: agregarPersonalizadoAlCarrito(itemventaid):itemcarrito
     * 1.7: guardarItemCarrito(itemcarrito)
     * 
     * Crea un ProductoPersonalizado con las opciones seleccionadas y lo agrega al carrito
     */
    @SuppressWarnings("unchecked")
    private void agregarPersonalizadoAlCarrito(HttpServletRequest request, HttpServletResponse response) 
            throws Exception {
        
        HttpSession session = request.getSession();
        
        // Obtener las opciones seleccionadas de la sesión
        List<ProductoPersonalizable> opcionesSeleccionadas = 
            (List<ProductoPersonalizable>) session.getAttribute("opcionesSeleccionadas");
        Double precioTotal = (Double) session.getAttribute("precioTotal");
        
        if (opcionesSeleccionadas == null || opcionesSeleccionadas.isEmpty()) {
            request.setAttribute("error", "Debe seleccionar al menos una opción antes de agregar al carrito");
            request.setAttribute("tipoMensaje", "error");
            personalizarMiProducto(request, response);
            return;
        }
        
        // 1.5: guardarProductoPersonalizado - Crear ProductoPersonalizado
        ProductoPersonalizado productoPersonalizado = new ProductoPersonalizado();
        productoPersonalizado.setNombre("Producto Personalizado");
        productoPersonalizado.setPrecio(precioTotal != null ? precioTotal : 0.0);
        productoPersonalizado.setOpciones(new ArrayList<>(opcionesSeleccionadas));
        
        // Si hay opciones, obtener la primera sección
        if (!opcionesSeleccionadas.isEmpty() && opcionesSeleccionadas.get(0).getSeccion() != null) {
            productoPersonalizado.setSeccion(opcionesSeleccionadas.get(0).getSeccion());
        }
        
        // Obtener o crear el carrito de compras
        CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
        if (carrito == null) {
            carrito = new CarritoCompras();
        }
        
        // 1.6: agregarPersonalizadoAlCarrito(itemventaid):itemcarrito
        ItemCarrito itemCarrito = new ItemCarrito(productoPersonalizado);
        
        // 1.7: guardarItemCarrito(itemcarrito)
        carritoComprasDAO.guardarItemCarrito(carrito, itemCarrito);
        
        // Guardar carrito en sesión
        session.setAttribute("carritoCompras", carrito);
        
        // Limpiar las opciones seleccionadas después de agregar al carrito
        session.setAttribute("opcionesSeleccionadas", new ArrayList<ProductoPersonalizable>());
        session.setAttribute("precioTotal", 0.0);
        
        // Mostrar mensaje de confirmación
        request.setAttribute("mensaje", "✓ Producto personalizado agregado al carrito exitosamente. Total: $" + String.format("%.2f", precioTotal));
        request.setAttribute("tipoMensaje", "exito");
        request.setAttribute("volverUrl", request.getContextPath() + "/PersonalizarProducto");
        request.setAttribute("carritoUrl", request.getContextPath() + "/GestionarCarrito?action=acceder");
        
        request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
    }
}
