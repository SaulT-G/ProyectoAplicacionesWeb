package com.controlador;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.List;

import com.dao.CategoriaDAO;
import com.dao.ProductoDAO;
import com.modelo.entities.Categoria;
import com.modelo.entities.Producto;

/**
 * CONTROLADOR: GestionarProductosServlet
 * 7 métodos según diagrama de robustez
 */
@WebServlet(name = "GestionarProductosServlet", urlPatterns = {"/admin/productos"})
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024,
    maxFileSize = 1024 * 1024 * 5,
    maxRequestSize = 1024 * 1024 * 10
)
public class GestionarProductosServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private ProductoDAO dao;
    private CategoriaDAO categoriaDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        dao = new ProductoDAO();
        categoriaDAO = new CategoriaDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        try {
            if ("add".equals(action)) {
                agregarProducto(request, response);
            } else if ("edit".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                editar(request, response, id);
            } else if ("view".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                ver(request, response, id);
            } else if ("delete".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                eliminar(request, response, id);
            } else {
                solicitarGestionDeProductos(request, response);
            }
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        try {
            if ("insert".equals(action) || "save".equals(action)) {
                registrarNuevoProducto(request, response);
            } else if ("update".equals(action)) {
                actualizarInfoProducto(request, response);
            } else if ("delete".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                eliminar(request, response, id);
            } else {
                solicitarGestionDeProductos(request, response);
            }
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    /**
     * MÉTODO 1 DEL DIAGRAMA: solicitarGestionDeProductos()
     * Lista todos los productos disponibles
     */
    private void solicitarGestionDeProductos(HttpServletRequest request, HttpServletResponse response) 
            throws Exception {
        List<Producto> lista = dao.obtenerListadoDeProductos();
        request.setAttribute("productos", lista);
        request.getRequestDispatcher("/vista/GestionarProductos.jsp").forward(request, response);
    }

    /**
     * MÉTODO 2 DEL DIAGRAMA: agregarProducto()
     * Muestra el formulario para agregar un nuevo producto
     */
    private void agregarProducto(HttpServletRequest request, HttpServletResponse response) 
            throws Exception {
        List<Categoria> categorias = categoriaDAO.obtenerCategorias();
        request.setAttribute("categorias", categorias);
        request.setAttribute("producto", new Producto());
        request.getRequestDispatcher("/vista/formularioNuevoProducto.jsp").forward(request, response);
    }

    /**
     * MÉTODO 3 DEL DIAGRAMA: registrarNuevoProducto(id,nombre,descrip,cat,stock,precio,img)
     * Registra un nuevo producto en la base de datos
     */
    private void registrarNuevoProducto(HttpServletRequest request, HttpServletResponse response) 
            throws Exception {
        
        String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");
        BigDecimal precio = new BigDecimal(request.getParameter("precio"));
        int stock = Integer.parseInt(request.getParameter("stock"));
        int categoriaId = Integer.parseInt(request.getParameter("categoriaId"));
        
        // Obtener categoría de la lista completa
        List<Categoria> categorias = categoriaDAO.obtenerCategorias();
        Categoria categoria = null;
        for (Categoria cat : categorias) {
            if (cat.getId() == categoriaId) {
                categoria = cat;
                break;
            }
        }
        
        // Leer imagen como bytes para guardar en la BD
        byte[] imagen = null;
        Part filePart = request.getPart("imagen");
        if (filePart != null && filePart.getSize() > 0) {
            try (InputStream is = filePart.getInputStream()) {
                imagen = is.readAllBytes();
            }
        }
        
        Producto producto = new Producto();
        producto.setNombre(nombre);
        producto.setDescripcion(descripcion);
        producto.setPrecio(precio);
        producto.setStock(stock);
        producto.setCategoria(categoria);
        producto.setImagen(imagen);
        
        dao.guardar(producto);
        
        response.sendRedirect("productos");
    }

    /**
     * MÉTODO 4 DEL DIAGRAMA: editar(id)
     * Muestra el formulario de actualización con los datos del producto
     */
    private void editar(HttpServletRequest request, HttpServletResponse response, int id) 
            throws Exception {
        Producto producto = dao.obtenerProducto(id);
        List<Categoria> categorias = categoriaDAO.obtenerCategorias();
        request.setAttribute("producto", producto);
        request.setAttribute("categorias", categorias);
        request.getRequestDispatcher("/vista/formularioActualizacion.jsp").forward(request, response);
    }

    /**
     * MÉTODO 5 DEL DIAGRAMA: actualizarInfoProducto(nombre,desc,cat,stock,precio,img)
     * Actualiza la información de un producto existente
     */
    private void actualizarInfoProducto(HttpServletRequest request, HttpServletResponse response) 
            throws Exception {
        
        int id = Integer.parseInt(request.getParameter("id"));
        String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");
        BigDecimal precio = new BigDecimal(request.getParameter("precio"));
        int stock = Integer.parseInt(request.getParameter("stock"));
        int categoriaId = Integer.parseInt(request.getParameter("categoriaId"));
        
        Producto producto = dao.obtenerProducto(id);
        
        // Obtener categoría de la lista completa
        List<Categoria> categorias = categoriaDAO.obtenerCategorias();
        Categoria categoria = null;
        for (Categoria cat : categorias) {
            if (cat.getId() == categoriaId) {
                categoria = cat;
                break;
            }
        }
        
        // Leer imagen como bytes si se sube una nueva
        Part filePart = request.getPart("imagen");
        if (filePart != null && filePart.getSize() > 0) {
            try (InputStream is = filePart.getInputStream()) {
                producto.setImagen(is.readAllBytes());
            }
        }
        
        producto.setNombre(nombre);
        producto.setDescripcion(descripcion);
        producto.setPrecio(precio);
        producto.setStock(stock);
        producto.setCategoria(categoria);
        
        dao.actualizarProducto(producto);
        
        response.sendRedirect("productos");
    }

    /**
     * MÉTODO 6 DEL DIAGRAMA: eliminar(id)
     * Elimina un producto de la base de datos
     */
    private void eliminar(HttpServletRequest request, HttpServletResponse response, int id) 
            throws Exception {
        dao.eliminarProducto(id);
        response.sendRedirect("productos");
    }

    /**
     * MÉTODO 7 DEL DIAGRAMA: ver(id)
     * Muestra los detalles de un producto específico
     */
    private void ver(HttpServletRequest request, HttpServletResponse response, int id) 
            throws Exception {
        Producto producto = dao.obtenerDatosProducto(id);
        request.setAttribute("producto", producto);
        request.getRequestDispatcher("/vista/DetalleProducto.jsp").forward(request, response);
    }

    private String getFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] tokens = contentDisp.split(";");
        for (String token : tokens) {
            if (token.trim().startsWith("filename")) {
                return token.substring(token.indexOf("=") + 2, token.length() - 1);
            }
        }
        return "";
    }
}
