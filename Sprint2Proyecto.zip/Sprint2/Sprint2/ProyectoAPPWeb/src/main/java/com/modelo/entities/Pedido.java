package com.modelo.entities;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * ========================================================================
 * ENTIDAD: Pedido
 * ========================================================================
 * Representa un pedido realizado por un comprador.
 * Según el diagrama de clases:
 * - numeroPedido : String
 * - fechaPedido : Date
 * - estado : String
 * - impuestos : double
 * - subtotal : double
 * - total : double
 * - envio : Envio
 */
@Entity
@Table(name = "pedido")
public class Pedido implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pedido")
    private Integer idPedido;

    @Column(name = "numero_pedido", nullable = false, unique = true, length = 50)
    private String numeroPedido;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "fecha_pedido", nullable = false)
    private Date fechaPedido;

    @Column(name = "estado", nullable = false, length = 30)
    private String estado;

    @Column(name = "impuestos", nullable = false)
    private double impuestos;

    @Column(name = "subtotal", nullable = false)
    private double subtotal;

    @Column(name = "total", nullable = false)
    private double total;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "id_envio")
    private Envio envio;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_comprador", nullable = false)
    private Comprador comprador;

    // Constructores
    public Pedido() {
        this.fechaPedido = new Date();
        this.estado = "PENDIENTE";
    }

    public Pedido(String numeroPedido, double subtotal, double impuestos, double total) {
        this.numeroPedido = numeroPedido;
        this.fechaPedido = new Date();
        this.estado = "PENDIENTE";
        this.subtotal = subtotal;
        this.impuestos = impuestos;
        this.total = total;
    }

    // Getters y Setters
    public Integer getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(Integer idPedido) {
        this.idPedido = idPedido;
    }

    public String getNumeroPedido() {
        return numeroPedido;
    }

    public void setNumeroPedido(String numeroPedido) {
        this.numeroPedido = numeroPedido;
    }

    public Date getFechaPedido() {
        return fechaPedido;
    }

    public void setFechaPedido(Date fechaPedido) {
        this.fechaPedido = fechaPedido;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public double getImpuestos() {
        return impuestos;
    }

    public void setImpuestos(double impuestos) {
        this.impuestos = impuestos;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Envio getEnvio() {
        return envio;
    }

    public void setEnvio(Envio envio) {
        this.envio = envio;
    }

    public Comprador getComprador() {
        return comprador;
    }

    public void setComprador(Comprador comprador) {
        this.comprador = comprador;
    }

    @Override
    public String toString() {
        return "Pedido{" +
                "idPedido=" + idPedido +
                ", numeroPedido='" + numeroPedido + '\'' +
                ", fechaPedido=" + fechaPedido +
                ", estado='" + estado + '\'' +
                ", total=" + total +
                '}';
    }
}
