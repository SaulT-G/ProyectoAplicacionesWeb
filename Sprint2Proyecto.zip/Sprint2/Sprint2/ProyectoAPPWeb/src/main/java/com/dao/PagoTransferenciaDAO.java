package com.dao;

import com.modelo.conection.PersistenciaBDD;
import com.modelo.entities.PagoTransferencia;
import com.modelo.entities.Pedido;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.Date;

/**
 * ========================================================================
 * DAO: PagoTransferenciaDAO
 * ========================================================================
 * Según el diagrama de clases:
 * +guardarPago(int, double, Date, String, String, String, String, String) : boolean
 */
public class PagoTransferenciaDAO {

    /**
     * Guarda un pago por transferencia en la base de datos
     * Según diagrama: +guardarPago(idpago, monto, fechaPago, banco, titular, numerocuenta, tipocuenta, RUC)
     */
    public boolean guardarPago(Integer idPago, Double monto, Date fechaPago, String banco, 
                              String titular, String numeroCuenta, String tipoCuenta, String ruc) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            
            PagoTransferencia pago = new PagoTransferencia();
            pago.setMonto(monto);
            pago.setFechaPago(fechaPago != null ? fechaPago : new Date());
            pago.setBanco(banco);
            pago.setTitular(titular);
            pago.setNumeroCuenta(numeroCuenta);
            pago.setTipoCuenta(tipoCuenta);
            pago.setRuc(ruc);
            pago.setEstado("PENDIENTE");
            
            em.persist(pago);
            tx.commit();
            
            System.out.println("✓ Pago por transferencia guardado exitosamente. ID: " + pago.getIdPago());
            return true;
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            System.err.println("❌ Error al guardar pago por transferencia: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            em.close();
        }
    }
    
    /**
     * Guarda un pago completo asociado a un pedido
     */
    public boolean guardarPago(PagoTransferencia pago, Pedido pedido) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            System.out.println("🔍 DEBUG: Iniciando guardarPago...");
            System.out.println("   - Pedido: " + (pedido != null ? pedido.getIdPedido() : "null"));
            System.out.println("   - Monto: " + (pago != null ? pago.getMonto() : "null"));
            System.out.println("   - Banco: " + (pago != null ? pago.getBanco() : "null"));
            
            tx = em.getTransaction();
            tx.begin();
            
            // Recargar pedido para que esté gestionado
            if (pedido != null && pedido.getIdPedido() != null) {
                System.out.println("🔍 DEBUG: Buscando pedido en BD con ID: " + pedido.getIdPedido());
                Pedido pedidoDb = em.find(Pedido.class, pedido.getIdPedido());
                if (pedidoDb != null) {
                    System.out.println("✓ Pedido encontrado en BD: " + pedidoDb.getNumeroPedido());
                    pago.setPedido(pedidoDb);
                } else {
                    System.err.println("⚠ ADVERTENCIA: Pedido no encontrado en BD con ID: " + pedido.getIdPedido());
                    // Hacer merge del pedido para gestionarlo
                    System.out.println("🔍 DEBUG: Intentando merge del pedido...");
                    Pedido pedidoMerged = em.merge(pedido);
                    pago.setPedido(pedidoMerged);
                }
            } else {
                System.err.println("⚠ ADVERTENCIA: Pedido es null o no tiene ID");
                // Si no hay ID, no podemos asociarlo
                if (pedido == null) {
                    System.err.println("❌ ERROR: No se puede guardar pago sin pedido asociado");
                    return false;
                }
            }
            
            // Asegurar que la fecha de pago esté establecida
            if (pago.getFechaPago() == null) {
                pago.setFechaPago(new Date());
            }
            
            System.out.println("🔍 DEBUG: Persistiendo pago...");
            em.persist(pago);
            
            System.out.println("🔍 DEBUG: Haciendo commit...");
            tx.commit();
            
            System.out.println("✓ Pago guardado exitosamente. ID: " + pago.getIdPago());
            return true;
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
                System.err.println("❌ Transaction rollback ejecutado");
            }
            System.err.println("❌ Error al guardar pago: " + e.getMessage());
            System.err.println("❌ Tipo de excepción: " + e.getClass().getName());
            e.printStackTrace();
            return false;
        } finally {
            em.close();
        }
    }
    
    /**
     * Actualiza el estado de un pago
     */
    public void actualizarEstadoPago(Integer idPago, String nuevoEstado) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            
            PagoTransferencia pago = em.find(PagoTransferencia.class, idPago);
            if (pago != null) {
                pago.setEstado(nuevoEstado);
                em.merge(pago);
            }
            
            tx.commit();
            System.out.println("✓ Estado de pago actualizado a: " + nuevoEstado);
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            System.err.println("❌ Error al actualizar estado de pago: " + e.getMessage());
        } finally {
            em.close();
        }
    }
    
    /**
     * Obtiene un pago por su ID
     */
    public PagoTransferencia obtenerPorId(Integer idPago) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        try {
            return em.find(PagoTransferencia.class, idPago);
        } finally {
            em.close();
        }
    }
}
