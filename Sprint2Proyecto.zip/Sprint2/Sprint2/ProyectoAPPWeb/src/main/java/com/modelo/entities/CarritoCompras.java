package com.modelo.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * ========================================================================
 * ENTIDAD: CarritoCompras
 * ========================================================================
 * Representa el carrito de compras del comprador.
 * Según el diagrama de clases:
 * - total : double
 * - descuento : double
 * - items : List<ItemCarrito>
 */
public class CarritoCompras implements Serializable {
    private static final long serialVersionUID = 1L;

    private double total;
    private double descuento;
    private List<ItemCarrito> items;
    private int contadorItems; // Contador para generar IDs únicos

    // Constructor vacío
    public CarritoCompras() {
        this.items = new ArrayList<>();
        this.total = 0.0;
        this.descuento = 0.0;
        this.contadorItems = 0;
    }

    // Getters y Setters
    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public List<ItemCarrito> getItems() {
        return items;
    }

    public void setItems(List<ItemCarrito> items) {
        this.items = items;
    }

    /**
     * Agrega un item al carrito
     * Si el producto ya existe, incrementa la cantidad
     */
    public void agregarItem(ItemCarrito nuevoItem) {
        // Buscar si ya existe el item
        for (ItemCarrito item : items) {
            if (item.getItem().getId() == nuevoItem.getItem().getId()) {
                item.incrementarCantidad();
                recalcularTotal();
                return;
            }
        }
        // Si no existe, agregar nuevo con ID único
        contadorItems++;
        nuevoItem.setIdItem(contadorItems);
        items.add(nuevoItem);
        recalcularTotal();
    }

    /**
     * Elimina un item del carrito por su ID
     */
    public void eliminarItem(int itemCarritoId) {
        items.removeIf(item -> item.getIdItem() == itemCarritoId);
        recalcularTotal();
    }

    /**
     * Vacía todos los items del carrito
     */
    public void vaciarCarrito() {
        items.clear();
        this.total = 0.0;
    }

    /**
     * Recalcula el total del carrito
     */
    public void recalcularTotal() {
        this.total = 0.0;
        for (ItemCarrito item : items) {
            this.total += item.getSubtotalPorCantidad();
        }
    }

    /**
     * Calcula el subtotal (antes de impuestos)
     */
    public double getSubtotal() {
        double subtotal = 0.0;
        for (ItemCarrito item : items) {
            subtotal += item.getSubtotalPorCantidad();
        }
        return subtotal;
    }

    /**
     * Verifica si el carrito está vacío
     */
    public boolean estaVacio() {
        return items.isEmpty();
    }

    /**
     * Obtiene la cantidad total de items
     */
    public int getCantidadItems() {
        return items.size();
    }
}
