package com.controlador;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.modelo.entities.CarritoCompras;

/**
 * Servlet para cerrar sesión de usuarios
 */
@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Obtener sesión actual
        HttpSession session = request.getSession(false);
        
        if (session != null) {
            // Guardar el carrito antes de cerrar sesión
            Integer usuarioId = (Integer) session.getAttribute("usuarioId");
            CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
            
            if (usuarioId != null && carrito != null && !carrito.estaVacio()) {
                // Guardar el carrito en el contexto de la aplicación
                ServletContext context = getServletContext();
                @SuppressWarnings("unchecked")
                Map<Integer, CarritoCompras> carritosUsuarios = 
                    (Map<Integer, CarritoCompras>) context.getAttribute("carritosUsuarios");
                
                if (carritosUsuarios == null) {
                    carritosUsuarios = new ConcurrentHashMap<>();
                    context.setAttribute("carritosUsuarios", carritosUsuarios);
                }
                
                carritosUsuarios.put(usuarioId, carrito);
            }
            
            // Invalidar la sesión
            session.invalidate();
        }
        
        // Redirigir al login
        response.sendRedirect(request.getContextPath() + "/GestionarInicioDeSesionServlet");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}
