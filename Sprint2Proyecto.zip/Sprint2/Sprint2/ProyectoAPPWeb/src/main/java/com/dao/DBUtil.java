package com.dao;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DBUtil {
    private static String url;
    private static String user;
    private static String password;
    private static String driver;

    static {
        InputStream is = null;
        try {
            // Intentar cargar desde la raíz del classpath
            is = DBUtil.class.getResourceAsStream("/db.properties");
            
            // Si no se encuentra, intentar desde /database/
            if (is == null) {
                is = DBUtil.class.getResourceAsStream("/database/db.properties");
            }
            
            // Si aún no se encuentra, intentar con ClassLoader
            if (is == null) {
                is = DBUtil.class.getClassLoader().getResourceAsStream("db.properties");
            }
            
            if (is == null) {
                throw new RuntimeException("db.properties not found in classpath. Searched in: /db.properties, /database/db.properties");
            }
            
            Properties p = new Properties();
            p.load(is);
            
            url = p.getProperty("db.url");
            user = p.getProperty("db.user");
            password = p.getProperty("db.password");
            driver = p.getProperty("db.driver");
            
            if (driver != null && !driver.isEmpty()) {
                Class.forName(driver);
            }
            
        } catch (Exception e) {
            throw new ExceptionInInitializerError(e);
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (Exception e) {
                    // Ignorar errores al cerrar
                }
            }
        }
    }

    public static Connection getConnection() throws Exception {
        return DriverManager.getConnection(url, user, password);
    }
}
