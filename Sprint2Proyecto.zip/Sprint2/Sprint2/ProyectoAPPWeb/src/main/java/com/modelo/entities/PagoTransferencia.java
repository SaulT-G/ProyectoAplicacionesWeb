package com.modelo.entities;

import jakarta.persistence.*;
import java.util.Date;

/**
 * Entidad PagoTransferencia
 * Representa el pago por transferencia bancaria según el diagrama
 */
@Entity
@Table(name = "pago_transferencia")
public class PagoTransferencia {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pago")
    private Integer idPago;
    
    @Column(name = "monto", nullable = false)
    private Double monto;
    
    @Column(name = "fecha_pago", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaPago;
    
    @Column(name = "banco", length = 100)
    private String banco;
    
    @Column(name = "titular", length = 150)
    private String titular;
    
    @Column(name = "numero_cuenta", length = 50)
    private String numeroCuenta;
    
    @Column(name = "tipo_cuenta", length = 50)
    private String tipoCuenta;
    
    @Column(name = "ruc", length = 13)
    private String ruc;
    
    @Column(name = "estado", length = 50)
    private String estado; // PENDIENTE, APROBADO, RECHAZADO
    
    @OneToOne(mappedBy = "pagoTransferencia", cascade = CascadeType.ALL)
    private ComprobantePago comprobante;
    
    @OneToOne
    @JoinColumn(name = "id_pedido")
    private Pedido pedido;
    
    // Constructores
    public PagoTransferencia() {
        this.fechaPago = new Date();
        this.estado = "PENDIENTE";
    }
    
    public PagoTransferencia(Double monto, String banco, String titular, String numeroCuenta, String tipoCuenta, String ruc) {
        this();
        this.monto = monto;
        this.banco = banco;
        this.titular = titular;
        this.numeroCuenta = numeroCuenta;
        this.tipoCuenta = tipoCuenta;
        this.ruc = ruc;
    }
    
    // Getters y Setters
    public Integer getIdPago() {
        return idPago;
    }
    
    public void setIdPago(Integer idPago) {
        this.idPago = idPago;
    }
    
    public Double getMonto() {
        return monto;
    }
    
    public void setMonto(Double monto) {
        this.monto = monto;
    }
    
    public Date getFechaPago() {
        return fechaPago;
    }
    
    public void setFechaPago(Date fechaPago) {
        this.fechaPago = fechaPago;
    }
    
    public String getBanco() {
        return banco;
    }
    
    public void setBanco(String banco) {
        this.banco = banco;
    }
    
    public String getTitular() {
        return titular;
    }
    
    public void setTitular(String titular) {
        this.titular = titular;
    }
    
    public String getNumeroCuenta() {
        return numeroCuenta;
    }
    
    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }
    
    public String getTipoCuenta() {
        return tipoCuenta;
    }
    
    public void setTipoCuenta(String tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }
    
    public String getRuc() {
        return ruc;
    }
    
    public void setRuc(String ruc) {
        this.ruc = ruc;
    }
    
    public String getEstado() {
        return estado;
    }
    
    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    public ComprobantePago getComprobante() {
        return comprobante;
    }
    
    public void setComprobante(ComprobantePago comprobante) {
        this.comprobante = comprobante;
    }
    
    public Pedido getPedido() {
        return pedido;
    }
    
    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }
    
    /**
     * Método según diagrama: guardarPago(...)
     */
    public boolean guardarPago(Integer idPago, Double monto, Date fechaPago, String banco, 
                              String titular, String numeroCuenta, String tipoCuenta, String ruc) {
        this.idPago = idPago;
        this.monto = monto;
        this.fechaPago = fechaPago;
        this.banco = banco;
        this.titular = titular;
        this.numeroCuenta = numeroCuenta;
        this.tipoCuenta = tipoCuenta;
        this.ruc = ruc;
        return true;
    }
}
