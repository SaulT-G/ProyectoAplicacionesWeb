package com.dao;

import com.modelo.conection.PersistenciaBDD;
import com.modelo.entities.ComprobantePago;
import com.modelo.entities.PagoTransferencia;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.Date;

/**
 * ========================================================================
 * DAO: ComprobantePagoDAO
 * ========================================================================
 * Según el diagrama de clases:
 * +generarComprobante(nombreComprador, numeroComprobante, fechaEmision) : Comprobante
 * +mostrarComprobanteDePago() : void
 */
public class ComprobantePagoDAO {

    /**
     * Genera y guarda un comprobante de pago
     * Según diagrama: +generarComprobante(nombreComprador, numeroComprobante, fechaEmision)
     */
    public ComprobantePago generarComprobante(String nombreComprador, String numeroComprobante, Date fechaEmision) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            
            ComprobantePago comprobante = new ComprobantePago();
            comprobante.setNombreComprador(nombreComprador);
            comprobante.setNumeroComprobante(numeroComprobante);
            comprobante.setFechaEmision(fechaEmision != null ? fechaEmision : new Date());
            
            em.persist(comprobante);
            tx.commit();
            
            System.out.println("✓ Comprobante generado exitosamente. ID: " + comprobante.getIdComprobante());
            return comprobante;
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            System.err.println("❌ Error al generar comprobante: " + e.getMessage());
            e.printStackTrace();
            return null;
        } finally {
            em.close();
        }
    }
    
    /**
     * Guarda un comprobante completo con imagen
     */
    public boolean guardarComprobante(ComprobantePago comprobante, PagoTransferencia pago) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            
            // Recargar pago para que esté gestionado
            if (pago != null && pago.getIdPago() != null) {
                PagoTransferencia pagoDb = em.find(PagoTransferencia.class, pago.getIdPago());
                if (pagoDb != null) {
                    comprobante.setPagoTransferencia(pagoDb);
                }
            }
            
            em.persist(comprobante);
            tx.commit();
            
            System.out.println("✓ Comprobante guardado exitosamente. ID: " + comprobante.getIdComprobante());
            return true;
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            System.err.println("❌ Error al guardar comprobante: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            em.close();
        }
    }
    
    /**
     * Muestra información del comprobante de pago
     * Según diagrama: +mostrarComprobanteDePago() : void
     */
    public void mostrarComprobanteDePago(Integer idComprobante) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        try {
            ComprobantePago comprobante = em.find(ComprobantePago.class, idComprobante);
            if (comprobante != null) {
                comprobante.mostrarComprobanteDePago();
            } else {
                System.out.println("❌ Comprobante no encontrado.");
            }
        } finally {
            em.close();
        }
    }
    
    /**
     * Obtiene un comprobante por su ID
     */
    public ComprobantePago obtenerPorId(Integer idComprobante) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        try {
            return em.find(ComprobantePago.class, idComprobante);
        } finally {
            em.close();
        }
    }
}
