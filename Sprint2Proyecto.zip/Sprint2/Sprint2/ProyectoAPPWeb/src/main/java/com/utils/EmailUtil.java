package com.utils;

import com.modelo.entities.ComprobantePago;
import com.modelo.entities.PagoTransferencia;
import com.modelo.entities.Pedido;

import jakarta.activation.DataHandler;
import jakarta.activation.DataSource;
import jakarta.mail.*;
import jakarta.mail.internet.*;
import jakarta.mail.util.ByteArrayDataSource;

import java.util.Properties;
import java.util.Date;

/**
 * Utilidad para enviar correos electrónicos con comprobantes de pago
 */
public class EmailUtil {
    
    private static final String EMAIL_FROM = "rochaximena1502@gmail.com";
    private static final String EMAIL_PASSWORD = "pvuh oroj figx wfza";
    private static final String SMTP_HOST = "smtp.gmail.com";
    private static final String SMTP_PORT = "587";
    
    /**
     * Envía un correo con el comprobante de pago adjunto y botones de aprobación/rechazo
     */
    public static boolean enviarComprobanteConBotones(String destinatario, PagoTransferencia pago, 
                                                      ComprobantePago comprobante, Pedido pedido, 
                                                      String urlBase) {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", SMTP_HOST);
        props.put("mail.smtp.port", SMTP_PORT);
        props.put("mail.smtp.ssl.trust", SMTP_HOST);
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");
        
        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(EMAIL_FROM, EMAIL_PASSWORD);
            }
        });
        
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(EMAIL_FROM));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            message.setSubject("Nuevo Comprobante de Pago - Pedido #" + pedido.getNumeroPedido());
            
            // Crear el cuerpo del mensaje
            MimeMultipart multipart = new MimeMultipart("related");
            
            // Parte HTML del mensaje
            BodyPart messageBodyPart = new MimeBodyPart();
            String urlAprobar = urlBase + "/ProcesarCompra?action=aprobarPago&idPago=" + pago.getIdPago();
            String urlRechazar = urlBase + "/ProcesarCompra?action=rechazarPago&idPago=" + pago.getIdPago();
            
            String htmlContent = construirHTMLCorreo(pago, pedido, comprobante, urlAprobar, urlRechazar);
            messageBodyPart.setContent(htmlContent, "text/html; charset=UTF-8");
            multipart.addBodyPart(messageBodyPart);
            
            // Adjuntar comprobante si existe
            if (comprobante != null && comprobante.getImagen() != null) {
                BodyPart adjuntoBodyPart = new MimeBodyPart();
                DataSource source = new ByteArrayDataSource(comprobante.getImagen(), comprobante.getTipoMime());
                adjuntoBodyPart.setDataHandler(new DataHandler(source));
                adjuntoBodyPart.setFileName(comprobante.getNombreArchivo());
                multipart.addBodyPart(adjuntoBodyPart);
            }
            
            message.setContent(multipart);
            
            Transport.send(message);
            
            System.out.println("✓ Correo enviado exitosamente a: " + destinatario);
            return true;
            
        } catch (MessagingException e) {
            System.err.println("❌ Error al enviar correo: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Construye el contenido HTML del correo con botones
     */
    private static String construirHTMLCorreo(PagoTransferencia pago, Pedido pedido, 
                                             ComprobantePago comprobante, String urlAprobar, String urlRechazar) {
        StringBuilder html = new StringBuilder();
        html.append("<!DOCTYPE html>");
        html.append("<html>");
        html.append("<head>");
        html.append("<meta charset='UTF-8'>");
        html.append("<style>");
        html.append("body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }");
        html.append(".container { max-width: 600px; margin: 0 auto; padding: 20px; }");
        html.append(".header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }");
        html.append(".content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }");
        html.append(".info-box { background: white; padding: 20px; margin: 15px 0; border-left: 4px solid #667eea; }");
        html.append(".info-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #eee; }");
        html.append(".label { font-weight: bold; color: #667eea; }");
        html.append(".value { color: #555; }");
        html.append(".button-container { text-align: center; margin: 30px 0; }");
        html.append(".btn { display: inline-block; padding: 15px 40px; margin: 10px; text-decoration: none; border-radius: 5px; font-weight: bold; font-size: 16px; }");
        html.append(".btn-aprobar { background: #4CAF50; color: white; }");
        html.append(".btn-rechazar { background: #f44336; color: white; }");
        html.append(".btn:hover { opacity: 0.9; }");
        html.append(".footer { text-align: center; padding: 20px; color: #999; font-size: 12px; }");
        html.append("</style>");
        html.append("</head>");
        html.append("<body>");
        html.append("<div class='container'>");
        html.append("<div class='header'>");
        html.append("<h1>🧸 Nuevo Comprobante de Pago</h1>");
        html.append("<p>Se ha recibido un comprobante de pago que requiere su revisión</p>");
        html.append("</div>");
        html.append("<div class='content'>");
        
        // Información del pedido
        html.append("<div class='info-box'>");
        html.append("<h3>📦 Información del Pedido</h3>");
        html.append("<div class='info-row'>");
        html.append("<span class='label'>Número de Pedido:</span>");
        html.append("<span class='value'>").append(pedido.getNumeroPedido()).append("</span>");
        html.append("</div>");
        html.append("<div class='info-row'>");
        html.append("<span class='label'>Estado:</span>");
        html.append("<span class='value'>").append(pedido.getEstado()).append("</span>");
        html.append("</div>");
        html.append("<div class='info-row'>");
        html.append("<span class='label'>Total:</span>");
        html.append("<span class='value'>$").append(String.format("%.2f", pedido.getTotal())).append("</span>");
        html.append("</div>");
        html.append("</div>");
        
        // Información del pago
        html.append("<div class='info-box'>");
        html.append("<h3>💳 Información del Pago</h3>");
        html.append("<div class='info-row'>");
        html.append("<span class='label'>Banco:</span>");
        html.append("<span class='value'>").append(pago.getBanco()).append("</span>");
        html.append("</div>");
        html.append("<div class='info-row'>");
        html.append("<span class='label'>Titular:</span>");
        html.append("<span class='value'>").append(pago.getTitular()).append("</span>");
        html.append("</div>");
        html.append("<div class='info-row'>");
        html.append("<span class='label'>Cuenta:</span>");
        html.append("<span class='value'>").append(pago.getNumeroCuenta()).append("</span>");
        html.append("</div>");
        html.append("<div class='info-row'>");
        html.append("<span class='label'>Monto:</span>");
        html.append("<span class='value'>$").append(String.format("%.2f", pago.getMonto())).append("</span>");
        html.append("</div>");
        if (pago.getRuc() != null && !pago.getRuc().isEmpty()) {
            html.append("<div class='info-row'>");
            html.append("<span class='label'>RUC:</span>");
            html.append("<span class='value'>").append(pago.getRuc()).append("</span>");
            html.append("</div>");
        }
        html.append("</div>");
        
        // Información del comprobante
        if (comprobante != null) {
            html.append("<div class='info-box'>");
            html.append("<h3>📄 Información del Comprobante</h3>");
            html.append("<div class='info-row'>");
            html.append("<span class='label'>Número:</span>");
            html.append("<span class='value'>").append(comprobante.getNumeroComprobante()).append("</span>");
            html.append("</div>");
            html.append("<div class='info-row'>");
            html.append("<span class='label'>Comprador:</span>");
            html.append("<span class='value'>").append(comprobante.getNombreComprador()).append("</span>");
            html.append("</div>");
            html.append("<p style='color: #666; margin-top: 10px;'><em>El comprobante se encuentra adjunto a este correo.</em></p>");
            html.append("</div>");
        }
        
        // Botones de acción
        html.append("<div class='button-container'>");
        html.append("<h3>¿Aprobar o Rechazar este pago?</h3>");
        html.append("<a href='").append(urlAprobar).append("' class='btn btn-aprobar'>✓ APROBAR PAGO</a>");
        html.append("<a href='").append(urlRechazar).append("' class='btn btn-rechazar'>✗ RECHAZAR PAGO</a>");
        html.append("</div>");
        
        html.append("<div class='footer'>");
        html.append("<p>Este correo fue enviado automáticamente. Por favor no responder.</p>");
        html.append("<p>Sistema de Gestión de Pedidos © 2026</p>");
        html.append("</div>");
        
        html.append("</div>");
        html.append("</div>");
        html.append("</body>");
        html.append("</html>");
        
        return html.toString();
    }
    
    /**
     * Envía notificación de aprobación al comprador
     */
    public static boolean enviarNotificacionAprobacion(String destinatario, Pedido pedido) {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", SMTP_HOST);
        props.put("mail.smtp.port", SMTP_PORT);
        props.put("mail.smtp.ssl.trust", SMTP_HOST);
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");
        
        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(EMAIL_FROM, EMAIL_PASSWORD);
            }
        });
        
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(EMAIL_FROM));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            message.setSubject("✓ Pago Aprobado - Pedido #" + pedido.getNumeroPedido());
            
            String htmlContent = "<!DOCTYPE html><html><head><meta charset='UTF-8'></head><body style='font-family: Arial, sans-serif;'>"
                + "<div style='max-width: 600px; margin: 0 auto; padding: 20px;'>"
                + "<div style='background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%); color: white; padding: 30px; text-align: center; border-radius: 10px;'>"
                + "<h1>¡Pago Aprobado! 🎉</h1>"
                + "</div>"
                + "<div style='padding: 30px; background: #f9f9f9;'>"
                + "<p>Estimado cliente,</p>"
                + "<p>Nos complace informarle que su pago ha sido <strong>aprobado exitosamente</strong>.</p>"
                + "<p><strong>Número de Pedido:</strong> " + pedido.getNumeroPedido() + "</p>"
                + "<p><strong>Total:</strong> $" + String.format("%.2f", pedido.getTotal()) + "</p>"
                + "<p>Su pedido será procesado y enviado a la brevedad.</p>"
                + "<p>Gracias por su compra.</p>"
                + "</div></div></body></html>";
            
            message.setContent(htmlContent, "text/html; charset=UTF-8");
            Transport.send(message);
            
            System.out.println("✓ Notificación de aprobación enviada a: " + destinatario);
            return true;
            
        } catch (MessagingException e) {
            System.err.println("❌ Error al enviar notificación: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Envía notificación de rechazo al comprador
     */
    public static boolean enviarNotificacionRechazo(String destinatario, Pedido pedido, String motivo) {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", SMTP_HOST);
        props.put("mail.smtp.port", SMTP_PORT);
        props.put("mail.smtp.ssl.trust", SMTP_HOST);
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");
        
        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(EMAIL_FROM, EMAIL_PASSWORD);
            }
        });
        
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(EMAIL_FROM));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            message.setSubject("Pago Rechazado - Pedido #" + pedido.getNumeroPedido());
            
            String htmlContent = "<!DOCTYPE html><html><head><meta charset='UTF-8'></head><body style='font-family: Arial, sans-serif;'>"
                + "<div style='max-width: 600px; margin: 0 auto; padding: 20px;'>"
                + "<div style='background: linear-gradient(135deg, #f44336 0%, #e53935 100%); color: white; padding: 30px; text-align: center; border-radius: 10px;'>"
                + "<h1>Pago Rechazado</h1>"
                + "</div>"
                + "<div style='padding: 30px; background: #f9f9f9;'>"
                + "<p>Estimado cliente,</p>"
                + "<p>Lamentamos informarle que su pago ha sido <strong>rechazado</strong>.</p>"
                + "<p><strong>Número de Pedido:</strong> " + pedido.getNumeroPedido() + "</p>"
                + (motivo != null && !motivo.isEmpty() ? "<p><strong>Motivo:</strong> " + motivo + "</p>" : "")
                + "<p>Por favor, verifique los datos de su transferencia e intente nuevamente.</p>"
                + "<p>Si tiene alguna duda, no dude en contactarnos.</p>"
                + "</div></div></body></html>";
            
            message.setContent(htmlContent, "text/html; charset=UTF-8");
            Transport.send(message);
            
            System.out.println("✓ Notificación de rechazo enviada a: " + destinatario);
            return true;
            
        } catch (MessagingException e) {
            System.err.println("❌ Error al enviar notificación: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}
