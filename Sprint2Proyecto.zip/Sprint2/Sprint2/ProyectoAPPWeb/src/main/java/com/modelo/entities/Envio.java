package com.modelo.entities;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * ========================================================================
 * ENTIDAD: Envio
 * ========================================================================
 * Representa la información de envío de un pedido.
 * Según el diagrama de clases:
 * - nombreDestinatario : String
 * - telefono : String
 * - fechaEntrega : Date
 * - direccionEntrega : Direccion
 * - metodoEnvio : MetodoEnvio
 */
@Entity
@Table(name = "envio")
public class Envio implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_envio")
    private Integer idEnvio;

    @Column(name = "nombre_destinatario", nullable = false, length = 100)
    private String nombreDestinatario;

    @Column(name = "telefono", nullable = false, length = 20)
    private String telefono;

    @Temporal(TemporalType.DATE)
    @Column(name = "fecha_entrega", nullable = false)
    private Date fechaEntrega;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_direccion_entrega")
    private Direccion direccionEntrega;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_metodo_envio", nullable = false)
    private MetodoEnvio metodoEnvio;

    // Constructores
    public Envio() {
    }

    public Envio(String nombreDestinatario, String telefono, Date fechaEntrega) {
        this.nombreDestinatario = nombreDestinatario;
        this.telefono = telefono;
        this.fechaEntrega = fechaEntrega;
    }

    // Getters y Setters
    public Integer getIdEnvio() {
        return idEnvio;
    }

    public void setIdEnvio(Integer idEnvio) {
        this.idEnvio = idEnvio;
    }

    public String getNombreDestinatario() {
        return nombreDestinatario;
    }

    public void setNombreDestinatario(String nombreDestinatario) {
        this.nombreDestinatario = nombreDestinatario;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public Date getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(Date fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public Direccion getDireccionEntrega() {
        return direccionEntrega;
    }

    public void setDireccionEntrega(Direccion direccionEntrega) {
        this.direccionEntrega = direccionEntrega;
    }

    public MetodoEnvio getMetodoEnvio() {
        return metodoEnvio;
    }

    public void setMetodoEnvio(MetodoEnvio metodoEnvio) {
        this.metodoEnvio = metodoEnvio;
    }

    @Override
    public String toString() {
        return "Envio{" +
                "idEnvio=" + idEnvio +
                ", nombreDestinatario='" + nombreDestinatario + '\'' +
                ", telefono='" + telefono + '\'' +
                ", fechaEntrega=" + fechaEntrega +
                '}';
    }
}
