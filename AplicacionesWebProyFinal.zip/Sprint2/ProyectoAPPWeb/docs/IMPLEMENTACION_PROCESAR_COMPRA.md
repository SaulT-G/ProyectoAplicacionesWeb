# Implementación del Flujo de Procesar Compra
## Encanto EA - Sistema de Pagos por Transferencia Bancaria

---

## RESUMEN DE LA IMPLEMENTACIÓN

Se ha implementado el flujo completo de "Procesar Compra" según los diagramas de robustez y secuencia proporcionados.

### Archivos Creados

1. **Entidades:**
   - `PagoTransferencia.java` - Entidad para almacenar los pagos por transferencia
   - `Comprobante.java` - Entidad para almacenar los comprobantes de pago

2. **DAOs:**
   - `PagoTransferenciaDAO.java` - DAO para operaciones con pagos
   - `ComprobanteDAO.java` - DAO para operaciones con comprobantes
   - `EmailService.java` - Servicio para envío de correos electrónicos

3. **Vistas:**
   - `ComprobanteDePago.jsp` - Vista para mostrar el comprobante de pago aprobado

### Archivos Modificados

1. **Controladores:**
   - `ProcesarCompraServlet.java` - Implementación completa del flujo
   - `ProcesarPedidoServlet.java` - Redirección al flujo de pago tras crear pedido

2. **Vistas:**
   - `ResumenPedido.jsp` - Agregada sección de datos bancarios y subida de comprobante
   - `Mensaje.jsp` - Soporte para mensajes del flujo de pago

3. **Entidades:**
   - `Pedido.java` - Agregada relación con PagoTransferencia

4. **Configuración:**
   - `pom.xml` - Agregadas dependencias de Jakarta Mail

---

## FLUJO IMPLEMENTADO

### Flujo Principal:

1. **Comprador solicita Procesar Compra** → `procesarCompraPedido()`
2. **Sistema muestra detalle del pedido y datos bancarios** → `ResumenPedido.jsp`
3. **Comprador adjunta comprobante** → `adjuntarComprobante(imagen)`
4. **Sistema valida y muestra mensaje de éxito** → `Mensaje.jsp`
5. **Comprador confirma transferencia** → `confirmarTransferencia()`
6. **Sistema actualiza estado a PENDIENTE y envía correo al admin**
7. **Administrador revisa el comprobante** (recibe correo con botones)
8. **Administrador aprueba pago** → `aprobarPago()`
9. **Sistema genera comprobante** → `ComprobanteDePago.jsp`
10. **Comprador continúa** → `continuar()`
11. **Sistema muestra mensaje de agradecimiento** → `MensajeAgradecimiento.jsp`

### Flujos Alternos:

- **5.1 No subir comprobante:** Sistema bloquea el proceso
- **5.2 Comprobante inválido:** Sistema solicita cargar nuevamente
- **10.1 Rechazar pago:** Sistema notifica al comprador
- **12.1 Seguir comprando:** Redirige al catálogo
- **12.2 Volver al inicio:** Redirige al panel

---

## CONFIGURACIÓN DEL SERVIDOR DE CORREO

### ⚠️ IMPORTANTE: Configurar EmailService.java

Para que el envío de correos funcione, debe configurar una **Contraseña de Aplicación** de Google:

1. Ir a: https://myaccount.google.com/apppasswords
2. Iniciar sesión con la cuenta: `tualombosaul0@gmail.com`
3. Generar una nueva contraseña de aplicación para "Correo"
4. Copiar la contraseña generada (16 caracteres sin espacios)
5. Editar el archivo `EmailService.java` y reemplazar:

```java
private static final String EMAIL_PASSWORD = ""; // <-- Pegar contraseña aquí
```

Por ejemplo:
```java
private static final String EMAIL_PASSWORD = "abcd efgh ijkl mnop";
```

**NOTA:** NO use su contraseña normal de Gmail, use la contraseña de aplicación.

---

## DATOS BANCARIOS CONFIGURADOS

Los datos bancarios se encuentran en `ProcesarCompraServlet.java`:

- **Banco:** Banco de Crédito del Perú (BCP)
- **Titular:** Encanto EA S.A.C.
- **N° Cuenta:** 191-12345678-0-12
- **Tipo:** Cuenta Corriente
- **CCI:** 002-191-012345678012-34
- **RUC:** 20123456789

Para modificarlos, edite las constantes al inicio del servlet.

---

## CORREO DE ADMINISTRADOR

El correo del administrador está configurado en `EmailService.java`:

```java
private static final String ADMIN_EMAIL = "tualombosaul0@gmail.com";
```

Los correos enviados al administrador incluyen:
- Detalles del pedido (número, comprador, monto)
- Comprobante de pago adjunto
- Botones de APROBAR y RECHAZAR pago

---

## FORMATO DE COMPROBANTES PERMITIDOS

- JPG/JPEG
- PNG
- PDF

Tamaño máximo: 10MB

---

## ESTADOS DEL PEDIDO

El pedido pasa por los siguientes estados:

1. `PENDIENTE` - Pedido creado, esperando comprobante
2. `PENDIENTE_APROBACION` - Comprobante enviado, esperando revisión del admin
3. `PAGO_APROBADO` - Administrador aprobó el pago
4. `PAGO_RECHAZADO` - Administrador rechazó el pago
5. `FINALIZADO` - Proceso completado

---

## PRUEBAS

Para probar el flujo:

1. Agregar productos al carrito
2. Ir a "Procesar Pedido"
3. Completar datos de entrega
4. En el resumen, ver los datos bancarios
5. Subir un comprobante (imagen JPG/PNG)
6. Confirmar la transferencia
7. Revisar el correo del administrador
8. Hacer clic en "Aprobar Pago" o "Rechazar Pago"
9. Verificar que el estado del pedido se actualice

---

## DEPENDENCIAS AGREGADAS

```xml
<!-- Jakarta Mail API -->
<dependency>
    <groupId>jakarta.mail</groupId>
    <artifactId>jakarta.mail-api</artifactId>
    <version>2.1.2</version>
</dependency>

<!-- Implementación de Jakarta Mail (Angus Mail) -->
<dependency>
    <groupId>org.eclipse.angus</groupId>
    <artifactId>angus-mail</artifactId>
    <version>2.0.2</version>
</dependency>
```

---

## NOTAS ADICIONALES

- El carrito NO se vacía hasta que el pedido sea finalizado
- El comprobante se almacena temporalmente en la sesión
- Los correos de notificación se envían tanto al administrador como al comprador
- Los botones del correo funcionan con URLs que apuntan a la aplicación

© 2026 Encanto EA - Implementación de Procesar Compra
