package com.recursos;

import jakarta.ws.rs.Path;

import java.util.List;

import com.dao.ProductoDAO;
import com.modelo.entities.Producto;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

/*
    URL de acceso:
	http://localhost:8080/ProyectoAPPWeb/rest/productos
*/

@Path("/productos")
public class RecursoProducto {

	// Instancia del DAO para manejar las operaciones de productos
	private ProductoDAO productoDAO = new ProductoDAO();

	// Obtener el listado de productos en formato JSON
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Producto> getProductos() {
		return productoDAO.obtenerListadoDeProductos();
	}
	
	// Obtener un producto por su ID en formato JSON
	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Producto getProductoPorId(@PathParam("id") int id) {
		return productoDAO.obtenerDatosProducto(id);
	}
	
	// Obtener los productos por categoria en formato JSON
	@GET
	@Path("/categoria/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Producto> getProductosPorCategoria(@PathParam("id") int id) {
		return productoDAO.obtenerPorCategoria(id);
	}
	
	// Guardar un nuevo producto (recibe un JSON)
	@POST
	@Path("/add")
	@Consumes(MediaType.APPLICATION_JSON)
	public void guardarProducto(Producto producto) {
		productoDAO.guardar(producto);
	}
	
	// Actualizar un producto (recibe un JSON)
	@PUT
	@Path("/update")
	@Consumes(MediaType.APPLICATION_JSON)
	public void actualizarProducto(Producto producto) {
		productoDAO.actualizarProducto(producto);
	}
	
	// Eliminar un producto por su ID
	@DELETE
	@Path("/delete/{id}")
	public void eliminarProducto(@PathParam("id") int id) {
		productoDAO.eliminarProducto(id);
	}
	
	
}
