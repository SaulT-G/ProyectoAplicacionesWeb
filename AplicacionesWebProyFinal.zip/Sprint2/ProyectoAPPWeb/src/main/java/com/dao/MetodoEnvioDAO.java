package com.dao;

import com.modelo.conection.PersistenciaBDD;
import com.modelo.entities.MetodoEnvio;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

import java.util.ArrayList;
import java.util.List;

/**
 * ========================================================================
 * DAO: MetodoEnvioDAO
 * ========================================================================
 * Según el diagrama de clases:
 * +obtenerMetodoDeEnvio() : List<MetodoEnvio>
 */
public class MetodoEnvioDAO {

    /**
     * Obtiene todos los métodos de envío disponibles
     * Según diagrama: +obtenerMetodoDeEnvio() : List<MetodoEnvio>
     * @return Lista de métodos de envío
     */
    public List<MetodoEnvio> obtenerMetodoDeEnvio() {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        try {
            TypedQuery<MetodoEnvio> query = em.createQuery(
                "SELECT m FROM MetodoEnvio m ORDER BY m.costo ASC",
                MetodoEnvio.class
            );
            return query.getResultList();
        } catch (Exception e) {
            System.err.println("❌ Error al obtener métodos de envío: " + e.getMessage());
            return new ArrayList<>();
        } finally {
            em.close();
        }
    }
}
