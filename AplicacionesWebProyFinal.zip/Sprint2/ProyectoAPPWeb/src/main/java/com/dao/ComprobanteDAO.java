package com.dao;

import com.modelo.conection.PersistenciaBDD;
import com.modelo.entities.Comprobante;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.Date;
import java.util.UUID;

/**
 * ========================================================================
 * DAO: ComprobanteDAO
 * ========================================================================
 * Según el diagrama de clases:
 * +generarComprobante(nombreComprador : String, numeroComprobante : String, 
 *                     fechaEmision : Date) : Comprobante
 */
public class ComprobanteDAO {

    private Comprobante ultimoComprobante;

    /**
     * Genera un comprobante de pago
     * Según diagrama: +generarComprobante(nombreComprador : String, numeroComprobante : String, 
     *                                    fechaEmision : Date) : Comprobante
     * Este método también puede recibir un Comprobante existente con imagen para guardarlo
     */
    public Comprobante generarComprobante(String nombreComprador, String numeroComprobante, Date fechaEmision) {
        return generarComprobante(nombreComprador, numeroComprobante, fechaEmision, null, null);
    }

    /**
     * Genera un comprobante de pago con imagen y estado opcionales
     * Versión extendida que permite guardar comprobantes con imagen adjunta
     */
    public Comprobante generarComprobante(String nombreComprador, String numeroComprobante, Date fechaEmision, 
                                          byte[] imagenComprobante, String estado) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            
            Comprobante comprobante = new Comprobante();
            comprobante.setNombreComprador(nombreComprador);
            
            // Generar número de comprobante si no existe
            if (numeroComprobante != null && !numeroComprobante.isEmpty()) {
                comprobante.setNumeroComprobante(numeroComprobante);
            } else {
                comprobante.setNumeroComprobante("COMP-" + System.currentTimeMillis() + "-" + 
                    UUID.randomUUID().toString().substring(0, 4).toUpperCase());
            }
            
            comprobante.setFechaEmision(fechaEmision != null ? fechaEmision : new Date());
            comprobante.setEstado(estado != null ? estado : "GENERADO");
            
            // Si hay imagen, asignarla
            if (imagenComprobante != null) {
                comprobante.setImagenComprobante(imagenComprobante);
            }
            
            em.persist(comprobante);
            em.flush();
            
            this.ultimoComprobante = comprobante;
            
            tx.commit();
            System.out.println("✓ Comprobante generado: " + comprobante.getNumeroComprobante());
            return comprobante;
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            System.err.println("❌ Error al generar comprobante: " + e.getMessage());
            e.printStackTrace();
            return null;
        } finally {
            em.close();
        }
    }
}
