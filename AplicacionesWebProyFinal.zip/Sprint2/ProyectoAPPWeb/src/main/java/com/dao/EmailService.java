package com.dao;

import jakarta.mail.*;
import jakarta.mail.internet.*;
import jakarta.activation.*;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Properties;
import java.util.HashMap;
import java.util.Map;

/**
 * ========================================================================
 * SERVICIO: EmailService
 * ========================================================================
 * Servicio para envío de correos electrónicos con comprobantes de pago.
 * Envía correos al administrador con botones para aprobar o rechazar pagos.
 */
public class EmailService {

    // Configuración del servidor SMTP (Gmail)
    private static final String SMTP_HOST = "smtp.gmail.com";
    private static final String SMTP_PORT = "465"; // Puerto SSL
    private static final String EMAIL_FROM = "tualombosaul0@gmail.com";
    // IMPORTANTE: Esta es la contraseña de aplicación de Google (16 caracteres sin espacios)
    // Para obtener una nueva: https://myaccount.google.com/apppasswords
    // Requisito: Tener activada la verificación en 2 pasos en tu cuenta de Google
    private static final String EMAIL_PASSWORD = "qoxcpqlnfsurgqxv"; // Contraseña de aplicación de Google
    private static final String ADMIN_EMAIL = "tualombosaul0@gmail.com";
    
    // URL BASE PARA ACCESO DESDE TELÉFONO/EXTERNA
    // Usando ngrok para exponer el servidor a Internet
    // Esta URL funciona desde cualquier dispositivo con Internet
    private static final String BASE_URL_EXTERNA = "https://eusebia-shrewd-hannah.ngrok-free.dev/ProyectoAPPWeb";
    
    // Variable para almacenar la última URL usada (para debug)
    private static String ultimaUrlAprobar = "";
    private static String ultimaUrlRechazar = "";
    
    /**
     * Obtiene la última URL de aprobación generada (útil para debug)
     */
    public static String getUltimaUrlAprobar() {
        return ultimaUrlAprobar;
    }
    
    /**
     * Obtiene la última URL de rechazo generada (útil para debug)
     */
    public static String getUltimaUrlRechazar() {
        return ultimaUrlRechazar;
    }
    
    // Almacén de tokens para validación
    private static Map<Integer, String> tokensAprobacion = new HashMap<>();

    /**
     * Genera y almacena un token de aprobación para un pedido
     */
    public static String generarTokenAprobacion(Integer idPedido) {
        String token = String.valueOf(System.currentTimeMillis()) + "-" + idPedido;
        tokensAprobacion.put(idPedido, token);
        return token;
    }
    
    /**
     * Valida un token de aprobación
     */
    public static boolean validarToken(Integer idPedido, String token) {
        String tokenGuardado = tokensAprobacion.get(idPedido);
        return tokenGuardado != null && tokenGuardado.equals(token);
    }
    
    /**
     * Obtiene el token de un pedido
     */
    public static String obtenerToken(Integer idPedido) {
        return tokensAprobacion.get(idPedido);
    }

    /**
     * Envía un correo al administrador con el comprobante de pago adjunto
     * y botones para aprobar o rechazar el pago.
     * 
     * @param numeroPedido Número del pedido
     * @param nombreComprador Nombre del comprador
     * @param monto Monto total del pedido
     * @param imagenComprobante Imagen del comprobante en bytes
     * @param baseUrl URL base de la aplicación para los botones
     * @param idPedido ID del pedido para las acciones
     * @return true si el correo se envió correctamente
     */
    public boolean enviarComprobanteAlAdministrador(String numeroPedido, String nombreComprador, 
            double monto, byte[] imagenComprobante, String baseUrl, Integer idPedido) {
        
        // Generar token de aprobación
        String token = generarTokenAprobacion(idPedido);
        
        System.out.println("========================================");
        System.out.println("📧 ENVIANDO CORREO AL ADMINISTRADOR");
        System.out.println("========================================");
        System.out.println("📮 Destinatario: " + ADMIN_EMAIL);
        System.out.println("📋 Pedido: #" + numeroPedido);
        System.out.println("👤 Comprador: " + nombreComprador);
        System.out.println("💰 Monto: S/ " + String.format("%.2f", monto));
        System.out.println("🔑 Token: " + token);
        System.out.println("🔐 Password configurada: " + (EMAIL_PASSWORD != null && !EMAIL_PASSWORD.isEmpty() ? "SÍ (" + EMAIL_PASSWORD.substring(0,4) + "...)" : "NO"));
        
        try {
            // Verificar si hay contraseña configurada
            if (EMAIL_PASSWORD == null || EMAIL_PASSWORD.isEmpty() || EMAIL_PASSWORD.equals("AQUI_TU_CONTRASENA_DE_APLICACION")) {
                System.out.println("⚠️ CONTRASEÑA DE CORREO NO CONFIGURADA");
                System.out.println("========================================");
                System.out.println("🔗 URLs de aprobación generadas:");
                System.out.println("   ✅ APROBAR: " + baseUrl + "/ProcesarCompra?action=aprobarPago&pedidoId=" + idPedido + "&token=" + token);
                System.out.println("   ❌ RECHAZAR: " + baseUrl + "/ProcesarCompra?action=rechazarPago&pedidoId=" + idPedido + "&token=" + token);
                System.out.println("========================================");
                return true; // Retornar true para que el flujo continúe
            }
            
            System.out.println("🔄 Configurando servidor SMTP...");
            
            // Configurar propiedades del servidor SMTP con SSL (puerto 465)
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.ssl.enable", "true"); // Usar SSL
            props.put("mail.smtp.host", SMTP_HOST);
            props.put("mail.smtp.port", SMTP_PORT);
            props.put("mail.smtp.ssl.trust", SMTP_HOST);
            props.put("mail.smtp.ssl.protocols", "TLSv1.2");
            props.put("mail.smtp.socketFactory.port", SMTP_PORT);
            props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
            props.put("mail.smtp.connectiontimeout", "15000");
            props.put("mail.smtp.timeout", "15000");
            props.put("mail.smtp.writetimeout", "15000");

            System.out.println("🔄 Creando sesión de correo...");
            
            // Crear sesión con autenticación
            Session session = Session.getInstance(props, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(EMAIL_FROM, EMAIL_PASSWORD);
                }
            });
            
            session.setDebug(true); // Habilitar debug para ver logs
            
            System.out.println("🔄 Creando mensaje...");

            // Crear mensaje
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(EMAIL_FROM, "Encanto EA - Sistema de Pagos"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(ADMIN_EMAIL));
            message.setSubject("🧾 Nuevo Comprobante de Pago - Pedido #" + numeroPedido);

            // Crear contenido HTML del correo
            String htmlContent = crearContenidoHtmlCorreo(numeroPedido, nombreComprador, monto, baseUrl, idPedido, token);

            // Crear el cuerpo multipart
            Multipart multipart = new MimeMultipart();

            // Parte HTML
            MimeBodyPart htmlPart = new MimeBodyPart();
            htmlPart.setContent(htmlContent, "text/html; charset=UTF-8");
            multipart.addBodyPart(htmlPart);

            // Adjuntar imagen del comprobante si existe
            if (imagenComprobante != null && imagenComprobante.length > 0) {
                MimeBodyPart attachmentPart = new MimeBodyPart();
                
                // Guardar temporalmente la imagen
                File tempFile = File.createTempFile("comprobante_" + numeroPedido, ".jpg");
                try (FileOutputStream fos = new FileOutputStream(tempFile)) {
                    fos.write(imagenComprobante);
                }
                
                DataSource source = new FileDataSource(tempFile);
                attachmentPart.setDataHandler(new DataHandler(source));
                attachmentPart.setFileName("Comprobante_Pedido_" + numeroPedido + ".jpg");
                multipart.addBodyPart(attachmentPart);
                
                // Eliminar archivo temporal después de adjuntarlo
                tempFile.deleteOnExit();
            }

            message.setContent(multipart);

            // Enviar correo
            Transport.send(message);
            
            System.out.println("✅ Correo enviado exitosamente al administrador: " + ADMIN_EMAIL);
            System.out.println("========================================");
            return true;

        } catch (AuthenticationFailedException authEx) {
            System.err.println("========================================");
            System.err.println("❌ ERROR DE AUTENTICACIÓN DE GMAIL");
            System.err.println("========================================");
            System.err.println("La contraseña de aplicación es INVÁLIDA o ha EXPIRADO.");
            System.err.println("");
            System.err.println("🔧 PARA SOLUCIONARLO:");
            System.err.println("1. Ve a: https://myaccount.google.com/apppasswords");
            System.err.println("2. Inicia sesión con: " + EMAIL_FROM);
            System.err.println("3. Crea una nueva 'Contraseña de aplicación'");
            System.err.println("4. Selecciona 'Otro' y escribe 'EncantoEA'");
            System.err.println("5. Copia la contraseña de 16 caracteres");
            System.err.println("6. Actualiza EMAIL_PASSWORD en EmailService.java");
            System.err.println("========================================");
            System.err.println("Error técnico: " + authEx.getMessage());
            System.out.println("🔗 URLs de aprobación generadas (usar manualmente):");
            System.out.println("   ✅ APROBAR: " + BASE_URL_EXTERNA + "/ProcesarCompra?action=aprobarPago&pedidoId=" + idPedido + "&token=" + token);
            System.out.println("   ❌ RECHAZAR: " + BASE_URL_EXTERNA + "/ProcesarCompra?action=rechazarPago&pedidoId=" + idPedido + "&token=" + token);
            System.out.println("========================================");
            return true;
        } catch (Exception e) {
            System.err.println("❌ Error al enviar correo: " + e.getMessage());
            e.printStackTrace();
            System.out.println("========================================");
            System.out.println("⚠️ EL CORREO NO SE ENVIÓ, PERO EL FLUJO CONTINÚA");
            System.out.println("🔗 URLs de aprobación generadas:");
            System.out.println("   ✅ APROBAR: " + BASE_URL_EXTERNA + "/ProcesarCompra?action=aprobarPago&pedidoId=" + idPedido + "&token=" + token);
            System.out.println("   ❌ RECHAZAR: " + BASE_URL_EXTERNA + "/ProcesarCompra?action=rechazarPago&pedidoId=" + idPedido + "&token=" + token);
            System.out.println("========================================");
            return true; // Retornar true para que el flujo continúe aunque el correo falle
        }
    }

    /**
     * Crea el contenido HTML del correo con los botones de acción
     */
    private String crearContenidoHtmlCorreo(String numeroPedido, String nombreComprador, 
            double monto, String baseUrl, Integer idPedido, String token) {
        
        // USAR LA URL EXTERNA PARA QUE FUNCIONE DESDE EL TELÉFONO
        String urlBase = BASE_URL_EXTERNA;
        String urlAprobar = urlBase + "/ProcesarCompra?action=aprobarPago&pedidoId=" + idPedido + "&token=" + token;
        String urlRechazar = urlBase + "/ProcesarCompra?action=rechazarPago&pedidoId=" + idPedido + "&token=" + token;
        
        // Guardar URLs para debug
        ultimaUrlAprobar = urlAprobar;
        ultimaUrlRechazar = urlRechazar;
        
        // Mostrar URLs en consola para facilitar pruebas
        System.out.println("========================================");
        System.out.println("🔗 URLs GENERADAS PARA EL CORREO:");
        System.out.println("✅ APROBAR: " + urlAprobar);
        System.out.println("❌ RECHAZAR: " + urlRechazar);
        System.out.println("========================================");
        
        return "<!DOCTYPE html>" +
            "<html lang=\"es\">" +
            "<head><meta charset=\"UTF-8\"></head>" +
            "<body style=\"font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5; margin: 0; padding: 20px;\">" +
            "<div style=\"max-width: 600px; margin: 0 auto; background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1);\">" +
            
            "<!-- Header -->" +
            "<div style=\"background: linear-gradient(135deg, #C26D7E, #B08968); padding: 30px; text-align: center;\">" +
            "<h1 style=\"color: white; margin: 0; font-size: 24px;\">🧾 Nuevo Comprobante de Pago</h1>" +
            "<p style=\"color: rgba(255,255,255,0.9); margin: 10px 0 0 0;\">Encanto EA - Sistema de Pagos</p>" +
            "</div>" +
            
            "<!-- Contenido -->" +
            "<div style=\"padding: 30px;\">" +
            "<div style=\"background: #fce4ec; border-radius: 10px; padding: 20px; margin-bottom: 25px;\">" +
            "<h2 style=\"color: #5A4A4F; margin: 0 0 15px 0; font-size: 18px;\">📋 Detalles del Pedido</h2>" +
            "<table style=\"width: 100%; border-collapse: collapse;\">" +
            "<tr><td style=\"padding: 8px 0; color: #666; border-bottom: 1px solid #F8BBD0;\">Número de Pedido:</td>" +
            "<td style=\"padding: 8px 0; color: #5A4A4F; font-weight: bold; border-bottom: 1px solid #F8BBD0; text-align: right;\">#" + numeroPedido + "</td></tr>" +
            "<tr><td style=\"padding: 8px 0; color: #666; border-bottom: 1px solid #F8BBD0;\">Comprador:</td>" +
            "<td style=\"padding: 8px 0; color: #5A4A4F; font-weight: bold; border-bottom: 1px solid #F8BBD0; text-align: right;\">" + nombreComprador + "</td></tr>" +
            "<tr><td style=\"padding: 8px 0; color: #666;\">Monto Total:</td>" +
            "<td style=\"padding: 8px 0; color: #C26D7E; font-weight: bold; font-size: 20px; text-align: right;\">S/ " + String.format("%.2f", monto) + "</td></tr>" +
            "</table></div>" +
            
            "<div style=\"background: #fff3e0; border-left: 4px solid #ff9800; padding: 15px; margin-bottom: 25px; border-radius: 0 10px 10px 0;\">" +
            "<p style=\"margin: 0; color: #e65100;\"><strong>⚠️ Importante:</strong> El comprobante de pago se encuentra adjunto a este correo. Por favor verifique los datos antes de aprobar el pago.</p>" +
            "</div>" +
            
            "<!-- Botones de Acción -->" +
            "<div style=\"text-align: center; margin-top: 30px;\">" +
            "<p style=\"color: #666; margin-bottom: 20px;\">Seleccione una acción para este pago:</p>" +
            
            "<a href=\"" + urlAprobar + "\" style=\"display: inline-block; padding: 15px 40px; background: linear-gradient(135deg, #A8B9A2, #7a9a70); color: white; text-decoration: none; border-radius: 10px; font-weight: bold; font-size: 16px; margin: 10px; box-shadow: 0 4px 15px rgba(168, 185, 162, 0.4);\">" +
            "✅ APROBAR PAGO</a>" +
            
            "<a href=\"" + urlRechazar + "\" style=\"display: inline-block; padding: 15px 40px; background: linear-gradient(135deg, #e74c3c, #c0392b); color: white; text-decoration: none; border-radius: 10px; font-weight: bold; font-size: 16px; margin: 10px; box-shadow: 0 4px 15px rgba(231, 76, 60, 0.4);\">" +
            "❌ RECHAZAR PAGO</a>" +
            "</div></div>" +
            
            "<!-- Footer -->" +
            "<div style=\"background: #5A4A4F; padding: 20px; text-align: center;\">" +
            "<p style=\"color: rgba(255,255,255,0.7); margin: 0; font-size: 12px;\">Este correo fue generado automáticamente por el sistema Encanto EA.<br>© 2026 Encanto EA - Todos los derechos reservados</p>" +
            "</div></div></body></html>";
    }

    /**
     * Envía un correo de notificación al comprador sobre el estado de su pago
     */
    public boolean enviarNotificacionComprador(String emailComprador, String nombreComprador, 
            String numeroPedido, String estado, String mensaje) {
        
        System.out.println("========================================");
        System.out.println("📧 ENVIANDO NOTIFICACIÓN AL COMPRADOR");
        System.out.println("📮 Destinatario: " + emailComprador);
        System.out.println("📋 Pedido: #" + numeroPedido);
        System.out.println("📊 Estado: " + estado);
        System.out.println("========================================");
        
        try {
            if (EMAIL_PASSWORD == null || EMAIL_PASSWORD.isEmpty() || EMAIL_PASSWORD.equals("AQUI_TU_CONTRASENA_DE_APLICACION")) {
                System.out.println("⚠️ Correo no configurado, notificación no enviada");
                return true;
            }
            
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.ssl.enable", "true");
            props.put("mail.smtp.host", SMTP_HOST);
            props.put("mail.smtp.port", SMTP_PORT);
            props.put("mail.smtp.ssl.trust", SMTP_HOST);
            props.put("mail.smtp.socketFactory.port", SMTP_PORT);
            props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

            Session session = Session.getInstance(props, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(EMAIL_FROM, EMAIL_PASSWORD);
                }
            });

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(EMAIL_FROM, "Encanto EA"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailComprador));
            
            String emoji = estado.equals("APROBADO") ? "✅" : "❌";
            message.setSubject(emoji + " Actualización de tu Pedido #" + numeroPedido);

            String htmlContent = crearNotificacionCompradorHtml(nombreComprador, numeroPedido, estado, mensaje);
            message.setContent(htmlContent, "text/html; charset=UTF-8");

            Transport.send(message);
            
            System.out.println("✅ Notificación enviada al comprador: " + emailComprador);
            return true;

        } catch (Exception e) {
            System.err.println("❌ Error al enviar notificación: " + e.getMessage());
            return true;
        }
    }

    /**
     * Crea el HTML para la notificación al comprador
     */
    private String crearNotificacionCompradorHtml(String nombreComprador, String numeroPedido, 
            String estado, String mensaje) {
        
        String colorEstado = estado.equals("APROBADO") ? "#A8B9A2" : "#e74c3c";
        String iconoEstado = estado.equals("APROBADO") ? "✅" : "❌";
        
        return "<!DOCTYPE html><html lang=\"es\"><head><meta charset=\"UTF-8\"></head>" +
            "<body style=\"font-family: 'Segoe UI', Tahoma, sans-serif; background-color: #f5f5f5; margin: 0; padding: 20px;\">" +
            "<div style=\"max-width: 500px; margin: 0 auto; background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1);\">" +
            "<div style=\"background: linear-gradient(135deg, #C26D7E, #B08968); padding: 25px; text-align: center;\">" +
            "<h1 style=\"color: white; margin: 0; font-size: 20px;\">Encanto EA</h1></div>" +
            "<div style=\"padding: 30px; text-align: center;\">" +
            "<div style=\"font-size: 50px; margin-bottom: 20px;\">" + iconoEstado + "</div>" +
            "<h2 style=\"color: " + colorEstado + "; margin: 0 0 15px 0;\">Pago " + estado + "</h2>" +
            "<p style=\"color: #666; margin-bottom: 20px;\">Hola <strong>" + nombreComprador + "</strong>,</p>" +
            "<p style=\"color: #5A4A4F; margin-bottom: 20px;\">" + mensaje + "</p>" +
            "<p style=\"color: #888; font-size: 14px;\">Pedido: <strong>#" + numeroPedido + "</strong></p></div>" +
            "<div style=\"background: #5A4A4F; padding: 15px; text-align: center;\">" +
            "<p style=\"color: rgba(255,255,255,0.7); margin: 0; font-size: 11px;\">© 2026 Encanto EA</p></div></div></body></html>";
    }
    
    /**
     * Método de prueba para verificar que el correo se envía correctamente
     */
    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("🧪 PRUEBA DE ENVÍO DE CORREO");
        System.out.println("========================================");
        System.out.println("📧 De: " + EMAIL_FROM);
        System.out.println("📮 Para: " + ADMIN_EMAIL);
        System.out.println("🔑 Password: " + EMAIL_PASSWORD.substring(0, 4) + "****");
        System.out.println("========================================");
        
        try {
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.ssl.enable", "true");
            props.put("mail.smtp.host", SMTP_HOST);
            props.put("mail.smtp.port", SMTP_PORT);
            props.put("mail.smtp.ssl.trust", SMTP_HOST);
            props.put("mail.smtp.ssl.protocols", "TLSv1.2");
            props.put("mail.smtp.socketFactory.port", SMTP_PORT);
            props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

            Session session = Session.getInstance(props, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(EMAIL_FROM, EMAIL_PASSWORD);
                }
            });
            
            session.setDebug(true);

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(EMAIL_FROM, "Encanto EA - Test"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(ADMIN_EMAIL));
            message.setSubject("🧪 Prueba de correo - " + new java.util.Date());
            message.setContent("<h1>Prueba exitosa!</h1><p>El correo funciona correctamente.</p>", "text/html; charset=UTF-8");

            Transport.send(message);
            
            System.out.println("========================================");
            System.out.println("✅ CORREO ENVIADO EXITOSAMENTE!");
            System.out.println("========================================");
            
        } catch (AuthenticationFailedException e) {
            System.err.println("========================================");
            System.err.println("❌ ERROR DE AUTENTICACIÓN");
            System.err.println("La contraseña de aplicación es inválida.");
            System.err.println("Error: " + e.getMessage());
            System.err.println("========================================");
        } catch (Exception e) {
            System.err.println("========================================");
            System.err.println("❌ ERROR: " + e.getMessage());
            e.printStackTrace();
            System.err.println("========================================");
        }
    }
}
