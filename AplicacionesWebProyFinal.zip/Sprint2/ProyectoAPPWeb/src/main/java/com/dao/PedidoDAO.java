package com.dao;

import com.modelo.conection.PersistenciaBDD;
import com.modelo.entities.Comprador;
import com.modelo.entities.Direccion;
import com.modelo.entities.Envio;
import com.modelo.entities.MetodoEnvio;
import com.modelo.entities.Pedido;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.Date;
import java.util.UUID;

/**
 * ========================================================================
 * DAO: PedidoDAO
 * ========================================================================
 * Según el diagrama de clases:
 * +guardarPedido(pedido : Pedido, comprador : Comprador) : boolean
 * +obtenerPedido() : Pedido
 * +actualizarEstadoPedido(estadoPedido : String) : void
 */
public class PedidoDAO {

    private Pedido ultimoPedido;

    /**
     * Guarda un pedido completo en la base de datos
     * Según diagrama: +guardarPedido(pedido : Pedido, comprador : Comprador) : boolean
     * Este método maneja el objeto Pedido completo con todas sus relaciones
     */
    public boolean guardarPedido(Pedido pedido, Comprador comprador) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            
            // Generar número de pedido si no existe
            if (pedido.getNumeroPedido() == null) {
                java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyyMMdd");
                String fecha = sdf.format(new Date());
                String uuid = UUID.randomUUID().toString().substring(0, 4).toUpperCase();
                pedido.setNumeroPedido("PED-" + fecha + "-" + uuid);
            }
            
            // Recargar comprador para que esté gestionado
            // Priorizar el comprador del pedido si ya está asignado, sino usar el parámetro
            Comprador compradorAUsar = pedido.getComprador() != null ? pedido.getComprador() : comprador;
            if (compradorAUsar != null && compradorAUsar.getIdUsuario() != null) {
                Comprador compradorDb = em.find(Comprador.class, compradorAUsar.getIdUsuario());
                if (compradorDb == null) {
                    throw new RuntimeException("Comprador no encontrado con ID: " + compradorAUsar.getIdUsuario());
                }
                pedido.setComprador(compradorDb);
            }
            
            // Si hay un envío, procesar sus relaciones
            if (pedido.getEnvio() != null) {
                // Recargar método de envío para que esté gestionado
                if (pedido.getEnvio().getMetodoEnvio() != null && pedido.getEnvio().getMetodoEnvio().getIdMetodoEnvio() != null) {
                    MetodoEnvio metodoEnvio = em.find(MetodoEnvio.class, pedido.getEnvio().getMetodoEnvio().getIdMetodoEnvio());
                    if (metodoEnvio == null) {
                        throw new RuntimeException("Método de envío no encontrado");
                    }
                    pedido.getEnvio().setMetodoEnvio(metodoEnvio);
                }
                
                // Manejar la dirección de entrega
                Direccion direccion = pedido.getEnvio().getDireccionEntrega();
                if (direccion != null) {
                    if (direccion.getIdDireccion() != null) {
                        Direccion direccionDb = em.find(Direccion.class, direccion.getIdDireccion());
                        pedido.getEnvio().setDireccionEntrega(direccionDb);
                    } else {
                        em.persist(direccion);
                        pedido.getEnvio().setDireccionEntrega(direccion);
                    }
                }
            }
            
            em.persist(pedido);
            em.flush();
            
            this.ultimoPedido = pedido;
            
            tx.commit();
            System.out.println("✓ Pedido guardado exitosamente: " + pedido.getNumeroPedido() + " con ID: " + pedido.getIdPedido());
            return true;
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            System.err.println("❌ Error al guardar pedido: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            em.close();
        }
    }

    /**
     * Obtiene el último pedido guardado
     * Según diagrama: +obtenerPedido() : Pedido
     * @return Pedido más reciente o null
     */
    public Pedido obtenerPedido() {
        if (this.ultimoPedido != null) {
            return this.ultimoPedido;
        }
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        try {
            return em.createQuery(
                "SELECT p FROM Pedido p ORDER BY p.fechaPedido DESC", 
                Pedido.class
            ).setMaxResults(1).getSingleResult();
        } catch (Exception e) {
            System.err.println("❌ Error al obtener pedido: " + e.getMessage());
            return null;
        } finally {
            em.close();
        }
    }

    /**
     * Actualiza el estado de un pedido
     * Según diagrama: +actualizarEstadoPedido(estadoPedido : String) : void
     * @param estadoPedido Nuevo estado del pedido
     */
    public void actualizarEstadoPedido(String estadoPedido) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            
            Pedido pedido = obtenerPedido();
            if (pedido != null) {
                pedido = em.merge(pedido);
                pedido.setEstado(estadoPedido);
            }
            
            tx.commit();
            System.out.println("✓ Estado del pedido actualizado a: " + estadoPedido);
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            System.err.println("❌ Error al actualizar estado del pedido: " + e.getMessage());
        } finally {
            em.close();
        }
    }

    /**
     * Establece el último pedido manualmente (para búsquedas por ID)
     * Usa el método existente obtenerPedido() consultando la BD con un ID específico
     * @param idPedido ID del pedido a establecer como último
     */
    public void setUltimoPedido(Integer idPedido) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        try {
            this.ultimoPedido = em.find(Pedido.class, idPedido);
        } finally {
            em.close();
        }
    }
}