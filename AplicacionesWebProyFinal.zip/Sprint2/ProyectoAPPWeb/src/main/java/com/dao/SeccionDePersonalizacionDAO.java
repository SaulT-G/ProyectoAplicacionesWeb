package com.dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

import java.util.List;

import com.modelo.entities.ProductoPersonalizable;
import com.modelo.entities.SeccionDePersonalizacion;

public class SeccionDePersonalizacionDAO {

    // Devuelve la lista de secciones de personalización ordenada por id.
    public List<SeccionDePersonalizacion> obtenerSeccionesPersonalizacion() throws Exception {
        EntityManager em = null;
        try {
            em = JPAUtil.getEntityManager();
            TypedQuery<SeccionDePersonalizacion> q = em.createQuery(
                "SELECT DISTINCT s FROM SeccionDePersonalizacion s " +
                "LEFT JOIN FETCH s.productosPersonalizable " +
                "ORDER BY s.id", 
                SeccionDePersonalizacion.class
            );
            return q.getResultList();
        } finally {
            if (em != null) em.close();
        }
    }

    // Asocia un producto existente a una sección (o la remueve) y persiste el cambio.
    public boolean guardarPersonalizableEnSeccion(ProductoPersonalizable producto) throws Exception {
        if (producto == null || producto.getId() == null) return false;
        EntityManager em = null;
        try {
            em = JPAUtil.getEntityManager();
            em.getTransaction().begin();
            ProductoPersonalizable p = em.find(ProductoPersonalizable.class, producto.getId());
            if (p == null) {
                em.getTransaction().rollback();
                return false;
            }
            if (producto.getSeccion() != null && producto.getSeccion().getId() != null) {
                SeccionDePersonalizacion s = em.find(SeccionDePersonalizacion.class, producto.getSeccion().getId());
                p.setSeccion(s);
            } else {
                p.setSeccion(null);
            }
            em.merge(p);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) em.getTransaction().rollback();
            throw e;
        } finally {
            if (em != null) em.close();
        }
    }

    // Sincroniza la sección de un producto (alias de guardarPersonalizableEnSeccion).
    public boolean actualizarSeccionPersonalizable(ProductoPersonalizable producto) throws Exception {
        return guardarPersonalizableEnSeccion(producto);
    }

    // Elimina la relación sección-producto para el producto indicado por id.
    public boolean eliminarPersonalizableDeSeccion(int id) throws Exception {
        EntityManager em = null;
        try {
            em = JPAUtil.getEntityManager();
            em.getTransaction().begin();
            ProductoPersonalizable p = em.find(ProductoPersonalizable.class, id);
            if (p == null) {
                em.getTransaction().rollback();
                return false;
            }
            p.setSeccion(null);
            em.merge(p);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) em.getTransaction().rollback();
            throw e;
        } finally {
            if (em != null) em.close();
        }
    }
}