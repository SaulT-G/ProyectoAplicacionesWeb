package com.dao;

import com.modelo.conection.PersistenciaBDD;
import com.modelo.entities.Direccion;
import com.modelo.entities.Comprador;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.ArrayList;
import java.util.List;

/**
 * DireccionDAO - Data Access Object para gestionar direcciones de clientes
 * Implementa los métodos según el diagrama de clases:
 * - registrarDireccion(idComprador: int, direccion: Direccion): boolean
 * - actualizarDireccion(idComprador: int, direccion: Direccion): boolean
 * - eliminarDireccion(idComprador: int): boolean
 * - guardarDireccionPedido(idPedido, direccion: Direccion): boolean
 */
public class DireccionDAO {

    /**
     * Método 2.1.5 del diagrama de secuencia: registrarDireccion(idComprador, direccion)
     * Registra una nueva dirección para un comprador
     * @param idComprador ID del comprador
     * @param direccion Direccion a registrar
     * @return true si se registró exitosamente, false si no
     */
    public boolean registrarDireccion(int idComprador, Direccion direccion) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            
            // Buscar el comprador
            Comprador comprador = em.find(Comprador.class, idComprador);
            if (comprador == null) {
                System.err.println("❌ Comprador no encontrado con ID: " + idComprador);
                return false;
            }
            
            // Asignar el comprador a la dirección y persistir
            direccion.setComprador(comprador);
            em.persist(direccion);
            
            tx.commit();
            System.out.println("✓ Dirección registrada exitosamente para comprador ID: " + idComprador);
            return true;
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            System.err.println("❌ Error al registrar dirección: " + e.getMessage());
            return false;
        } finally {
            em.close();
        }
    }

    /**
     * Método 2.2.5 del diagrama de secuencia: actualizarDireccion(idComprador, direccion)
     * Actualiza la dirección de un comprador
     * @param idComprador ID del comprador
     * @param direccion Direccion con datos actualizados
     * @return true si se actualizó exitosamente, false si no
     */
    public boolean actualizarDireccion(int idComprador, Direccion direccion) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            
            // Verificar que la dirección pertenece al comprador
            Comprador comprador = em.find(Comprador.class, idComprador);
            if (comprador == null) {
                System.err.println("❌ Comprador no encontrado con ID: " + idComprador);
                return false;
            }
            
            direccion.setComprador(comprador);
            em.merge(direccion);
            
            tx.commit();
            System.out.println("✓ Dirección actualizada exitosamente para comprador ID: " + idComprador);
            return true;
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            System.err.println("❌ Error al actualizar dirección: " + e.getMessage());
            return false;
        } finally {
            em.close();
        }
    }

    /**
     * Método 2.3.4 del diagrama de secuencia: eliminarDireccion(idComprador)
     * Elimina todas las direcciones de un comprador
     * @param idComprador ID del comprador
     * @return true si se eliminó exitosamente, false si no
     */
    public boolean eliminarDireccion(int idComprador) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            
            // Eliminar todas las direcciones del comprador
            int deleted = em.createQuery(
                "DELETE FROM Direccion d WHERE d.comprador.idUsuario = :idComprador"
            ).setParameter("idComprador", idComprador).executeUpdate();
            
            tx.commit();
            System.out.println("✓ " + deleted + " direcciones eliminadas para comprador ID: " + idComprador);
            return true;
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            System.err.println("❌ Error al eliminar direcciones: " + e.getMessage());
            return false;
        } finally {
            em.close();
        }
    }

    /**
     * Guarda la dirección de entrega para un pedido
     * Según diagrama: +guardarDireccionPedido(idPedido, direccion : Direccion) : boolean
     * @param idPedido ID del pedido
     * @param direccion Dirección de entrega
     * @return true si se guardó exitosamente
     */
    public boolean guardarDireccionPedido(int idPedido, Direccion direccion) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            
            // Persistir la dirección si es nueva (sin ID)
            if (direccion.getIdDireccion() == null) {
                em.persist(direccion);
                em.flush(); // Asegurar que se genera el ID
            } else {
                direccion = em.merge(direccion);
            }
            
            tx.commit();
            System.out.println("✓ Dirección de pedido guardada exitosamente con ID: " + direccion.getIdDireccion());
            return true;
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            System.err.println("❌ Error al guardar dirección del pedido: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            em.close();
        }
    }
}