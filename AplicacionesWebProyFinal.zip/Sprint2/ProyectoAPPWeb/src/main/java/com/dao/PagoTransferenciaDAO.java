package com.dao;

import com.modelo.conection.PersistenciaBDD;
import com.modelo.entities.PagoTransferencia;
import com.modelo.entities.Pedido;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.Date;

/**
 * ========================================================================
 * DAO: PagoTransferenciaDAO
 * ========================================================================
 * Según el diagrama de clases:
 * +guardarPago(idPago : int, monto : double, fechaPago : Date, banco : String, 
 *              titular : String, numeroCuenta : String, tipoCuenta : String, RUC : String) : boolean
 */
public class PagoTransferenciaDAO {

    private PagoTransferencia ultimoPago;

    /**
     * Guarda un pago de transferencia en la base de datos
     * Según diagrama: +guardarPago(idPago : int, monto : double, fechaPago : Date, 
     *                             banco : String, titular : String, numeroCuenta : String, 
     *                             tipoCuenta : String, RUC : String) : boolean
     */
    public boolean guardarPago(int idPago, double monto, Date fechaPago, String banco, 
                               String titular, String numeroCuenta, String tipoCuenta, String RUC) {
        PagoTransferencia pago = new PagoTransferencia();
        pago.setMonto(monto);
        pago.setFechaPago(fechaPago != null ? fechaPago : new Date());
        pago.setBanco(banco);
        pago.setTitular(titular);
        pago.setNumeroCuenta(numeroCuenta);
        pago.setTipoCuenta(tipoCuenta);
        pago.setRUC(RUC);
        return guardarPago(pago);
    }

    /**
     * Guarda un pago de transferencia completo con pedido y comprobante
     * Versión que recibe el objeto PagoTransferencia directamente
     */
    public boolean guardarPago(PagoTransferencia pago) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            tx = em.getTransaction();
            tx.begin();
            
            // Si hay un pedido asociado, recargarlo para que esté gestionado
            if (pago.getPedido() != null && pago.getPedido().getIdPedido() != null) {
                Pedido pedidoDb = em.find(Pedido.class, pago.getPedido().getIdPedido());
                pago.setPedido(pedidoDb);
            }
            
            // Asegurar fecha de pago
            if (pago.getFechaPago() == null) {
                pago.setFechaPago(new Date());
            }
            
            em.persist(pago);
            em.flush();
            
            this.ultimoPago = pago;
            
            tx.commit();
            System.out.println("✓ Pago guardado exitosamente con ID: " + pago.getIdPago());
            return true;
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            System.err.println("❌ Error al guardar pago: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            em.close();
        }
    }
}
