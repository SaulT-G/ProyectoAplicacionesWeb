package com.dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

import com.modelo.entities.Producto;

/**
 * ProductoDAO - Métodos según diagrama de robustez
 */
public class ProductoDAO {

    /**
     * MÉTODO 1 DEL DIAGRAMA: obtenerListadoDeProductos()
     * Obtiene la lista completa de productos
     */
    public List<Producto> obtenerListadoDeProductos() {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            TypedQuery<Producto> query = em.createQuery("SELECT p FROM Producto p ORDER BY p.id DESC", Producto.class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    /**
     * MÉTODO 2 DEL DIAGRAMA: actualizarProducto(nombre,desc,cat,stock,precio,img)
     * Actualiza la información de un producto existente
     */
    public void actualizarProducto(Producto p) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            // Si la categoría está detached, la re-obtenemos del contexto actual
            if (p.getCategoria() != null && p.getCategoria().getId() > 0) {
                com.modelo.entities.Categoria categoriaManaged = em.find(com.modelo.entities.Categoria.class, p.getCategoria().getId());
                p.setCategoria(categoriaManaged);
            }
            em.merge(p);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw new RuntimeException("Error al actualizar producto: " + e.getMessage(), e);
        } finally {
            em.close();
        }
    }

    /**
     * MÉTODO 4 DEL DIAGRAMA: eliminarProducto(id)
     * Elimina un producto de la base de datos
     */
    public void eliminarProducto(int id) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            Producto p = em.find(Producto.class, id);
            if (p != null) {
                em.remove(p);
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw new RuntimeException("Error al eliminar producto: " + e.getMessage(), e);
        } finally {
            em.close();
        }
    }

    /**
     * MÉTODO 5 DEL DIAGRAMA: obtenerDatosProducto(id)
     * Obtiene los detalles completos de un producto (para visualización)
     */
    public Producto obtenerDatosProducto(int id) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            return em.find(Producto.class, id);
        } finally {
            em.close();
        }
    }

    /**
     * Método auxiliar para guardar un nuevo producto
     */
    public void guardar(Producto p) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            // Si la categoría está detached, la re-obtenemos del contexto actual
            if (p.getCategoria() != null && p.getCategoria().getId() > 0) {
                com.modelo.entities.Categoria categoriaManaged = em.find(com.modelo.entities.Categoria.class, p.getCategoria().getId());
                p.setCategoria(categoriaManaged);
            }
            em.persist(p);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw new RuntimeException("Error al guardar producto: " + e.getMessage(), e);
        } finally {
            em.close();
        }
    }

    /**
     * Método auxiliar para obtener productos por categoría
     */
    public List<Producto> obtenerPorCategoria(int categoriaId) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            TypedQuery<Producto> query = em.createQuery(
                "SELECT p FROM Producto p WHERE p.categoria.id = :categoriaId ORDER BY p.id DESC", 
                Producto.class
            );
            query.setParameter("categoriaId", categoriaId);
            return query.getResultList();
        } finally {
            em.close();
        }
    }
}
