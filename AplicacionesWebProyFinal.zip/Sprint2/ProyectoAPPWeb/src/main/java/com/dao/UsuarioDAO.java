package com.dao;

import com.modelo.conection.PersistenciaBDD;
import com.modelo.entities.Comprador;
import com.modelo.entities.Usuario;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;

import java.util.regex.Pattern;

public class UsuarioDAO {

    // Usuario autenticado tras verificarCredenciales
    public Usuario usuarioAutenticado = null;

    // Email regex patrón:
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\\.)+[A-Za-z]{2,}$");
    // Nombre: letras (mayusculas y minusculas), espacios y guiones
    private static final Pattern NAME_PATTERN = Pattern.compile("^[A-Za-zÁÉÍÓÚáéíóúÑñ\\- ]+$");

    /**
     * Verifica las credenciales del usuario
     * Si las credenciales son válidas, setea `usuarioAutenticado` con el Usuario encontrado.
     * Si no son válidas lanza RuntimeException.
     */
    public void verificarCredenciales(String correo, String contrasena) {
        if (correo == null || correo.trim().isEmpty() || contrasena == null || contrasena.trim().isEmpty()) {
            throw new RuntimeException("Debe completar todos los campos");
        }

        // Trim inputs para evitar fallos causados por espacios al inicio/fin
        String correoTrim = correo.trim();
        String contrasenaTrim = contrasena.trim();

        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        try {
            TypedQuery<Usuario> query = em.createQuery(
                    "SELECT u FROM Usuario u WHERE u.correoElectronico = :correo AND u.contrasena = :contrasena",
                    Usuario.class);
            query.setParameter("correo", correoTrim);
            query.setParameter("contrasena", contrasenaTrim);

            Usuario usuario = null;
            try {
                usuario = query.getSingleResult();
            } catch (NoResultException e) {
                usuario = null;
            }

            if (usuario == null) {
                this.usuarioAutenticado = null;
                throw new RuntimeException("Correo o contraseña incorrectos");
            }

            this.usuarioAutenticado = usuario;
        } finally {
            em.close();
        }
    }

    /**
     * Registra un nuevo comprador
     * Realiza validaciones: formato correo, longitud minima contrasena, formato nombre.
     * Lanza RuntimeException en caso de error.
     */
    public void registrarNuevoComprador(int id, String nombre, String contrasena, String correo) {
        // Validaciones
        if (nombre == null || nombre.trim().isEmpty() ||
            correo == null || correo.trim().isEmpty() ||
            contrasena == null || contrasena.trim().isEmpty()) {
            throw new RuntimeException("Debe completar todos los campos obligatorios");
        }

        // Trim inputs para validaciones y persistencia
        String nombreTrim = nombre.trim();
        String correoTrim = correo.trim();
        String contrasenaTrim = contrasena.trim();

        if (!NAME_PATTERN.matcher(nombreTrim).matches()) {
            throw new RuntimeException("El nombre contiene caracteres no permitidos");
        }

        if (!EMAIL_PATTERN.matcher(correoTrim).matches()) {
            throw new RuntimeException("Formato de correo inválido");
        }

        if (contrasenaTrim.length() < 6) {
            throw new RuntimeException("La contraseña debe tener al menos 6 caracteres");
        }

        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        EntityTransaction tx = null;
        try {
            // Verificar que el correo no exista
            TypedQuery<Usuario> query = em.createQuery(
                    "SELECT u FROM Usuario u WHERE u.correoElectronico = :correo",
                    Usuario.class);
            query.setParameter("correo", correoTrim);

            try {
                Usuario existente = query.getSingleResult();
                if (existente != null) {
                    throw new RuntimeException("El correo electrónico ya está registrado");
                }
            } catch (NoResultException nro) {
                // no existe, continuar
            }

            // Crear objeto Comprador
            Comprador comprador = new Comprador();
            comprador.setNombre(nombreTrim);
            comprador.setCorreoElectronico(correoTrim);
            comprador.setContrasena(contrasenaTrim);
            comprador.setTelefono(null);
            comprador.setEstado("ACTIVO");
            comprador.setRol("COMPRADOR");

            tx = em.getTransaction();
            tx.begin();
            em.persist(comprador);
            tx.commit();

        } catch (RuntimeException e) {
            if (tx != null && tx.isActive()) tx.rollback();
            throw e;
        } catch (Exception e) {
            if (tx != null && tx.isActive()) tx.rollback();
            throw new RuntimeException(e.getMessage(), e);
        } finally {
            em.close();
        }
    }
}