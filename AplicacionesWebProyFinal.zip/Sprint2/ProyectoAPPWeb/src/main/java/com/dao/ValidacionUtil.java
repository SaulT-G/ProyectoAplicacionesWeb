package com.dao;

import com.modelo.conection.PersistenciaBDD;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

/**
 * Clase de utilidades para validaciones comunes
 * Centraliza las validaciones de datos para evitar código duplicado
 */
public class ValidacionUtil {

    /**
     * Verifica si un String está vacío o es nulo
     */
    public static boolean esVacio(String valor) {
        return valor == null || valor.trim().isEmpty();
    }

    /**
     * Verifica si un String NO está vacío
     */
    public static boolean noEsVacio(String valor) {
        return valor != null && !valor.trim().isEmpty();
    }

    /**
     * Valida formato de correo electrónico
     */
    public static boolean esCorreoValido(String correo) {
        if (esVacio(correo)) return false;
        return correo.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    }

    /**
     * Valida longitud mínima de una cadena
     */
    public static boolean cumpleLongitudMinima(String valor, int minimo) {
        return noEsVacio(valor) && valor.length() >= minimo;
    }

    /**
     * Valida los datos obligatorios de un cliente para registro
     * @return Mensaje de error o null si todo está correcto
     */
    public static String validarDatosClienteRegistro(String nombre, String correo, 
            String contrasena, String calle, String provincia, String ciudad) {
        
        if (esVacio(nombre)) {
            return "El nombre es obligatorio";
        }
        if (esVacio(correo)) {
            return "El correo electrónico es obligatorio";
        }
        if (!esCorreoValido(correo)) {
            return "El formato del correo electrónico no es válido";
        }
        if (esVacio(contrasena)) {
            return "La contraseña es obligatoria";
        }
        if (!cumpleLongitudMinima(contrasena, 3)) {
            return "La contraseña debe tener al menos 3 caracteres";
        }
        if (esVacio(calle)) {
            return "La calle es obligatoria";
        }
        if (esVacio(provincia)) {
            return "La provincia es obligatoria";
        }
        if (esVacio(ciudad)) {
            return "La ciudad es obligatoria";
        }
        return null;
    }

    /**
     * Valida los datos obligatorios de un cliente para actualización
     * @return Mensaje de error o null si todo está correcto
     */
    public static String validarDatosClienteActualizacion(String nombre, String correo, 
            String calle, String provincia, String ciudad) {
        
        if (esVacio(nombre)) {
            return "El nombre es obligatorio";
        }
        if (esVacio(correo)) {
            return "El correo electrónico es obligatorio";
        }
        if (!esCorreoValido(correo)) {
            return "El formato del correo electrónico no es válido";
        }
        if (esVacio(calle)) {
            return "La calle es obligatoria";
        }
        if (esVacio(provincia)) {
            return "La provincia es obligatoria";
        }
        if (esVacio(ciudad)) {
            return "La ciudad es obligatoria";
        }
        return null;
    }

    /**
     * Devuelve el valor o una cadena vacía si es nulo
     */
    public static String valorOVacio(String valor) {
        return valor != null ? valor : "";
    }

    /**
     * Verifica si existe un correo electrónico registrado en la tabla Comprador
     * @param correo Correo a verificar
     * @return true si existe, false si no
     */
    public static boolean existeCorreoComprador(String correo) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        try {
            TypedQuery<Long> query = em.createQuery(
                "SELECT COUNT(c) FROM Comprador c WHERE c.correoElectronico = :correo",
                Long.class
            );
            query.setParameter("correo", correo);
            return query.getSingleResult() > 0;
        } catch (Exception e) {
            return false;
        } finally {
            em.close();
        }
    }

    /**
     * Verifica si existe un correo registrado excluyendo un ID específico (para actualizaciones)
     * @param correo Correo a verificar
     * @param idExcluir ID del cliente a excluir de la verificación
     * @return true si existe otro cliente con ese correo, false si no
     */
    public static boolean existeCorreoCompradorExcluyendoId(String correo, int idExcluir) {
        EntityManager em = PersistenciaBDD.getInstance().getEntityManager();
        try {
            TypedQuery<Long> query = em.createQuery(
                "SELECT COUNT(c) FROM Comprador c WHERE c.correoElectronico = :correo AND c.idUsuario != :id",
                Long.class
            );
            query.setParameter("correo", correo);
            query.setParameter("id", idExcluir);
            return query.getSingleResult() > 0;
        } catch (Exception e) {
            return false;
        } finally {
            em.close();
        }
    }

    /**
     * Valida si el formato del archivo es permitido (imágenes JPG, PNG o PDF)
     * @param contentType Tipo de contenido del archivo
     * @param fileName Nombre del archivo
     * @return true si el formato es válido, false si no
     */
    public static boolean esFormatoValido(String contentType, String fileName) {
        if (contentType == null) return false;
        
        String lowerType = contentType.toLowerCase();
        String lowerName = fileName != null ? fileName.toLowerCase() : "";
        
        return lowerType.startsWith("image/jpeg") || 
               lowerType.startsWith("image/jpg") || 
               lowerType.startsWith("image/png") || 
               lowerType.equals("application/pdf") ||
               lowerName.endsWith(".jpg") ||
               lowerName.endsWith(".jpeg") ||
               lowerName.endsWith(".png") ||
               lowerName.endsWith(".pdf");
    }

    // =========================================================================
    // VALIDACIONES PARA PRODUCTOS
    // =========================================================================

    /**
     * Valida el nombre del producto
     * @param nombre Nombre del producto
     * @return Mensaje de error o null si es válido
     */
    public static String validarNombreProducto(String nombre) {
        if (esVacio(nombre)) {
            return "El nombre del producto es obligatorio";
        }
        if (nombre.trim().length() < 2) {
            return "El nombre del producto debe tener al menos 2 caracteres";
        }
        if (nombre.trim().length() > 100) {
            return "El nombre del producto no puede exceder 100 caracteres";
        }
        return null;
    }

    /**
     * Valida la descripción del producto
     * @param descripcion Descripción del producto
     * @return Mensaje de error o null si es válido
     */
    public static String validarDescripcionProducto(String descripcion) {
        if (esVacio(descripcion)) {
            return "La descripción del producto es obligatoria";
        }
        if (descripcion.trim().length() < 10) {
            return "La descripción debe tener al menos 10 caracteres";
        }
        if (descripcion.trim().length() > 500) {
            return "La descripción no puede exceder 500 caracteres";
        }
        return null;
    }

    /**
     * Valida el precio del producto
     * @param precioStr Precio como cadena
     * @return Mensaje de error o null si es válido
     */
    public static String validarPrecioProducto(String precioStr) {
        if (esVacio(precioStr)) {
            return "El precio es obligatorio";
        }
        try {
            double precio = Double.parseDouble(precioStr);
            if (precio <= 0) {
                return "El precio debe ser mayor a 0";
            }
            if (precio > 999999.99) {
                return "El precio no puede exceder 999,999.99";
            }
        } catch (NumberFormatException e) {
            return "El precio debe ser un número válido";
        }
        return null;
    }

    /**
     * Valida el stock del producto
     * @param stockStr Stock como cadena
     * @return Mensaje de error o null si es válido
     */
    public static String validarStockProducto(String stockStr) {
        if (esVacio(stockStr)) {
            return "El stock es obligatorio";
        }
        try {
            int stock = Integer.parseInt(stockStr);
            if (stock < 0) {
                return "El stock no puede ser negativo";
            }
            if (stock > 99999) {
                return "El stock no puede exceder 99,999 unidades";
            }
        } catch (NumberFormatException e) {
            return "El stock debe ser un número entero válido";
        }
        return null;
    }

    /**
     * Valida la categoría del producto
     * @param categoriaIdStr ID de categoría como cadena
     * @return Mensaje de error o null si es válido
     */
    public static String validarCategoriaProducto(String categoriaIdStr) {
        if (esVacio(categoriaIdStr)) {
            return "Debe seleccionar una categoría";
        }
        try {
            int categoriaId = Integer.parseInt(categoriaIdStr);
            if (categoriaId <= 0) {
                return "Debe seleccionar una categoría válida";
            }
        } catch (NumberFormatException e) {
            return "Categoría inválida";
        }
        return null;
    }

    /**
     * Valida todos los datos del producto para registro
     * @return Mensaje de error o null si todo está correcto
     */
    public static String validarDatosProductoRegistro(String nombre, String descripcion, 
            String precio, String stock, String categoriaId) {
        
        String error = validarNombreProducto(nombre);
        if (error != null) return error;
        
        error = validarDescripcionProducto(descripcion);
        if (error != null) return error;
        
        error = validarPrecioProducto(precio);
        if (error != null) return error;
        
        error = validarStockProducto(stock);
        if (error != null) return error;
        
        error = validarCategoriaProducto(categoriaId);
        if (error != null) return error;
        
        return null;
    }

    /**
     * Valida todos los datos del producto para actualización
     * @return Mensaje de error o null si todo está correcto
     */
    public static String validarDatosProductoActualizacion(String nombre, String descripcion, 
            String precio, String stock, String categoriaId) {
        // Las mismas validaciones que para registro
        return validarDatosProductoRegistro(nombre, descripcion, precio, stock, categoriaId);
    }

    // =========================================================================
    // VALIDACIONES PARA PRODUCTOS PERSONALIZABLES
    // =========================================================================

    /**
     * Valida la sección de personalización
     * @param seccionIdStr ID de sección como cadena
     * @return Mensaje de error o null si es válido
     */
    public static String validarSeccionPersonalizable(String seccionIdStr) {
        if (esVacio(seccionIdStr)) {
            return null; // Sección es opcional
        }
        try {
            int seccionId = Integer.parseInt(seccionIdStr);
            if (seccionId <= 0) {
                return "Debe seleccionar una sección válida";
            }
        } catch (NumberFormatException e) {
            return "Sección inválida";
        }
        return null;
    }

    /**
     * Valida todos los datos del producto personalizable para registro
     * @return Mensaje de error o null si todo está correcto
     */
    public static String validarDatosPersonalizableRegistro(String nombre, String descripcion, 
            String precio, String stock, String seccionId) {
        
        String error = validarNombreProducto(nombre);
        if (error != null) return error;
        
        // Descripción puede ser opcional para personalizables
        if (noEsVacio(descripcion) && descripcion.trim().length() > 500) {
            return "La descripción no puede exceder 500 caracteres";
        }
        
        error = validarPrecioProducto(precio);
        if (error != null) return error;
        
        error = validarStockProducto(stock);
        if (error != null) return error;
        
        error = validarSeccionPersonalizable(seccionId);
        if (error != null) return error;
        
        return null;
    }

    /**
     * Valida todos los datos del producto personalizable para actualización
     * @return Mensaje de error o null si todo está correcto
     */
    public static String validarDatosPersonalizableActualizacion(String nombre, String descripcion, 
            String precio, String stock, String seccionId) {
        return validarDatosPersonalizableRegistro(nombre, descripcion, precio, stock, seccionId);
    }

    /**
     * Valida tamaño de imagen contra el límite de la base de datos
     * @param partSize Tamaño del archivo en bytes
     * @param dbMax Límite máximo permitido por la BD
     * @return Mensaje de error o null si es válido
     */
    public static String validarTamanoImagenDB(long partSize, long dbMax) {
        if (dbMax > 0 && partSize > dbMax) {
            return "El archivo es demasiado grande para la configuración del servidor DB (" 
                   + partSize + " bytes > max_allowed_packet=" + dbMax 
                   + "). Incrementa 'max_allowed_packet' en MySQL o sube una imagen más pequeña.";
        }
        return null;
    }

    /**
     * Detecta el MIME type básico de una imagen a partir de sus bytes (jpg, png, gif, webp).
     * @param bytes Array de bytes de la imagen
     * @return Tipo MIME detectado o null si no se reconoce
     */
    public static String detectarMimeImagen(byte[] bytes) {
        if (bytes == null || bytes.length < 8) return null;
        if ((bytes[0] & 0xFF) == 0xFF && (bytes[1] & 0xFF) == 0xD8 && (bytes[2] & 0xFF) == 0xFF) return "image/jpeg";
        if ((bytes[0] & 0xFF) == 0x89 && (bytes[1] & 0xFF) == 0x50 && (bytes[2] & 0xFF) == 0x4E && (bytes[3] & 0xFF) == 0x47) return "image/png";
        if ((bytes[0] & 0xFF) == 0x47 && (bytes[1] & 0xFF) == 0x49 && (bytes[2] & 0xFF) == 0x46) return "image/gif";
        if ((bytes[0] & 0xFF) == 0x52 && (bytes[1] & 0xFF) == 0x49 && (bytes[2] & 0xFF) == 0x46 && (bytes[8] & 0xFF) == 0x57) return "image/webp";
        return null;
    }

    /**
     * Escapa cadenas para JSON simple (evita romper las comillas y saltos de línea).
     * @param s Cadena a escapar
     * @return Cadena escapada para JSON
     */
    public static String escaparParaJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }
}
