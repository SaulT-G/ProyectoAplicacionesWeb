package com.dao;

import jakarta.persistence.EntityManager;

import java.util.List;

import com.modelo.entities.ProductoPersonalizable;
import com.modelo.entities.ProductoPersonalizado;
import com.modelo.entities.SeccionDePersonalizacion;

/**
 * DAO: ProductoPersonalizadoDAO
 * Maneja la persistencia de productos personalizados por el comprador.
 * Usa JPA/Hibernate para las operaciones CRUD.
 */
public class ProductoPersonalizadoDAO {

    /**
     * Guarda un producto personalizado con las opciones seleccionadas
     * @param seccion - Sección de personalización
     * @param opciones - Lista de opciones seleccionadas
     * @return ProductoPersonalizado guardado
     */
    public ProductoPersonalizado guardarProductoPersonalizado(SeccionDePersonalizacion seccion, List<ProductoPersonalizable> opciones) throws Exception {
        EntityManager em = null;
        try {
            em = JPAUtil.getEntityManager();
            em.getTransaction().begin();
            
            ProductoPersonalizado pp = new ProductoPersonalizado();
            
            // Asegurar que la sección esté managed
            if (seccion != null && seccion.getId() != null) {
                SeccionDePersonalizacion seccionManaged = em.find(SeccionDePersonalizacion.class, seccion.getId());
                pp.setSeccion(seccionManaged);
            }
            
            // Calcular precio total sumando precios de opciones
            double precioTotal = 0.0;
            if (opciones != null && !opciones.isEmpty()) {
                for (ProductoPersonalizable opcion : opciones) {
                    precioTotal += opcion.getPrecio();
                }
            }
            pp.setPrecio(precioTotal);
            pp.setOpciones(opciones);
            
            em.persist(pp);
            em.getTransaction().commit();
            
            return pp;
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw e;
        } finally {
            if (em != null) em.close();
        }
    }
}
