package com.controlador;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

import com.dao.CarritoComprasDAO;
import com.dao.CategoriaDAO;
import com.dao.ProductoDAO;
import com.modelo.entities.CarritoCompras;
import com.modelo.entities.Categoria;
import com.modelo.entities.ItemCarrito;
import com.modelo.entities.Producto;

/**
 * ========================================================================
 * CONTROLADOR: ControladorCatalogo (Servlet MVC)
 * ========================================================================
 * 
 * Este servlet implementa el patrón MVC para el caso de uso "Explorar Catálogo"
 * según los diagramas de secuencia y robustez proporcionados.
 * 
 * FLUJO DEL DIAGRAMA DE SECUENCIA:
 * 1. accederAlCatalogo() - Comprador accede al catálogo
 *    1.1. getInstance(): ServiciorBDD - Obtiene instancia del servicio
 *    1.1.1. obtenerProductos(): List<Producto> - Obtiene lista de productos
 *    1.1.2. listar(productos) - Lista productos en la vista
 * 
 * 2. obtenerDetalles(id) - Comprador consulta detalles de un producto
 *    2.1. obtenerInfoProducto(id): Producto - Obtiene información del producto
 *    2.1.1. mostrarDetalles(producto) - Muestra detalles en la vista
 * 
 * 3. agregarAlCarrito(id) - Comprador agrega producto al carrito
 *    3.1. enviarInfoProducto(id) - Envía información al controlador de pedido
 * 
 * 4. filtrarBusqueda(categoria) - Comprador filtra por categoría
 *    4.1. obtenerCategorias(): List<Categoria> - Obtiene categorías
 *    4.2. obtenerProductosCategoria(categoria) - Filtra productos
 *    4.3. listarPorFiltro(categoria) - Lista productos filtrados
 * 
 * @author
 * @version 1.0
 */
@WebServlet("/ControladorCatalogo")
public class ControladorCatalogo extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // DAOs para acceso a datos
    private ProductoDAO productoDAO;
    private CategoriaDAO categoriaDAO;
    private CarritoComprasDAO carritoComprasDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        // Inicializar DAOs (Singleton - getInstance)
        productoDAO = new ProductoDAO();
        categoriaDAO = new CategoriaDAO();
        carritoComprasDAO = new CarritoComprasDAO();
    }

    /**
     * Procesa peticiones GET
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Obtener acción del parámetro
        String accion = request.getParameter("accion");
        
        if (accion == null) {
            accion = "explorar"; // Acción por defecto
        }
        
        switch (accion) {
            case "explorar":
            case "listar":
                explorarCatalogoProductos(request, response);
                break;
            case "verMas":
            case "detalle":
                verMas(request, response);
                break;
            case "filtrar":
            case "solicitarFiltracion":
                solicitarFiltracion(request, response);
                break;
            case "agregarCarrito":
                agregarAlCarrito(request, response);
                break;
            default:
                explorarCatalogoProductos(request, response);
                break;
        }
    }

    /**
     * Procesa peticiones POST
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String accion = request.getParameter("accion");
        
        if ("agregarCarrito".equals(accion)) {
            agregarAlCarrito(request, response);
        } else {
            doGet(request, response);
        }
    }

    /**
     * ========================================================================
     * MÉTODO: explorarCatalogoProductos() - Retorna List<Producto>
     * ========================================================================
     * Obtiene y muestra todos los productos del catálogo
     * Según el diagrama de clases: +explorarCatalogoProductos() : List<Producto>
     */
    private void explorarCatalogoProductos(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            // Obtener lista de productos usando ProductoDAO (ORM/JPA)
            List<Producto> listaProductos = productoDAO.obtenerListadoDeProductos();
            
            // Obtener categorías para los filtros
            List<Categoria> listaCategorias = categoriaDAO.obtenerCategorias();
            
            // Enviar datos a la vista
            request.setAttribute("productos", listaProductos);
            request.setAttribute("categorias", listaCategorias);
            
            // Forward a la vista del catálogo
            request.getRequestDispatcher("/vista/Catalogo.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error al cargar el catálogo: " + e.getMessage());
            request.getRequestDispatcher("/vista/error.jsp").forward(request, response);
        }
    }

    /**
     * ========================================================================
     * MÉTODO: verMas(id: int) - Retorna Producto
     * ========================================================================
     * Muestra los detalles completos de un producto específico
     * Según el diagrama de clases: +verMas(id : int) : Producto
     */
    private void verMas(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            // Obtener ID del producto desde el parámetro
            String idParam = request.getParameter("id");
            int id = Integer.parseInt(idParam);
            
            // Obtener información del producto usando ProductoDAO (ORM)
            Producto producto = productoDAO.obtenerDatosProducto(id);
            
            if (producto != null) {
                // Enviar producto a la vista de detalle
                request.setAttribute("producto", producto);
                request.getRequestDispatcher("/vista/DetalleProducto.jsp").forward(request, response);
            } else {
                request.setAttribute("error", "Producto no encontrado");
                request.getRequestDispatcher("/vista/error.jsp").forward(request, response);
            }
            
        } catch (NumberFormatException e) {
            request.setAttribute("error", "ID de producto inválido");
            request.getRequestDispatcher("/vista/error.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error al obtener detalles: " + e.getMessage());
            request.getRequestDispatcher("/vista/error.jsp").forward(request, response);
        }
    }

    /**
     * ========================================================================
     * MÉTODO: agregarAlCarrito(producto) - Diagrama de Robustez flujoexplorarproducto
     * ========================================================================
     * Implementa el flujo según diagrama de robustez:
     * 2.2.1: agregarAlCarrito(producto)
     * 2.2.2: confirmarProductoAlCarrito
     * 2.2.3: agregarProducto(itemventaid):itemcarrito
     * 2.2.4: guardarItemCarrito(itemcarrito)
     * 2.2.5: agregarItemAlCarrito(itemcarrito) -> CarritoCompras
     * 
     * Agrega un producto al carrito de compras usando CarritoCompras e ItemCarrito
     */
    private void agregarAlCarrito(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            // Obtener ID del producto
            String idParam = request.getParameter("id");
            int id = Integer.parseInt(idParam);
            
            // Obtener el producto completo (actualizado de la BD)
            Producto producto = productoDAO.obtenerDatosProducto(id);
            
            if (producto != null) {
                // CONTROL DE STOCK: Verificar si hay stock disponible
                if (producto.getStock() <= 0) {
                    request.setAttribute("error", "❌ Lo sentimos, el producto '" + producto.getNombre() + "' no tiene stock disponible.");
                    request.setAttribute("titulo", "Sin Stock Disponible");
                    request.setAttribute("volverUrl", request.getContextPath() + "/ControladorCatalogo?accion=explorar");
                    request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
                    return;
                }
                
                // Obtener sesión actual
                HttpSession session = request.getSession();
                
                // Obtener carrito de la sesión (CarritoCompras)
                CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
                
                // Si no existe carrito, crear uno nuevo
                if (carrito == null) {
                    carrito = new CarritoCompras();
                }
                
                // CONTROL DE STOCK: Verificar cantidad actual en el carrito vs stock disponible
                int cantidadEnCarrito = 0;
                for (ItemCarrito item : carrito.getItems()) {
                    if (item.getItem() != null && item.getItem().getId() == producto.getId()) {
                        cantidadEnCarrito = item.getCantidad();
                        break;
                    }
                }
                
                if (cantidadEnCarrito >= producto.getStock()) {
                    request.setAttribute("error", "❌ No puedes agregar más unidades de '" + producto.getNombre() + "'. Stock máximo disponible: " + producto.getStock());
                    request.setAttribute("titulo", "Stock Límite Alcanzado");
                    request.setAttribute("volverUrl", request.getContextPath() + "/ControladorCatalogo?accion=explorar");
                    request.setAttribute("carritoUrl", request.getContextPath() + "/GestionarCarrito?action=acceder");
                    request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
                    return;
                }
                
                // 2.2.3: agregarProducto(itemventaid):itemcarrito - Crear ItemCarrito
                ItemCarrito itemCarrito = new ItemCarrito(producto);
                
                // 2.2.4: guardarItemCarrito(itemcarrito)
                // 2.2.5: agregarItemAlCarrito(itemcarrito)
                carritoComprasDAO.guardarItemCarrito(carrito, itemCarrito);
                
                // Guardar carrito en sesión
                session.setAttribute("carritoCompras", carrito);
                
                // 2.2.2: confirmarProductoAlCarrito - Mostrar mensaje de confirmación
                request.setAttribute("mensaje", "✓ Producto '" + producto.getNombre() + "' agregado al carrito exitosamente");
                request.setAttribute("tipoMensaje", "exito");
                request.setAttribute("volverUrl", request.getContextPath() + "/ControladorCatalogo?accion=explorar");
                request.setAttribute("carritoUrl", request.getContextPath() + "/GestionarCarrito?action=acceder");
                
                // Redirigir al mensaje de confirmación
                request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
            } else {
                request.setAttribute("error", "Producto no encontrado");
                request.getRequestDispatcher("/vista/error.jsp").forward(request, response);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error al agregar al carrito: " + e.getMessage());
            request.getRequestDispatcher("/vista/error.jsp").forward(request, response);
        }
    }

    /**
     * ========================================================================
     * MÉTODO: solicitarFiltracion(categoria: Categoria) - Retorna List<Producto>
     * ========================================================================
     * Solicita filtrar productos por categoría
     * Según el diagrama de clases: +solicitarFiltracion(categoria : Categoria) : List<Producto>
     */
    private void solicitarFiltracion(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            // Obtener categoría del parámetro
            String categoriaParam = request.getParameter("categoria");
            
            // Obtener todas las categorías para mostrar en los filtros
            List<Categoria> listaCategorias = categoriaDAO.obtenerCategorias();
            
            List<Producto> listaProductos;
            
            if (categoriaParam != null && !categoriaParam.isEmpty()) {
                int categoriaId = Integer.parseInt(categoriaParam);
                
                // Llamar a buscarPorCategoria
                listaProductos = buscarPorCategoria(categoriaId);
            } else {
                // Si no hay categoría, mostrar todos
                listaProductos = productoDAO.obtenerListadoDeProductos();
            }
            
            // Enviar datos a la vista
            request.setAttribute("productos", listaProductos);
            request.setAttribute("categorias", listaCategorias);
            request.setAttribute("categoriaSeleccionada", categoriaParam);
            
            // Forward a la vista del catálogo
            request.getRequestDispatcher("/vista/Catalogo.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error al filtrar productos: " + e.getMessage());
            request.getRequestDispatcher("/vista/error.jsp").forward(request, response);
        }
    }
    
    /**
     * ========================================================================
     * MÉTODO: buscarPorCategoria(categoria: Categoria) - Retorna List<Producto>
     * ========================================================================
     * Busca productos filtrados por una categoría específica
     * Según el diagrama de clases: +buscarPorCategoria(categoria : Categoria) : List<Producto>
     */
    private List<Producto> buscarPorCategoria(int categoriaId) {
        // Usa ProductoDAO con JPA/Hibernate (ORM)
        // SQL generado: SELECT * FROM producto WHERE categoria_id = ? ORDER BY id DESC
        return productoDAO.obtenerPorCategoria(categoriaId);
    }
}
