package com.controlador;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

import com.dao.CompradorDAO;
import com.dao.DireccionDAO;
import com.dao.ValidacionUtil;
import com.modelo.entities.Comprador;
import com.modelo.entities.Direccion;

/**
 * CONTROLADOR: GestionarClientesServlet
 * Implementa el flujo de Gestionar Clientes según los diagramas de robustez y secuencia.
 * 
 * Métodos del diagrama:
 * - solicitarGestionDeClientes(): void
 * - agregarCliente(): void
 * - registrarInfoCliente(id, nombre, correo, telefono, direccion): void
 * - editarCliente(id): void
 * - actualizarInfoCliente(nombre, correo, telefono, direccion): void
 * - eliminarCliente(id): void
 * - verCliente(id): void
 * - buscarCliente(filtro): void
 */
@WebServlet(name = "GestionarClientesServlet", urlPatterns = {"/admin/clientes"})
public class GestionarClientesServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private CompradorDAO clienteDAO;
    private DireccionDAO direccionDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        clienteDAO = new CompradorDAO();
        direccionDAO = new DireccionDAO();
    }

    /**
     * Maneja las solicitudes GET
     * Acciones: listar, agregar (formulario), editar (formulario), ver, eliminar, buscar
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        try {
            if ("add".equals(action)) {
                // 4.1.1 Agregar cliente - mostrar formulario
                agregarCliente(request, response);
            } else if ("edit".equals(action)) {
                // 4.2.1 Editar cliente - mostrar formulario con datos
                int id = Integer.parseInt(request.getParameter("id"));
                editarCliente(request, response, id);
            } else if ("view".equals(action)) {
                // 4.4.1 Ver cliente - mostrar datos
                int id = Integer.parseInt(request.getParameter("id"));
                verCliente(request, response, id);
            } else if ("delete".equals(action)) {
                // 4.3.1 Eliminar cliente - confirmación ya hecha en JS
                int id = Integer.parseInt(request.getParameter("id"));
                eliminarCliente(request, response, id);
            } else if ("search".equals(action)) {
                // 4.5.1 Buscar cliente
                String filtroNombre = request.getParameter("nombre");
                String filtroEstado = request.getParameter("estado");
                buscarCliente(request, response, filtroNombre, filtroEstado);
            } else {
                // Por defecto: listar todos los clientes
                solicitarGestionDeClientes(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error: " + e.getMessage());
            solicitarGestionDeClientes(request, response);
        }
    }

    /**
     * Maneja las solicitudes POST
     * Acciones: registrar, actualizar, confirmar eliminación
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        
        try {
            if ("insert".equals(action) || "save".equals(action)) {
                // 4.1.3 Registrar información del cliente
                registrarInfoCliente(request, response);
            } else if ("update".equals(action)) {
                // 4.2.3 Actualizar información del cliente
                actualizarInfoCliente(request, response);
            } else if ("delete".equals(action)) {
                // 4.3.3 Confirmar eliminación del cliente
                int id = Integer.parseInt(request.getParameter("id"));
                eliminarCliente(request, response, id);
            } else if ("search".equals(action)) {
                // 4.5.1 Buscar cliente (POST)
                String filtro = request.getParameter("filtro");
                buscarCliente(request, response, filtro, null);
            } else {
                solicitarGestionDeClientes(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error: " + e.getMessage());
            solicitarGestionDeClientes(request, response);
        }
    }

    // =========================================================================
    // MÉTODO 1: solicitarGestionDeClientes() - Diagrama de secuencia paso 1
    // =========================================================================
    /**
     * Solicita la gestión de clientes mostrando el listado completo
     * Diagrama de secuencia: 1.1 obtenerListadoDeClientes() -> 1.1.1 mostrarListadoDeClientes()
     */
    private void solicitarGestionDeClientes(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // 1.1 Obtener listado de clientes del DAO
        List<Comprador> clientes = clienteDAO.obtenerListadoDeClientes();
        
        // 1.1.1 Mostrar listado de clientes en la vista
        request.setAttribute("clientes", clientes);
        request.getRequestDispatcher("/vista/ListaClientes.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO 2: agregarCliente() - Diagrama de secuencia paso 2
    // =========================================================================
    /**
     * Muestra el formulario para agregar un nuevo cliente
     * Diagrama de secuencia: 2.1 mostrarFormularioRegistroCliente()
     */
    private void agregarCliente(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // 2.1 Mostrar formulario de registro de cliente
        request.setAttribute("cliente", new Comprador());
        request.setAttribute("direccion", new Direccion());
        request.getRequestDispatcher("/vista/FormularioRegistrarCliente.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO 3: registrarInfoCliente() - Diagrama de secuencia paso 3
    // =========================================================================
    /**
     * Registra la información del nuevo cliente
     * Diagrama de secuencia: 
     * 3.1 guardarRegistro(cliente) 
     * 3.2 registrarDireccion(idComprador, direccion)
     * 3.3 solicitarGestionDeClientes()
     */
    private void registrarInfoCliente(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Obtener parámetros del formulario
        String nombre = request.getParameter("nombre");
        String correo = request.getParameter("correo");
        String telefono = request.getParameter("telefono");
        String contrasena = request.getParameter("contrasena");
        String estado = request.getParameter("estado");
        
        // Datos de dirección
        String calle = request.getParameter("calle");
        String provincia = request.getParameter("provincia");
        String ciudad = request.getParameter("ciudad");
        String codigoPostal = request.getParameter("codigoPostal");
        String referencia = request.getParameter("referencia");
        
        // 4.1.4 Validar información ingresada usando clase de utilidades
        String error = ValidacionUtil.validarDatosClienteRegistro(nombre, correo, contrasena, calle, provincia, ciudad);
        
        if (error != null) {
            // 5.2 Informar datos pendientes
            request.setAttribute("error", error);
            // Crear cliente temporal para mantener datos
            Comprador clienteTemp = new Comprador();
            clienteTemp.setNombre(ValidacionUtil.valorOVacio(nombre));
            clienteTemp.setCorreoElectronico(ValidacionUtil.valorOVacio(correo));
            clienteTemp.setTelefono(ValidacionUtil.valorOVacio(telefono));
            clienteTemp.setContrasena(ValidacionUtil.valorOVacio(contrasena));
            clienteTemp.setEstado(ValidacionUtil.noEsVacio(estado) ? estado : "ACTIVO");
            request.setAttribute("cliente", clienteTemp);
            // Crear dirección temporal para mantener datos
            Direccion direccionTemp = new Direccion();
            direccionTemp.setCalle(ValidacionUtil.valorOVacio(calle));
            direccionTemp.setProvincia(ValidacionUtil.valorOVacio(provincia));
            direccionTemp.setCiudad(ValidacionUtil.valorOVacio(ciudad));
            direccionTemp.setCodigoPostal(ValidacionUtil.valorOVacio(codigoPostal));
            direccionTemp.setReferencia(ValidacionUtil.valorOVacio(referencia));
            request.setAttribute("direccion", direccionTemp);
            request.getRequestDispatcher("/vista/FormularioRegistrarCliente.jsp").forward(request, response);
            return;
        }
        
        // Verificar si el correo ya existe
        if (ValidacionUtil.existeCorreoComprador(correo)) {
            request.setAttribute("error", "El correo electrónico ya está registrado");
            // Crear cliente temporal para mantener datos
            Comprador clienteTemp = new Comprador();
            clienteTemp.setNombre(ValidacionUtil.valorOVacio(nombre));
            clienteTemp.setCorreoElectronico(ValidacionUtil.valorOVacio(correo));
            clienteTemp.setTelefono(ValidacionUtil.valorOVacio(telefono));
            clienteTemp.setContrasena(ValidacionUtil.valorOVacio(contrasena));
            clienteTemp.setEstado(ValidacionUtil.noEsVacio(estado) ? estado : "ACTIVO");
            request.setAttribute("cliente", clienteTemp);
            // Crear dirección temporal para mantener datos
            Direccion direccionTemp = new Direccion();
            direccionTemp.setCalle(ValidacionUtil.valorOVacio(calle));
            direccionTemp.setProvincia(ValidacionUtil.valorOVacio(provincia));
            direccionTemp.setCiudad(ValidacionUtil.valorOVacio(ciudad));
            direccionTemp.setCodigoPostal(ValidacionUtil.valorOVacio(codigoPostal));
            direccionTemp.setReferencia(ValidacionUtil.valorOVacio(referencia));
            request.setAttribute("direccion", direccionTemp);
            request.getRequestDispatcher("/vista/FormularioRegistrarCliente.jsp").forward(request, response);
            return;
        }
        
        // 4.1.5 Registrar cliente
        Comprador cliente = new Comprador(nombre, correo, contrasena, telefono, estado != null ? estado : "ACTIVO");
        
        // Crear y agregar dirección
        Direccion direccion = new Direccion(calle, provincia, ciudad, codigoPostal, referencia);
        cliente.agregarDireccion(direccion);
        
        // 3.1 Guardar registro
        clienteDAO.guardarRegistro(cliente);
        
        // 4.1.6 Mostrar mensaje de éxito y volver al listado
        request.setAttribute("mensaje", "Cliente '" + nombre + "' registrado exitosamente");
        
        // 3.3 Solicitar gestión de clientes (volver al listado)
        solicitarGestionDeClientes(request, response);
    }

    // =========================================================================
    // MÉTODO 4: editarCliente(id) - Diagrama de secuencia paso 4
    // =========================================================================
    /**
     * Muestra el formulario de edición con los datos del cliente
     * Diagrama de secuencia: 4.1 mostrarFormularioEditarCliente()
     */
    private void editarCliente(HttpServletRequest request, HttpServletResponse response, int id) 
            throws ServletException, IOException {
        // Obtener datos del cliente
        Comprador cliente = clienteDAO.obtenerDatosCliente(id);
        
        if (cliente == null) {
            request.setAttribute("error", "Cliente no encontrado");
            solicitarGestionDeClientes(request, response);
            return;
        }
        
        // 4.1 Mostrar formulario de editar cliente
        request.setAttribute("cliente", cliente);
        
        // Obtener la dirección principal si existe
        Direccion direccion = cliente.getDireccionPrincipal();
        request.setAttribute("direccion", direccion != null ? direccion : new Direccion());
        
        request.getRequestDispatcher("/vista/FormularioEditarCliente.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO 5: actualizarInfoCliente() - Diagrama de secuencia paso 5
    // =========================================================================
    /**
     * Actualiza la información del cliente
     * Diagrama de secuencia:
     * 5.1 actualizarCliente(cliente)
     * 5.2 actualizarDireccion(idComprador, direccion)
     */
    private void actualizarInfoCliente(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        int id = Integer.parseInt(request.getParameter("id"));
        
        // Obtener parámetros del formulario
        String nombre = request.getParameter("nombre");
        String correo = request.getParameter("correo");
        String telefono = request.getParameter("telefono");
        String contrasena = request.getParameter("contrasena");
        String estado = request.getParameter("estado");
        
        // Datos de dirección
        String calle = request.getParameter("calle");
        String provincia = request.getParameter("provincia");
        String ciudad = request.getParameter("ciudad");
        String codigoPostal = request.getParameter("codigoPostal");
        String referencia = request.getParameter("referencia");
        String idDireccionStr = request.getParameter("idDireccion");
        
        // Validar datos usando clase de utilidades
        String error = ValidacionUtil.validarDatosClienteActualizacion(nombre, correo, calle, provincia, ciudad);
        
        if (error != null) {
            request.setAttribute("error", error);
            editarCliente(request, response, id);
            return;
        }
        
        // Verificar si el correo ya existe en otro cliente
        if (ValidacionUtil.existeCorreoCompradorExcluyendoId(correo, id)) {
            request.setAttribute("error", "El correo electrónico ya está registrado por otro cliente");
            editarCliente(request, response, id);
            return;
        }
        
        // Obtener cliente existente
        Comprador cliente = clienteDAO.obtenerDatosCliente(id);
        if (cliente == null) {
            request.setAttribute("error", "Cliente no encontrado");
            solicitarGestionDeClientes(request, response);
            return;
        }
        
        // Actualizar datos del cliente
        cliente.setNombre(nombre);
        cliente.setCorreoElectronico(correo);
        cliente.setTelefono(telefono);
        cliente.setEstado(estado != null ? estado : cliente.getEstado());
        
        // Actualizar contraseña solo si se proporciona una nueva
        if (contrasena != null && !contrasena.trim().isEmpty()) {
            cliente.setContrasena(contrasena);
        }
        
        // 5.1 Actualizar cliente
        clienteDAO.actualizarCliente(cliente);
        
        // 5.2 Actualizar o crear dirección
        if (calle != null && !calle.trim().isEmpty()) {
            Direccion direccion = null;
            if (idDireccionStr != null && !idDireccionStr.trim().isEmpty()) {
                // Buscar dirección existente en la lista del cliente
                Integer idDireccion = Integer.parseInt(idDireccionStr);
                for (Direccion d : cliente.getDirecciones()) {
                    if (d.getIdDireccion() != null && d.getIdDireccion().equals(idDireccion)) {
                        direccion = d;
                        break;
                    }
                }
                if (direccion != null) {
                    direccion.setCalle(calle);
                    direccion.setProvincia(provincia);
                    direccion.setCiudad(ciudad);
                    direccion.setCodigoPostal(codigoPostal);
                    direccion.setReferencia(referencia);
                    direccionDAO.actualizarDireccion(id, direccion);
                }
            } else {
                // Crear nueva dirección
                direccion = new Direccion(calle, provincia, ciudad, codigoPostal, referencia);
                direccionDAO.registrarDireccion(id, direccion);
            }
        }
        
        // Mostrar mensaje de éxito y volver al listado
        request.setAttribute("mensaje", "Cliente '" + nombre + "' actualizado exitosamente");
        solicitarGestionDeClientes(request, response);
    }

    // =========================================================================
    // MÉTODO 6: eliminarCliente(id) - Diagrama de secuencia paso 6
    // =========================================================================
    /**
     * Ejecuta la eliminación del cliente después de la confirmación
     * Diagrama de secuencia:
     * 6.2 eliminar(cliente)
     * 6.3 eliminarDireccion(idComprador)
     */
    private void eliminarCliente(HttpServletRequest request, HttpServletResponse response, int id) 
            throws ServletException, IOException {
        // Obtener cliente
        Comprador cliente = clienteDAO.obtenerDatosCliente(id);
        
        if (cliente == null) {
            request.setAttribute("error", "Cliente no encontrado");
            solicitarGestionDeClientes(request, response);
            return;
        }
        
        String nombreCliente = cliente.getNombre();
        
        try {
            // 6.3 Eliminar direcciones del cliente (se eliminan en cascada con el cliente)
            // 6.2 Eliminar cliente
            clienteDAO.eliminar(cliente);
            
            // Mostrar mensaje de éxito
            request.setAttribute("mensaje", "Cliente '" + nombreCliente + "' eliminado exitosamente");
        } catch (Exception e) {
            // Mostrar mensaje de error amigable
            String mensajeError = e.getMessage();
            if (mensajeError != null && (mensajeError.contains("constraint") || mensajeError.contains("foreign key") || mensajeError.contains("referential"))) {
                request.setAttribute("error", "No se puede eliminar al cliente '" + nombreCliente + "' porque tiene pedidos asociados");
            } else {
                request.setAttribute("error", "Error al eliminar cliente: " + mensajeError);
            }
        }
        
        solicitarGestionDeClientes(request, response);
    }

    // =========================================================================
    // MÉTODO 7: verCliente(id) - Diagrama de secuencia paso 7
    // =========================================================================
    /**
     * Muestra los datos del cliente
     * Diagrama de secuencia:
     * 7.1 obtenerDatosCliente(id)
     * 7.2 mostrarDatosCliente()
     */
    private void verCliente(HttpServletRequest request, HttpServletResponse response, int id) 
            throws ServletException, IOException {
        // 7.1 Obtener datos del cliente
        Comprador cliente = clienteDAO.obtenerDatosCliente(id);
        
        if (cliente == null) {
            request.setAttribute("error", "Cliente no encontrado");
            solicitarGestionDeClientes(request, response);
            return;
        }
        
        // 7.2 Mostrar datos del cliente
        request.setAttribute("cliente", cliente);
        request.getRequestDispatcher("/vista/DetalleClientes.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO 8: buscarCliente(filtro) - Diagrama de secuencia paso 8
    // =========================================================================
    /**
     * Busca clientes según los filtros aplicados (nombre y estado)
     * Diagrama de secuencia:
     * 8.1 obtenerClientesPorFiltro(filtro)
     * 8.1.1 mostrarListadoFiltrado()
     */
    private void buscarCliente(HttpServletRequest request, HttpServletResponse response, String filtroNombre, String filtroEstado) 
            throws ServletException, IOException {
        List<Comprador> clientes;
        
        boolean tieneNombre = filtroNombre != null && !filtroNombre.trim().isEmpty();
        boolean tieneEstado = filtroEstado != null && !filtroEstado.trim().isEmpty();
        
        if (!tieneNombre && !tieneEstado) {
            // Si no hay filtros, mostrar todos
            clientes = clienteDAO.obtenerListadoDeClientes();
        } else if (tieneNombre && !tieneEstado) {
            // Solo filtro por nombre
            clientes = clienteDAO.obtenerClientesPorFiltro(filtroNombre);
        } else if (!tieneNombre && tieneEstado) {
            // Solo filtro por estado
            clientes = clienteDAO.obtenerClientesPorFiltro(filtroEstado);
        } else {
            // Ambos filtros: obtener por nombre y luego filtrar por estado en memoria
            clientes = clienteDAO.obtenerClientesPorFiltro(filtroNombre);
            String estadoFinal = filtroEstado.toUpperCase();
            clientes = clientes.stream()
                .filter(c -> c.getEstado() != null && c.getEstado().toUpperCase().equals(estadoFinal))
                .toList();
        }
        
        // 8.1.1 Mostrar listado filtrado
        request.setAttribute("clientes", clientes);
        request.setAttribute("filtroNombre", filtroNombre);
        request.setAttribute("filtroEstado", filtroEstado);
        request.getRequestDispatcher("/vista/ListaClientes.jsp").forward(request, response);
    }
}
