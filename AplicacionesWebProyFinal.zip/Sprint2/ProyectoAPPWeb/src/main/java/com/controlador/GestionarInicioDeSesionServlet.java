package com.controlador;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Map;

import com.dao.UsuarioDAO;
import com.modelo.entities.CarritoCompras;
import com.modelo.entities.Usuario;

/**
 * Servlet para gestionar inicio de sesión y registro.
 */
@WebServlet("/GestionarInicioDeSesionServlet")
public class GestionarInicioDeSesionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private UsuarioDAO usuarioDAO;

    // Temporales para que los métodos con las firmas exactas puedan usar request/response
    private HttpServletRequest currentRequest;
    private HttpServletResponse currentResponse;

    @Override
    public void init() throws ServletException {
        super.init();
        usuarioDAO = new UsuarioDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.currentRequest = request;
        this.currentResponse = response;

        String action = request.getParameter("action");
        if ("registrarse".equals(action)) {
            registrarse();
        } else {
            solicitarInicioSesion();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.currentRequest = request;
        this.currentResponse = response;

        String action = request.getParameter("action");

        try {
            if ("registrar".equals(action)) {
                String nombre = request.getParameter("nombre");
                String correo = request.getParameter("correo");
                String contrasena = request.getParameter("contrasena");
                registrarUsuario(0, nombre, contrasena, correo);
            } else {
                String correo = request.getParameter("correo");
                String contrasena = request.getParameter("contrasena");
                iniciarSesion(correo, contrasena);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", e.getMessage());
            request.getRequestDispatcher("/vista/FormularioInicioSesion.jsp").forward(request, response);
        }
    }

    // ---------------------------------------------------------------------
    //                             MÉTODOS
    // ---------------------------------------------------------------------

    /**
     * Muestra el formulario de inicio de sesión
     */
    public void solicitarInicioSesion() throws ServletException, IOException {
        currentRequest.getRequestDispatcher("/vista/FormularioInicioSesion.jsp").forward(currentRequest, currentResponse);
    }

    /**
     * Procesa el inicio de sesión del usuario
     * @param correo correo del usuario
     * @param contrasena contraseña del usuario
     */
    public void iniciarSesion(String correo, String contrasena) throws ServletException, IOException {
        try {
            if (correo == null || correo.trim().isEmpty() ||
                contrasena == null || contrasena.trim().isEmpty()) {
                currentRequest.setAttribute("error", "Debe completar todos los campos");
                currentRequest.getRequestDispatcher("/vista/FormularioInicioSesion.jsp").forward(currentRequest, currentResponse);
                return;
            }

            // Verificar credenciales mediante DAO. El DAO seteará el usuario autenticado en su campo público si es válido.
            usuarioDAO.verificarCredenciales(correo, contrasena);

            Usuario usuario = usuarioDAO.usuarioAutenticado;

            if (usuario != null) {
                HttpSession session = currentRequest.getSession();
                session.setAttribute("usuario", usuario);
                session.setAttribute("usuarioId", usuario.getIdUsuario());
                session.setAttribute("usuarioNombre", usuario.getNombre());
                session.setAttribute("usuarioRol", usuario.getRol());

                // Recuperar carrito guardado en contexto si existe
                ServletContext context = getServletContext();
                @SuppressWarnings("unchecked")
                Map<Integer, CarritoCompras> carritosUsuarios =
                        (Map<Integer, CarritoCompras>) context.getAttribute("carritosUsuarios");

                if (carritosUsuarios != null && usuario.getIdUsuario() != null && carritosUsuarios.containsKey(usuario.getIdUsuario())) {
                    CarritoCompras carritoGuardado = carritosUsuarios.get(usuario.getIdUsuario());
                    session.setAttribute("carritoCompras", carritoGuardado);
                }

                if ("ADMIN".equals(usuario.getRol())) {
                    currentResponse.sendRedirect(currentRequest.getContextPath() + "/vista/PanelDeAdministrador.jsp");
                } else {
                    currentResponse.sendRedirect(currentRequest.getContextPath() + "/vista/PanelDeComprador.jsp");
                }

            } else {
                currentRequest.setAttribute("error", "Correo o contraseña incorrectos");
                currentRequest.getRequestDispatcher("/vista/FormularioInicioSesion.jsp").forward(currentRequest, currentResponse);
            }

        } catch (Exception e) {
            e.printStackTrace();
            currentRequest.setAttribute("error", "Error al procesar login: " + e.getMessage());
            currentRequest.getRequestDispatcher("/vista/FormularioInicioSesion.jsp").forward(currentRequest, currentResponse);
        }
    }

    /**
     * Muestra el formulario de registro
     */
    public void registrarse() throws ServletException, IOException {
        // Mover mensajes de "flash" desde la sesión al request (si existen)
    	// para evitar que persistan tras una recarga de página
        HttpSession session = currentRequest.getSession(false);
        if (session != null) {
            Object msg = session.getAttribute("mensaje");
            if (msg != null) {
                currentRequest.setAttribute("mensaje", msg);
                session.removeAttribute("mensaje");
            }
            Object err = session.getAttribute("error");
            if (err != null) {
                currentRequest.setAttribute("error", err);
                session.removeAttribute("error");
            }
        }

        currentRequest.getRequestDispatcher("/vista/FormularioRegistro.jsp").forward(currentRequest, currentResponse);
    }

    /**
     * Registra un nuevo usuario comprador.
     * @param id id
     * @param nombre nombre del usuario
     * @param contrasena contraseña
     * @param correo correo electrónico
     */
    public void registrarUsuario(int id, String nombre, String contrasena, String correo) throws ServletException, IOException {
        try {
            // Validaciones básicas
            if (nombre == null || nombre.trim().isEmpty() ||
                correo == null || correo.trim().isEmpty() ||
                contrasena == null || contrasena.trim().isEmpty()) {
                currentRequest.setAttribute("error", "Debe completar todos los campos obligatorios");
                currentRequest.getRequestDispatcher("/vista/FormularioRegistro.jsp").forward(currentRequest, currentResponse);
                return;
            }

            // Trim inputs and delegate format validations to UsuarioDAO
            String correoTrim = correo.trim();
            String nombreTrim = nombre.trim();

            // Registrar nuevo comprador mediante DAO (el DAO validará formato de correo, nombre y contraseña)
            usuarioDAO.registrarNuevoComprador(id, nombreTrim, contrasena, correoTrim);

            // Guardar mensaje en sesión y redirigir al GET que muestra el formulario
            HttpSession session = currentRequest.getSession();
            session.setAttribute("mensaje", "Registro exitoso. Por favor inicie sesión.");

            // Redirigir al GET que mostrará el formulario y el mensaje (evita reenvío al recargar)
            currentResponse.sendRedirect(currentRequest.getContextPath() + "/GestionarInicioDeSesionServlet?action=registrarse");

        } catch (Exception e) {
            e.printStackTrace();
            // En caso de error en registro, mostramos el error en la misma página
            currentRequest.setAttribute("error", e.getMessage());
            currentRequest.getRequestDispatcher("/vista/FormularioRegistro.jsp").forward(currentRequest, currentResponse);
        }
    }
}