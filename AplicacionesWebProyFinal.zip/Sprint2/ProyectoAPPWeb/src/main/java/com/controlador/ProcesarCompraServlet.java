package com.controlador;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

import com.dao.CarritoComprasDAO;
import com.dao.ComprobanteDAO;
import com.dao.EmailService;
import com.dao.PagoTransferenciaDAO;
import com.dao.PedidoDAO;
import com.dao.ProductoDAO;
import com.dao.ValidacionUtil;
import com.modelo.entities.CarritoCompras;
import com.modelo.entities.Comprador;
import com.modelo.entities.Comprobante;
import com.modelo.entities.ItemCarrito;
import com.modelo.entities.ItemVenta;
import com.modelo.entities.PagoTransferencia;
import com.modelo.entities.Pedido;
import com.modelo.entities.Producto;
import com.modelo.entities.Usuario;

/**
 * ========================================================================
 * CONTROLADOR: ProcesarCompra (Servlet)
 * ========================================================================
 * Implementa el flujo de Procesar Compra según los diagramas de robustez y secuencia.
 * 
 * Métodos según diagrama de clases del controlador ProcesarCompra:
 * +enviarPedido(pedido : Pedido) : void
 * +procesarCompraPedido() : void
 * +adjuntarComprobante(imagen : String) : void
 * +confirmarTransferencia() : void
 * +aprobarPago() : void
 * +continuar() : void
 * 
 * Flujo Principal según caso de uso:
 * 1. El comprador solicita Procesar Compra.
 * 2. El sistema muestra el detalle del pedido y los datos bancarios.
 * 3. El comprador adjunta comprobante de pago.
 * 4. El sistema valida el comprobante y muestra mensaje de éxito.
 * 5. El comprador solicita Confirmar Transferencia.
 * 6. El sistema actualiza estado a pendiente y envía comprobante al administrador.
 * 7. El administrador revisa el comprobante.
 * 8. El administrador solicita Aprobar Pago.
 * 9. El sistema muestra mensaje pago exitoso y genera comprobante.
 * 10. El comprador solicita continuar.
 * 11. El sistema actualiza estado a finalizado y muestra mensaje de agradecimiento.
 */
@WebServlet(name = "ProcesarCompraServlet", urlPatterns = {"/ProcesarCompra"})
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024,      // 1 MB
    maxFileSize = 1024 * 1024 * 10,       // 10 MB
    maxRequestSize = 1024 * 1024 * 15     // 15 MB
)
public class ProcesarCompraServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Datos bancarios de la empresa
    private static final String BANCO = "Banco de Crédito del Perú (BCP)";
    private static final String TITULAR = "Encanto EA S.A.C.";
    private static final String NUMERO_CUENTA = "191-12345678-0-12";
    private static final String TIPO_CUENTA = "Cuenta Corriente";
    private static final String RUC = "20123456789";
    private static final String CCI = "002-191-012345678012-34";
    
    private CarritoComprasDAO carritoComprasDAO;
    private PedidoDAO pedidoDAO;
    private PagoTransferenciaDAO pagoTransferenciaDAO;
    private ComprobanteDAO comprobanteDAO;
    private EmailService emailService;
    private ProductoDAO productoDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        carritoComprasDAO = new CarritoComprasDAO();
        pedidoDAO = new PedidoDAO();
        pagoTransferenciaDAO = new PagoTransferenciaDAO();
        comprobanteDAO = new ComprobanteDAO();
        emailService = new EmailService();
        productoDAO = new ProductoDAO();
    }

    /**
     * Maneja las solicitudes GET
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        try {
            if (action == null || "procesarCompraPedido".equals(action)) {
                // 1: procesarCompraPedido
                procesarCompraPedido(request, response);
            } else if ("continuar".equals(action)) {
                // 10: continuar
                continuar(request, response);
            } else if ("aprobarPago".equals(action)) {
                // 9: aprobarPago (desde correo del administrador)
                aprobarPago(request, response);
            } else if ("rechazarPago".equals(action)) {
                // Flujo alterno 10.1: rechazarPago
                rechazarPago(request, response);
            } else if ("verificarEstado".equals(action)) {
                // Verificar estado del pedido - lógica inline
                HttpSession session = request.getSession();
                String pedidoIdStr = request.getParameter("pedidoId");
                Pedido pedido = null;
                
                // Obtener pedido de la BD (siempre consultar BD para obtener estado actualizado)
                if (pedidoIdStr != null) {
                    try {
                        Integer pedidoId = Integer.parseInt(pedidoIdStr);
                        pedidoDAO.setUltimoPedido(pedidoId);
                        pedido = pedidoDAO.obtenerPedido();
                    } catch (NumberFormatException e) {
                        // Ignorar
                    }
                }
                
                // Si no viene por parámetro, intentar obtener de la sesión
                if (pedido == null) {
                    Pedido pedidoSesion = (Pedido) session.getAttribute("pedidoConfirmado");
                    if (pedidoSesion != null) {
                        pedidoDAO.setUltimoPedido(pedidoSesion.getIdPedido());
                        pedido = pedidoDAO.obtenerPedido();
                    }
                }
                
                if (pedido == null) {
                    response.sendRedirect(request.getContextPath() + "/vista/PanelDeComprador.jsp");
                    return;
                }
                
                // Actualizar pedido en sesión con el estado actualizado
                session.setAttribute("pedidoConfirmado", pedido);
                
                String estado = pedido.getEstado();
                
                System.out.println("========================================");
                System.out.println("🔍 VERIFICANDO ESTADO DEL PEDIDO");
                System.out.println("📋 Pedido: #" + pedido.getNumeroPedido());
                System.out.println("📊 Estado: " + estado);
                System.out.println("========================================");
                
                // Según el estado, redirigir a la vista correspondiente
                if ("PAGO_APROBADO".equals(estado) || "FINALIZADO".equals(estado)) {
                    session.removeAttribute("comprobanteImagen");
                    session.removeAttribute("comprobanteNombre");
                    session.removeAttribute("pagoTransferencia");
                    
                    Comprador comprador = pedido.getComprador();
                    String nombreComprador = comprador != null ? comprador.getNombre() : "Cliente";
                    
                    request.setAttribute("pedido", pedido);
                    request.setAttribute("nombreComprador", nombreComprador);
                    request.setAttribute("pagoAprobado", true);
                    request.setAttribute("mensaje", "¡Tu pago ha sido aprobado exitosamente! Tu pedido está siendo preparado.");
                    
                    request.getRequestDispatcher("/vista/MensajeAgradecimiento.jsp").forward(request, response);
                    
                } else if ("PAGO_RECHAZADO".equals(estado)) {
                    request.setAttribute("mensaje", "❌ Lo sentimos, tu pago ha sido rechazado. Por favor, contacta con soporte o intenta nuevamente.");
                    request.setAttribute("titulo", "Pago Rechazado");
                    request.setAttribute("pedido", pedido);
                    request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
                    
                } else {
                    request.getRequestDispatcher("/vista/EsperaAprobacion.jsp").forward(request, response);
                }
            } else if ("seguirComprando".equals(action)) {
                // Flujo alterno 12.1: seguirComprando
                seguirComprando(request, response);
            } else if ("volverInicio".equals(action)) {
                // Flujo alterno 12.2: volverInicio
                volverInicio(request, response);
            } else {
                procesarCompraPedido(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error: " + e.getMessage());
            procesarCompraPedido(request, response);
        }
    }

    /**
     * Maneja las solicitudes POST
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        try {
            if ("adjuntarComprobante".equals(action)) {
                // 3-4: adjuntarComprobante
                adjuntarComprobante(request, response);
            } else if ("confirmarTransferencia".equals(action)) {
                // 5-6: confirmarTransferencia
                confirmarTransferencia(request, response);
            } else if ("aprobarPago".equals(action)) {
                // 8-9: aprobarPago
                aprobarPago(request, response);
            } else {
                procesarCompraPedido(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error al procesar: " + e.getMessage());
            procesarCompraPedido(request, response);
        }
    }

    // =========================================================================
    // MÉTODO 1: procesarCompraPedido() - Diagrama de robustez paso 1
    // =========================================================================
    /**
     * El comprador solicita Procesar Compra.
     * Según diagrama controlador: +procesarCompraPedido() : void
     * 
     * Diagrama de secuencia:
     * 1: procesarCompraPedido() : void
     * 2: obtenerPedido() : Pedido
     * 3: obtenerCarritoDeCompras() : CarritoCompras
     * 4: mostrarResumenDePedido() : void
     */
    private void procesarCompraPedido(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        
        // 2: obtenerPedido() : Pedido
        Pedido pedido = (Pedido) session.getAttribute("pedidoConfirmado");
        
        if (pedido == null) {
            request.setAttribute("error", "No hay pedido para procesar. Por favor, complete el proceso de compra.");
            response.sendRedirect(request.getContextPath() + "/GestionarCarrito?action=acceder");
            return;
        }
        
        // 3: obtenerCarritoDeCompras() : CarritoCompras
        CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
        carrito = carritoComprasDAO.obtenerCarritoDeCompras(carrito);
        
        // Preparar datos para la vista
        request.setAttribute("pedido", pedido);
        request.setAttribute("carrito", carrito);
        
        // Atributos del pedido para mostrar en el resumen
        request.setAttribute("subtotal", pedido.getSubtotal());
        request.setAttribute("iva", pedido.getImpuestos());
        request.setAttribute("total", pedido.getTotal());
        if (pedido.getEnvio() != null) {
            request.setAttribute("costoEnvio", pedido.getEnvio().getMetodoEnvio() != null ? 
                pedido.getEnvio().getMetodoEnvio().getCosto() : 0.0);
            request.setAttribute("nombredestinatario", pedido.getEnvio().getNombreDestinatario());
            request.setAttribute("telefono", pedido.getEnvio().getTelefono());
            request.setAttribute("fechaentrega", pedido.getEnvio().getFechaEntrega());
            request.setAttribute("direccion", pedido.getEnvio().getDireccionEntrega());
            request.setAttribute("metodoEnvio", pedido.getEnvio().getMetodoEnvio());
        }
        
        // Datos bancarios
        request.setAttribute("banco", BANCO);
        request.setAttribute("titular", TITULAR);
        request.setAttribute("numeroCuenta", NUMERO_CUENTA);
        request.setAttribute("tipoCuenta", TIPO_CUENTA);
        request.setAttribute("ruc", RUC);
        request.setAttribute("cci", CCI);
        
        // Verificar si ya hay comprobante adjunto
        byte[] comprobanteImagen = (byte[]) session.getAttribute("comprobanteImagen");
        request.setAttribute("comprobanteAdjunto", comprobanteImagen != null);
        
        // 4: mostrarResumenDePedido() : void
        request.getRequestDispatcher("/vista/ResumenPedido.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO 2: adjuntarComprobante(imagen : String) - Diagrama de robustez paso 5
    // =========================================================================
    /**
     * El comprador adjunta el comprobante de pago.
     * Según diagrama controlador: +adjuntarComprobante(imagen : String) : void
     * 
     * Diagrama de secuencia:
     * 5: adjuntarComprobante(imagen : String) : void
     * 6: mostrarMensajeExito() : void
     * 
     * Flujos alternos:
     * 5.1 No subir comprobante - el sistema bloquea el proceso
     * 5.2 Comprobante inválido - el sistema solicita cargar nuevamente
     */
    private void adjuntarComprobante(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        Pedido pedido = (Pedido) session.getAttribute("pedidoConfirmado");
        
        if (pedido == null) {
            request.setAttribute("error", "No hay pedido activo.");
            response.sendRedirect(request.getContextPath() + "/GestionarCarrito?action=acceder");
            return;
        }
        
        try {
            // Obtener el archivo del comprobante
            Part filePart = request.getPart("comprobanteImagen");
            
            // Flujo alterno 5.1: No subir comprobante
            if (filePart == null || filePart.getSize() == 0) {
                request.setAttribute("error", "Debe adjuntar un comprobante de pago para continuar.");
                procesarCompraPedido(request, response);
                return;
            }
            
            // Flujo alterno 5.2: Validar formato del archivo
            String fileName = filePart.getSubmittedFileName();
            String contentType = filePart.getContentType();
            
            if (!ValidacionUtil.esFormatoValido(contentType, fileName)) {
                request.setAttribute("error", "El comprobante no es válido. Solo se permiten imágenes (JPG, PNG) o PDF. Por favor, cargue nuevamente el archivo.");
                procesarCompraPedido(request, response);
                return;
            }
            
            // Leer la imagen
            byte[] imagenBytes;
            try (InputStream inputStream = filePart.getInputStream()) {
                imagenBytes = inputStream.readAllBytes();
            }
            
            // Guardar en sesión
            session.setAttribute("comprobanteImagen", imagenBytes);
            session.setAttribute("comprobanteNombre", fileName);
            
            // 6: mostrarMensajeExito() : void
            request.setAttribute("mensaje", "✅ Comprobante adjuntado correctamente. Ahora puede confirmar la transferencia.");
            request.setAttribute("comprobanteAdjunto", true);
            
            procesarCompraPedido(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error al procesar el comprobante: " + e.getMessage());
            procesarCompraPedido(request, response);
        }
    }

    // =========================================================================
    // MÉTODO 3: confirmarTransferencia() - Diagrama de robustez paso 7
    // =========================================================================
    /**
     * El comprador confirma la transferencia.
     * Según diagrama controlador: +confirmarTransferencia() : void
     * 
     * Diagrama de secuencia:
     * 7: confirmarTransferencia() : void
     * 8: actualizarEstadoPedido(estadoPedido : String) : void
     * - Envía comprobante al correo del administrador
     */
    private void confirmarTransferencia(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        Pedido pedido = (Pedido) session.getAttribute("pedidoConfirmado");
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        
        if (pedido == null) {
            request.setAttribute("error", "No hay pedido activo.");
            response.sendRedirect(request.getContextPath() + "/GestionarCarrito?action=acceder");
            return;
        }
        
        // Flujo alterno 5.1.3: Verificar que hay comprobante adjunto
        byte[] comprobanteImagen = (byte[]) session.getAttribute("comprobanteImagen");
        if (comprobanteImagen == null) {
            request.setAttribute("error", "⚠️ Debe subir el comprobante de pago para continuar con la confirmación.");
            procesarCompraPedido(request, response);
            return;
        }
        
        // Obtener nombre del comprador
        String nombreComprador = "Cliente";
        String emailComprador = "";
        if (usuario != null && usuario instanceof Comprador) {
            Comprador comprador = (Comprador) usuario;
            nombreComprador = comprador.getNombre();
            emailComprador = comprador.getCorreoElectronico();
        }
        
        // ACTUALIZAR STOCK - Descontar stock al confirmar la transferencia
        CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
        if (carrito != null && carrito.getItems() != null) {
            for (ItemCarrito item : carrito.getItems()) {
                ItemVenta itemVenta = item.getItem();
                if (itemVenta != null) {
                    int cantidadComprada = item.getCantidad();
                    
                    try {
                        if (itemVenta instanceof Producto) {
                            Producto producto = (Producto) itemVenta;
                            Producto productoDb = productoDAO.obtenerDatosProducto(producto.getId());
                            if (productoDb != null) {
                                int stockActual = productoDb.getStock();
                                int nuevoStock = stockActual - cantidadComprada;
                                if (nuevoStock < 0) nuevoStock = 0;
                                productoDb.setStock(nuevoStock);
                                productoDAO.actualizarProducto(productoDb);
                                System.out.println("✓ Stock actualizado al confirmar transferencia: " + productoDb.getNombre() + 
                                    " - Stock anterior: " + stockActual + " - Nuevo stock: " + nuevoStock);
                            }
                        }
                    } catch (Exception e) {
                        System.err.println("❌ Error al actualizar stock: " + e.getMessage());
                    }
                }
            }
            
            // Vaciar el carrito después de actualizar stock
            carritoComprasDAO.quitarTodosLosItems(carrito);
            session.setAttribute("carritoCompras", carrito);
            System.out.println("✓ Carrito vaciado y stock actualizado al confirmar transferencia");
        }
        
        // Crear comprobante en BD usando generarComprobante
        Comprobante comprobante = comprobanteDAO.generarComprobante(
            nombreComprador, 
            null, 
            new Date(), 
            comprobanteImagen, 
            "PENDIENTE_REVISION"
        );
        
        // Crear pago de transferencia
        PagoTransferencia pago = new PagoTransferencia();
        pago.setMonto(pedido.getTotal());
        pago.setFechaPago(new Date());
        pago.setBanco(BANCO);
        pago.setTitular(TITULAR);
        pago.setNumeroCuenta(NUMERO_CUENTA);
        pago.setTipoCuenta(TIPO_CUENTA);
        pago.setRUC(RUC);
        pago.setComprobante(comprobante);
        pago.setPedido(pedido);
        pagoTransferenciaDAO.guardarPago(pago);
        
        // 8: actualizarEstadoPedido(estadoPedido : String) : void
        pedidoDAO.actualizarEstadoPedido("PENDIENTE_APROBACION");
        pedido.setEstado("PENDIENTE_APROBACION");
        session.setAttribute("pedidoConfirmado", pedido);
        
        // DEBUG: Verificar datos antes de enviar correo
        System.out.println("========================================");
        System.out.println("🔍 DEBUG - ANTES DE ENVIAR CORREO:");
        System.out.println("📋 Pedido ID: " + pedido.getIdPedido());
        System.out.println("📋 Número Pedido: " + pedido.getNumeroPedido());
        System.out.println("👤 Comprador: " + nombreComprador);
        System.out.println("💰 Total: " + pedido.getTotal());
        System.out.println("📎 Comprobante bytes: " + (comprobanteImagen != null ? comprobanteImagen.length : "NULL"));
        System.out.println("========================================");
        
        // Enviar comprobante al correo del administrador
        String baseUrl = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath();
        
        // Verificar que el pedido tenga ID antes de enviar
        boolean emailEnviado = false;
        if (pedido.getIdPedido() != null) {
            try {
                emailEnviado = emailService.enviarComprobanteAlAdministrador(
                    pedido.getNumeroPedido(),
                    nombreComprador,
                    pedido.getTotal(),
                    comprobanteImagen,
                    baseUrl,
                    pedido.getIdPedido()
                );
                System.out.println("✅ Resultado envío email: " + (emailEnviado ? "ENVIADO" : "NO ENVIADO"));
            } catch (Exception emailEx) {
                System.err.println("❌ EXCEPCIÓN al enviar email: " + emailEx.getMessage());
                emailEx.printStackTrace();
            }
        } else {
            System.err.println("❌ ERROR: El pedido no tiene ID asignado. No se puede enviar correo.");
        }
        
        // Guardar info del pago en sesión
        session.setAttribute("pagoTransferencia", pago);
        
        // Mostrar mensaje según resultado
        if (emailEnviado) {
            request.setAttribute("mensaje", "✅ Transferencia confirmada. Su comprobante ha sido enviado al administrador para verificación. Le notificaremos cuando su pago sea aprobado.");
        } else {
            request.setAttribute("mensaje", "✅ Transferencia confirmada. Su comprobante está pendiente de verificación por el administrador.");
        }
        
        request.setAttribute("pedido", pedido);
        request.setAttribute("estadoTransferencia", "PENDIENTE_APROBACION");
        request.setAttribute("pago", pago);
        
        // Redirigir a la vista de espera de aprobación
        request.getRequestDispatcher("/vista/EsperaAprobacion.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO 4: aprobarPago() - Diagrama de robustez paso 9
    // =========================================================================
    /**
     * El administrador aprueba el pago.
     * Según diagrama controlador: +aprobarPago() : void
     * 
     * Diagrama de secuencia:
     * 9: aprobarPago() : void
     * 9.1: guardarPago(...) : boolean
     * 9.2: generarComprobante(...) : Comprobante
     * 9.3: mostrarComprobanteDePago() : void
     */
    private void aprobarPago(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pedidoIdStr = request.getParameter("pedidoId");
        String token = request.getParameter("token");
        HttpSession session = request.getSession();
        
        Integer pedidoId = null;
        Pedido pedido = null;
        boolean desdeCorreoAdmin = false;
        
        // Si viene desde el correo del admin (tiene pedidoId en el parámetro)
        if (pedidoIdStr != null && !pedidoIdStr.isEmpty()) {
            desdeCorreoAdmin = true;
            try {
                pedidoId = Integer.parseInt(pedidoIdStr);
                
                // Validar token de seguridad
                if (token == null || !EmailService.validarToken(pedidoId, token)) {
                    System.out.println("⚠️ Token inválido o expirado para pedido: " + pedidoId);
                    // Aún así permitir si el token coincide con el almacenado
                    String tokenGuardado = EmailService.obtenerToken(pedidoId);
                    if (tokenGuardado == null || !tokenGuardado.equals(token)) {
                        request.setAttribute("error", "El enlace de aprobación ha expirado o es inválido.");
                        request.setAttribute("titulo", "Enlace Inválido");
                        request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
                        return;
                    }
                }
                
                // Obtener pedido de la BD
                pedidoDAO.setUltimoPedido(pedidoId);
                pedido = pedidoDAO.obtenerPedido();
                
            } catch (NumberFormatException e) {
                request.setAttribute("error", "ID de pedido inválido.");
                request.setAttribute("titulo", "Error");
                request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
                return;
            }
        } else {
            // Si viene desde la sesión (flujo normal desde la web)
            pedido = (Pedido) session.getAttribute("pedidoConfirmado");
            if (pedido != null) {
                pedidoId = pedido.getIdPedido();
            }
        }
        
        if (pedido == null) {
            request.setAttribute("error", "No se encontró el pedido.");
            request.setAttribute("titulo", "Error");
            request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
            return;
        }
        
        // Verificar si el pedido ya fue aprobado
        if ("PAGO_APROBADO".equals(pedido.getEstado()) || "FINALIZADO".equals(pedido.getEstado())) {
            request.setAttribute("mensaje", "✅ Este pedido ya fue aprobado anteriormente.");
            request.setAttribute("titulo", "Pedido Ya Aprobado");
            request.setAttribute("pedido", pedido);
            request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
            return;
        }
        
        // 9.1: guardarPago - Actualizar estado del pago directamente en BD
        pedidoDAO.setUltimoPedido(pedidoId);
        pedidoDAO.actualizarEstadoPedido("PAGO_APROBADO");
        boolean actualizado = pedidoDAO.obtenerPedido() != null;
        
        if (!actualizado) {
            request.setAttribute("error", "Error al actualizar el estado del pedido.");
            request.setAttribute("titulo", "Error");
            request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
            return;
        }
        
        pedido.setEstado("PAGO_APROBADO");
        
        System.out.println("========================================");
        System.out.println("✅ PAGO APROBADO");
        System.out.println("📋 Pedido: #" + pedido.getNumeroPedido());
        System.out.println("🆔 ID: " + pedidoId);
        System.out.println("👤 Desde: " + (desdeCorreoAdmin ? "Correo Admin (teléfono)" : "Sesión Web"));
        System.out.println("========================================");
        
        // Nota: El stock ya fue actualizado al momento de confirmar la transferencia
        // Aquí solo vaciamos el carrito si aún existe en sesión
        CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
        if (carrito != null) {
            carritoComprasDAO.quitarTodosLosItems(carrito);
            session.setAttribute("carritoCompras", carrito);
            System.out.println("✓ Carrito vaciado después de aprobar pago");
        }
        
        // Obtener info del comprador para notificación
        Comprador comprador = pedido.getComprador();
        String nombreComprador = comprador != null ? comprador.getNombre() : "Cliente";
        String emailComprador = comprador != null ? comprador.getCorreoElectronico() : null;
        
        // 9.2: generarComprobante
        Comprobante comprobanteGenerado = comprobanteDAO.generarComprobante(
            nombreComprador,
            "COMP-" + pedido.getNumeroPedido(),
            new Date()
        );
        
        // Notificar al comprador por correo
        if (emailComprador != null && !emailComprador.isEmpty()) {
            emailService.enviarNotificacionComprador(
                emailComprador,
                nombreComprador,
                pedido.getNumeroPedido(),
                "APROBADO",
                "¡Tu pago ha sido aprobado! Tu pedido está siendo preparado para envío."
            );
        }
        
        // Actualizar estado a FINALIZADO ya que el pago fue aprobado
        pedidoDAO.setUltimoPedido(pedidoId);
        pedidoDAO.actualizarEstadoPedido("FINALIZADO");
        pedido.setEstado("FINALIZADO");
        
        System.out.println("========================================");
        System.out.println("🎉 PAGO APROBADO Y FINALIZADO");
        System.out.println("📋 Pedido: #" + pedido.getNumeroPedido());
        System.out.println("👤 Cliente: " + nombreComprador);
        System.out.println("👤 Desde: " + (desdeCorreoAdmin ? "Admin (correo/teléfono)" : "Cliente (web)"));
        System.out.println("========================================");
        
        // Si viene desde el correo del admin (teléfono), mostrar confirmación al admin
        if (desdeCorreoAdmin) {
            request.setAttribute("mensaje", "✅ ¡Pago aprobado exitosamente!<br><br>" +
                "📋 Pedido: <strong>#" + pedido.getNumeroPedido() + "</strong><br>" +
                "👤 Cliente: <strong>" + nombreComprador + "</strong><br>" +
                "💰 Monto: <strong>S/ " + String.format("%.2f", pedido.getTotal()) + "</strong><br><br>" +
                "El cliente ha sido notificado por correo electrónico y verá el mensaje de agradecimiento en su pantalla.");
            request.setAttribute("titulo", "✅ Pago Aprobado");
            request.setAttribute("esAdmin", true);
            request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
        } else {
            // Si viene desde la sesión web normal (cliente verificando estado)
            // Limpiar datos de sesión relacionados con la compra
            session.removeAttribute("comprobanteImagen");
            session.removeAttribute("comprobanteNombre");
            session.removeAttribute("pagoTransferencia");
            
            // MOSTRAR MENSAJE DE AGRADECIMIENTO AL CLIENTE
            request.setAttribute("pedido", pedido);
            request.setAttribute("nombreComprador", nombreComprador);
            request.setAttribute("comprobanteGenerado", comprobanteGenerado);
            request.setAttribute("pagoAprobado", true);
            request.setAttribute("mensaje", "¡Tu pago ha sido aprobado exitosamente! Tu pedido está siendo preparado.");
            session.setAttribute("pedidoConfirmado", pedido);
            
            // Redirigir a la página de agradecimiento
            request.getRequestDispatcher("/vista/MensajeAgradecimiento.jsp").forward(request, response);
        }
    }

    // =========================================================================
    // MÉTODO ALTERNO: rechazarPago() - Flujo alterno 10.1
    // =========================================================================
    /**
     * El administrador rechaza el pago por inconsistencias.
     * Flujo alterno 10.1:
     * 10.1.1 El administrador detecta inconsistencias
     * 10.1.2 El administrador solicita Rechazar Pago
     * 10.1.3 El sistema mantiene el pedido en estado pendiente
     * 10.1.4 El sistema notifica al comprador el rechazo
     */
    private void rechazarPago(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pedidoIdStr = request.getParameter("pedidoId");
        String token = request.getParameter("token");
        
        if (pedidoIdStr == null) {
            request.setAttribute("error", "ID de pedido no proporcionado.");
            request.setAttribute("titulo", "Error");
            request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
            return;
        }
        
        try {
            Integer pedidoId = Integer.parseInt(pedidoIdStr);
            
            // Validar token de seguridad
            if (token != null) {
                String tokenGuardado = EmailService.obtenerToken(pedidoId);
                if (tokenGuardado == null || !tokenGuardado.equals(token)) {
                    request.setAttribute("error", "El enlace de rechazo ha expirado o es inválido.");
                    request.setAttribute("titulo", "Enlace Inválido");
                    request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
                    return;
                }
            }
            
            pedidoDAO.setUltimoPedido(pedidoId);
            Pedido pedido = pedidoDAO.obtenerPedido();
            
            if (pedido == null) {
                request.setAttribute("error", "Pedido no encontrado.");
                request.setAttribute("titulo", "Error");
                request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
                return;
            }
            
            // Verificar si el pedido ya fue procesado
            if ("PAGO_APROBADO".equals(pedido.getEstado()) || "FINALIZADO".equals(pedido.getEstado())) {
                request.setAttribute("mensaje", "⚠️ Este pedido ya fue aprobado y no puede ser rechazado.");
                request.setAttribute("titulo", "Pedido Ya Procesado");
                request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
                return;
            }
            
            if ("PAGO_RECHAZADO".equals(pedido.getEstado())) {
                request.setAttribute("mensaje", "⚠️ Este pedido ya fue rechazado anteriormente.");
                request.setAttribute("titulo", "Pedido Ya Rechazado");
                request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
                return;
            }
            
            // 10.1.3: Actualizar estado a rechazado usando el nuevo método por ID
            pedidoDAO.setUltimoPedido(pedidoId);
            pedidoDAO.actualizarEstadoPedido("PAGO_RECHAZADO");
            boolean actualizado = pedidoDAO.obtenerPedido() != null;
            
            if (!actualizado) {
                request.setAttribute("error", "Error al actualizar el estado del pedido.");
                request.setAttribute("titulo", "Error");
                request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
                return;
            }
            
            pedido.setEstado("PAGO_RECHAZADO");
            
            System.out.println("========================================");
            System.out.println("❌ PAGO RECHAZADO");
            System.out.println("📋 Pedido: #" + pedido.getNumeroPedido());
            System.out.println("🆔 ID: " + pedidoId);
            System.out.println("========================================");
            
            // 10.1.4: Notificar al comprador
            Comprador comprador = pedido.getComprador();
            String nombreComprador = comprador != null ? comprador.getNombre() : "Cliente";
            
            if (comprador != null && comprador.getCorreoElectronico() != null) {
                emailService.enviarNotificacionComprador(
                    comprador.getCorreoElectronico(),
                    comprador.getNombre(),
                    pedido.getNumeroPedido(),
                    "RECHAZADO",
                    "Lo sentimos, tu pago ha sido rechazado debido a inconsistencias en el comprobante. Por favor, contacta con soporte o intenta nuevamente."
                );
            }
            
            request.setAttribute("mensaje", "❌ Pago rechazado<br><br>" +
                "📋 Pedido: <strong>#" + pedido.getNumeroPedido() + "</strong><br>" +
                "👤 Cliente: <strong>" + nombreComprador + "</strong><br><br>" +
                "El cliente ha sido notificado por correo electrónico.");
            request.setAttribute("titulo", "❌ Pago Rechazado");
            request.setAttribute("pedido", pedido);
            request.setAttribute("esAdmin", true);
            
        } catch (NumberFormatException e) {
            request.setAttribute("error", "ID de pedido inválido.");
            request.setAttribute("titulo", "Error");
        }
        
        request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO 5: continuar() - Diagrama de robustez paso 10
    // =========================================================================
    /**
     * El comprador solicita continuar después de la aprobación.
     * Según diagrama controlador: +continuar() : void
     * 
     * Diagrama de secuencia:
     * 10: continuar() : void
     * 11: mostrarMensajeAgradecimiento() : void
     */
    private void continuar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        Pedido pedido = (Pedido) session.getAttribute("pedidoConfirmado");
        
        if (pedido != null) {
            // Actualizar estado a finalizado
            pedidoDAO.actualizarEstadoPedido("FINALIZADO");
            pedido.setEstado("FINALIZADO");
            
            // Vaciar carrito
            CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
            if (carrito != null) {
                carritoComprasDAO.quitarTodosLosItems(carrito);
            }
            
            // Limpiar datos de sesión
            session.removeAttribute("comprobanteImagen");
            session.removeAttribute("comprobanteNombre");
            session.removeAttribute("pagoTransferencia");
        }
        
        // 11: mostrarMensajeAgradecimiento() : void
        request.setAttribute("pedido", pedido);
        request.getRequestDispatcher("/vista/MensajeAgradecimiento.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO ALTERNO: seguirComprando() - Flujo alterno 12.1
    // =========================================================================
    /**
     * El comprador solicita seguir comprando.
     * Flujo alterno 12.1:
     * 12.1.1 El comprador solicita Seguir Comprando
     * 12.1.2 El sistema redirige al catálogo de productos
     */
    private void seguirComprando(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Limpiar datos del pedido procesado
        HttpSession session = request.getSession();
        session.removeAttribute("pedidoConfirmado");
        session.removeAttribute("comprobanteImagen");
        session.removeAttribute("comprobanteNombre");
        session.removeAttribute("pagoTransferencia");
        
        // Redirigir al catálogo
        response.sendRedirect(request.getContextPath() + "/ControladorCatalogo?accion=explorar");
    }

    // =========================================================================
    // MÉTODO ALTERNO: volverInicio() - Flujo alterno 12.2
    // =========================================================================
    /**
     * El comprador solicita volver al inicio.
     * Flujo alterno 12.2:
     * 12.2.1 El comprador solicita Volver al Inicio
     * 12.2.2 El sistema retorna al inicio del sistema
     */
    private void volverInicio(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Limpiar datos del pedido procesado
        HttpSession session = request.getSession();
        session.removeAttribute("pedidoConfirmado");
        session.removeAttribute("comprobanteImagen");
        session.removeAttribute("comprobanteNombre");
        session.removeAttribute("pagoTransferencia");
        
        // Redirigir al panel del comprador
        response.sendRedirect(request.getContextPath() + "/vista/PanelDeComprador.jsp");
    }

    // =========================================================================
    // MÉTODO AUXILIAR: enviarPedido(pedido : Pedido) - Diagrama ProcesarCompra
    // =========================================================================
    /**
     * Envía el pedido para su procesamiento.
     * Según diagrama: +enviarPedido(pedido : Pedido) : void
     */
    private void enviarPedido(Pedido pedido) {
        System.out.println("✓ Enviando pedido: " + pedido.getNumeroPedido());
        pedido.setEstado("PROCESANDO");
    }
}
