package com.controlador;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

import com.dao.CarritoComprasDAO;
import com.dao.ItemCarritoDAO;
import com.modelo.entities.CarritoCompras;
import com.modelo.entities.ItemCarrito;

/**
 * ========================================================================
 * CONTROLADOR: GestionarCarrito (Servlet)
 * ========================================================================
 * Implementa el flujo de Gestionar Carrito de Compras según los diagramas 
 * de robustez y secuencia.
 * 
 * Métodos según diagrama de clases:
 * +accederACarritoDeCompras() : void
 * +procesarPedido() : void
 * +seguirComprando() : void
 * +eliminarProductoDelCarrito(itemCarrito : ItemCarrito) : void
 * +vaciarCarrito() : void
 * +modificarCantidadItem(opcion : int) : void
 * 
 * Flujo Principal según caso de uso:
 * 1. El comprador solicita acceder a su Carrito de Compras.
 * 2. El sistema muestra el Carrito de Compras con los productos agregados
 *    y las acciones disponibles.
 */
@WebServlet(name = "GestionarCarritoServlet", urlPatterns = {"/GestionarCarrito"})
public class GestionarCarritoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private CarritoComprasDAO carritoComprasDAO;
    private ItemCarritoDAO itemCarritoDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        carritoComprasDAO = new CarritoComprasDAO();
        itemCarritoDAO = new ItemCarritoDAO();
    }

    /**
     * Maneja las solicitudes GET
     * Acciones: acceder, seguirComprando, eliminar, vaciar, modificarCantidad
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        try {
            if (action == null || "acceder".equals(action)) {
                // 1.1: accederACarritoDeCompras
                accederACarritoDeCompras(request, response);
            } else if ("seguirComprando".equals(action)) {
                // 2.2.1: seguirComprando
                seguirComprando(request, response);
            } else if ("eliminar".equals(action)) {
                // 2.3.1: eliminarProductoDelCarrito - mostrar confirmación
                int itemId = Integer.parseInt(request.getParameter("itemId"));
                HttpSession session = request.getSession();
                CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
                
                if (carrito != null) {
                    // Buscar el item a eliminar para mostrar en el mensaje
                    for (ItemCarrito item : carrito.getItems()) {
                        if (item.getIdItem() == itemId) {
                            // 2.3.2: mostrarMensajeConfirmacion
                            request.setAttribute("confirmarEliminar", true);
                            request.setAttribute("itemAEliminar", item);
                            request.setAttribute("itemId", itemId);
                            break;
                        }
                    }
                }
                accederACarritoDeCompras(request, response);
            } else if ("vaciar".equals(action)) {
                // 2.4.1: vaciarCarrito - mostrar confirmación
                // 2.4.2: mostrarMensajeConfirmacion
                request.setAttribute("confirmarVaciar", true);
                accederACarritoDeCompras(request, response);
            } else if ("modificarCantidad".equals(action)) {
                // 2.5.1: modificarCantidadItem
                String opcion = request.getParameter("opcion");
                int itemId = Integer.parseInt(request.getParameter("itemId"));
                modificarCantidadItem(request, response, itemId, opcion);
            } else {
                accederACarritoDeCompras(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error: " + e.getMessage());
            accederACarritoDeCompras(request, response);
        }
    }

    /**
     * Maneja las solicitudes POST
     * Acciones: confirmarEliminar, confirmarVaciar, procesarPedido
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        try {
            if ("confirmarEliminar".equals(action)) {
                // 2.3.3: confirmar eliminación del producto
                int itemId = Integer.parseInt(request.getParameter("itemId"));
                eliminarProductoDelCarrito(request, response, itemId);
            } else if ("confirmarVaciar".equals(action)) {
                // 2.4.3: confirmar vaciar carrito
                vaciarCarrito(request, response);
            } else if ("procesarPedido".equals(action)) {
                // 2.1.1: procesarPedido
                procesarPedido(request, response);
            } else if ("agregarPersonalizado".equals(action)) {
                // Agregar producto personalizado al carrito
                agregarPersonalizadoAlCarrito(request, response);
            } else {
                accederACarritoDeCompras(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error: " + e.getMessage());
            accederACarritoDeCompras(request, response);
        }
    }

    // =========================================================================
    // MÉTODO 1: accederACarritoDeCompras() - Diagrama de robustez 1.1
    // =========================================================================
    /**
     * Permite al comprador acceder a su Carrito de Compras.
     * Diagrama de robustez:
     * 1.1: accederACarritoDeCompras
     * 1.2: obtenerCarritoDeCompras:carritocompras
     * 1.3: obtenerItemsDelCarrito:itemscarrito
     * 1.4: mostrarCarritoConProductos
     */
    private void accederACarritoDeCompras(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        
        // 1.2: obtenerCarritoDeCompras:carritocompras
        CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
        carrito = carritoComprasDAO.obtenerCarritoDeCompras(carrito);
        
        // Guardar en sesión si es nuevo
        session.setAttribute("carritoCompras", carrito);
        
        // 1.3: obtenerItemsDelCarrito:itemscarrito
        List<ItemCarrito> items = itemCarritoDAO.obtenerItemsDelCarrito(carrito.getItems());
        
        // Verificar si el carrito está vacío (Excepción general 3.1)
        if (carrito.estaVacio()) {
            // 2.4.3: mostrarCarritoVacio
            request.setAttribute("carritoVacio", true);
        }
        
        // Calcular resumen del pedido
        double subtotal = carrito.getSubtotal();
        double iva = subtotal * 0.15; // 15% IVA
        double envio = subtotal > 0 ? 5.00 : 0.00; // Costo de envío fijo
        double total = subtotal + iva + envio;
        
        // Pasar datos a la vista
        request.setAttribute("carrito", carrito);
        request.setAttribute("items", items);
        request.setAttribute("subtotal", subtotal);
        request.setAttribute("iva", iva);
        request.setAttribute("envio", envio);
        request.setAttribute("total", total);
        
        // 1.4: mostrarCarritoConProductos
        request.getRequestDispatcher("/vista/CarritoDeCompras.jsp").forward(request, response);
    }

    // =========================================================================
    // MÉTODO 2: procesarPedido() - Diagrama de robustez 2.1.1
    // =========================================================================
    /**
     * Procesa el pedido del carrito de compras.
     * Diagrama de robustez:
     * 2.1.1: procesarPedido
     * 2.1.2: enviarItemsCarrito(carritocompras)
     * 
     * Excepción 3.1: Si el carrito está vacío, informa al usuario
     */
    private void procesarPedido(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
        
        // Excepción 3.1: Verificar si hay productos en el carrito
        if (carrito == null || carrito.estaVacio()) {
            // 3.2: Informar que no existen productos disponibles para procesar
            request.setAttribute("error", "No existen productos disponibles para procesar. Por favor, agregue productos al carrito.");
            accederACarritoDeCompras(request, response);
            return;
        }
        
        // 2.1.2: enviarItemsCarrito(carritocompras)
        // Redirigir al flujo de procesar pedido
        response.sendRedirect(request.getContextPath() + "/ProcesarPedido?action=solicitarProcesarPedido");
    }

    // =========================================================================
    // MÉTODO 3: seguirComprando() - Diagrama de robustez 2.2.1
    // =========================================================================
    /**
     * Redirige al catálogo de productos para seguir comprando.
     * Diagrama de robustez:
     * 2.2.1: seguirComprando
     * 2.2.3: mostrarCatalogoProductos
     */
    private void seguirComprando(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // 2.2.3: mostrarCatalogoProductos
        response.sendRedirect(request.getContextPath() + "/ControladorCatalogo?accion=explorar");
    }

    // =========================================================================
    // MÉTODO 4: eliminarProductoDelCarrito(itemCarrito) - Diagrama de robustez 2.3
    // =========================================================================
    /**
     * Elimina un producto del carrito después de confirmar.
     * Diagrama de robustez:
     * 2.3.3: confirmar eliminación
     * 2.3.4: eliminarItemDelCarrito(itemcarritoid)
     * 2.3.4: accederACarritoDeCompras (actualizar lista)
     */
    private void eliminarProductoDelCarrito(HttpServletRequest request, HttpServletResponse response, int itemId) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
        
        if (carrito != null) {
            // 2.3.3: eliminarItemDelCarrito(itemcarritoid)
            carritoComprasDAO.eliminarItemDelCarrito(carrito, itemId);
            session.setAttribute("carritoCompras", carrito);
            
            request.setAttribute("mensaje", "Producto eliminado del carrito exitosamente.");
        }
        
        // 2.3.4: accederACarritoDeCompras (actualizar lista y resumen)
        accederACarritoDeCompras(request, response);
    }

    // =========================================================================
    // MÉTODO 5: vaciarCarrito() - Diagrama de robustez 2.4
    // =========================================================================
    /**
     * Vacía todos los productos del carrito después de confirmar.
     * Diagrama de robustez:
     * 2.4.3: confirmar vaciar
     * 2.4.2: quitarTodosLosItems(carritocompras)
     * 2.4.3: mostrarCarritoVacio
     */
    private void vaciarCarrito(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
        
        if (carrito != null) {
            // 2.4.2: quitarTodosLosItems(carritocompras)
            carritoComprasDAO.quitarTodosLosItems(carrito);
            session.setAttribute("carritoCompras", carrito);
            
            request.setAttribute("mensaje", "Carrito vaciado exitosamente.");
        }
        
        // 2.4.3: mostrarCarritoVacio
        accederACarritoDeCompras(request, response);
    }

    // =========================================================================
    // MÉTODO 6: modificarCantidadItem(opcion) - Diagrama de robustez 2.5
    // =========================================================================
    /**
     * Modifica la cantidad de un producto en el carrito.
     * Diagrama de robustez:
     * 2.5.1: modificarCantidadItem(opcion) - + o -
     * 2.5.2: recalcularSubtotal
     * 2.5.3: mostrarResumenCarrito (actualizado)
     * 
     * @param opcion "incrementar" (+) o "decrementar" (-)
     */
    private void modificarCantidadItem(HttpServletRequest request, HttpServletResponse response, 
            int itemId, String opcion) throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
        
        if (carrito != null) {
            // Buscar el item a modificar
            for (ItemCarrito item : carrito.getItems()) {
                if (item.getIdItem() == itemId) {
                    // 2.5.1: modificarCantidadItem(opcion)
                    if ("incrementar".equals(opcion)) {
                        // CONTROL DE STOCK: Verificar stock disponible antes de incrementar
                        if (item.getItem() instanceof com.modelo.entities.Producto) {
                            com.modelo.entities.Producto producto = (com.modelo.entities.Producto) item.getItem();
                            // Obtener producto actualizado de la BD para verificar stock real
                            com.dao.ProductoDAO productoDAO = new com.dao.ProductoDAO();
                            com.modelo.entities.Producto productoActualizado = productoDAO.obtenerDatosProducto(producto.getId());
                            if (productoActualizado != null) {
                                if (item.getCantidad() >= productoActualizado.getStock()) {
                                    request.setAttribute("error", "❌ No puedes agregar más unidades. Stock máximo disponible: " + productoActualizado.getStock());
                                    break;
                                }
                            }
                        }
                        item.incrementarCantidad();
                    } else if ("decrementar".equals(opcion)) {
                        item.decrementarCantidad();
                    }
                    break;
                }
            }
            
            // 2.5.2: recalcularSubtotal
            carritoComprasDAO.recalcularSubtotal(carrito);
            session.setAttribute("carritoCompras", carrito);
        }
        
        // 2.5.3: mostrarResumenCarrito (actualizar vista con nuevo total)
        accederACarritoDeCompras(request, response);
    }

    // =========================================================================
    // MÉTODO 7: agregarPersonalizadoAlCarrito() - Diagrama de robustez flujopersonalizarproducto
    // =========================================================================
    /**
     * MÉTODO SEGÚN DIAGRAMA DE ROBUSTEZ flujopersonalizarproducto:
     * 1.5: guardarProductoPersonalizado(productopersonalizable, seccion)
     * 1.6: agregarPersonalizadoAlCarrito(itemventaid):itemcarrito
     * 1.7: guardarItemCarrito(itemcarrito)
     * 
     * Crea un ProductoPersonalizado con las opciones seleccionadas y lo agrega al carrito
     */
    @SuppressWarnings("unchecked")
    private void agregarPersonalizadoAlCarrito(HttpServletRequest request, HttpServletResponse response) 
            throws Exception {
        
        HttpSession session = request.getSession();
        
        // Obtener las opciones seleccionadas de la sesión
        List<com.modelo.entities.ProductoPersonalizable> opcionesSeleccionadas = 
            (List<com.modelo.entities.ProductoPersonalizable>) session.getAttribute("opcionesSeleccionadas");
        Double precioTotal = (Double) session.getAttribute("precioTotal");
        
        if (opcionesSeleccionadas == null || opcionesSeleccionadas.isEmpty()) {
            request.setAttribute("error", "Debe seleccionar al menos una opción antes de agregar al carrito");
            request.setAttribute("tipoMensaje", "error");
            response.sendRedirect(request.getContextPath() + "/PersonalizarProducto");
            return;
        }
        
        // 1.5: guardarProductoPersonalizado - Crear ProductoPersonalizado
        com.modelo.entities.ProductoPersonalizado productoPersonalizado = new com.modelo.entities.ProductoPersonalizado();
        productoPersonalizado.setNombre("Producto Personalizado");
        productoPersonalizado.setPrecio(precioTotal != null ? precioTotal : 0.0);
        productoPersonalizado.setOpciones(new java.util.ArrayList<>(opcionesSeleccionadas));
        
        // Si hay opciones, obtener la primera sección
        if (!opcionesSeleccionadas.isEmpty() && opcionesSeleccionadas.get(0).getSeccion() != null) {
            productoPersonalizado.setSeccion(opcionesSeleccionadas.get(0).getSeccion());
        }
        
        // Obtener o crear el carrito de compras
        CarritoCompras carrito = (CarritoCompras) session.getAttribute("carritoCompras");
        if (carrito == null) {
            carrito = new CarritoCompras();
        }
        
        // 1.6: agregarPersonalizadoAlCarrito(itemventaid):itemcarrito
        ItemCarrito itemCarrito = new ItemCarrito(productoPersonalizado);
        
        // 1.7: guardarItemCarrito(itemcarrito)
        carritoComprasDAO.guardarItemCarrito(carrito, itemCarrito);
        
        // Guardar carrito en sesión
        session.setAttribute("carritoCompras", carrito);
        
        // Limpiar las opciones seleccionadas después de agregar al carrito
        session.setAttribute("opcionesSeleccionadas", new java.util.ArrayList<com.modelo.entities.ProductoPersonalizable>());
        session.setAttribute("precioTotal", 0.0);
        
        // Mostrar mensaje de confirmación
        request.setAttribute("mensaje", "✓ Producto personalizado agregado al carrito exitosamente. Total: $" + String.format("%.2f", precioTotal));
        request.setAttribute("tipoMensaje", "exito");
        request.setAttribute("volverUrl", request.getContextPath() + "/PersonalizarProducto");
        request.setAttribute("carritoUrl", request.getContextPath() + "/GestionarCarrito?action=acceder");
        
        request.getRequestDispatcher("/vista/Mensaje.jsp").forward(request, response);
    }
}
