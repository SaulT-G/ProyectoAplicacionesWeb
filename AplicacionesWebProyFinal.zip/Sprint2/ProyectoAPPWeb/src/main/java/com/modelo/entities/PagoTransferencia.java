package com.modelo.entities;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * ========================================================================
 * ENTIDAD: PagoTransferencia
 * ========================================================================
 * Representa un pago por transferencia bancaria.
 * Según el diagrama de clases:
 * - idPago : int
 * - monto : double
 * - fechaPago : Date
 * - banco : String
 * - titular : String
 * - numeroCuenta : String
 * - tipoCuenta : String
 * - RUC : String
 */
@Entity
@Table(name = "pago_transferencia")
public class PagoTransferencia implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pago")
    private Integer idPago;

    @Column(name = "monto", nullable = false)
    private double monto;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "fecha_pago", nullable = false)
    private Date fechaPago;

    @Column(name = "banco", length = 100)
    private String banco;

    @Column(name = "titular", length = 200)
    private String titular;

    @Column(name = "numero_cuenta", length = 50)
    private String numeroCuenta;

    @Column(name = "tipo_cuenta", length = 50)
    private String tipoCuenta;

    @Column(name = "ruc", length = 20)
    private String RUC;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "id_comprobante")
    private Comprobante comprobante;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_pedido")
    private Pedido pedido;

    // Constructores
    public PagoTransferencia() {
        this.fechaPago = new Date();
    }

    public PagoTransferencia(double monto, String banco, String titular, String numeroCuenta, String tipoCuenta, String RUC) {
        this.monto = monto;
        this.fechaPago = new Date();
        this.banco = banco;
        this.titular = titular;
        this.numeroCuenta = numeroCuenta;
        this.tipoCuenta = tipoCuenta;
        this.RUC = RUC;
    }

    // Getters y Setters
    public Integer getIdPago() {
        return idPago;
    }

    public void setIdPago(Integer idPago) {
        this.idPago = idPago;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public Date getFechaPago() {
        return fechaPago;
    }

    public void setFechaPago(Date fechaPago) {
        this.fechaPago = fechaPago;
    }

    public String getBanco() {
        return banco;
    }

    public void setBanco(String banco) {
        this.banco = banco;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public String getTipoCuenta() {
        return tipoCuenta;
    }

    public void setTipoCuenta(String tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    public String getRUC() {
        return RUC;
    }

    public void setRUC(String RUC) {
        this.RUC = RUC;
    }

    public Comprobante getComprobante() {
        return comprobante;
    }

    public void setComprobante(Comprobante comprobante) {
        this.comprobante = comprobante;
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    @Override
    public String toString() {
        return "PagoTransferencia{" +
                "idPago=" + idPago +
                ", monto=" + monto +
                ", fechaPago=" + fechaPago +
                ", banco='" + banco + '\'' +
                ", titular='" + titular + '\'' +
                '}';
    }
}
