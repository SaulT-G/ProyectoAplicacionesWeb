package com.modelo.entities;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * ========================================================================
 * ENTIDAD: Comprobante
 * ========================================================================
 * Representa un comprobante de pago.
 * Según el diagrama de clases:
 * - nombreComprador : String
 * - numeroComprobante : String
 * - fechaEmision : Date
 */
@Entity
@Table(name = "comprobante")
public class Comprobante implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_comprobante")
    private Integer idComprobante;

    @Column(name = "nombre_comprador", length = 200)
    private String nombreComprador;

    @Column(name = "numero_comprobante", nullable = false, unique = true, length = 50)
    private String numeroComprobante;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "fecha_emision", nullable = false)
    private Date fechaEmision;

    @Lob
    @Column(name = "imagen_comprobante", columnDefinition = "MEDIUMBLOB")
    private byte[] imagenComprobante;

    @Column(name = "estado", length = 30)
    private String estado;

    // Constructores
    public Comprobante() {
        this.fechaEmision = new Date();
        this.estado = "PENDIENTE";
    }

    public Comprobante(String nombreComprador, String numeroComprobante, Date fechaEmision) {
        this.nombreComprador = nombreComprador;
        this.numeroComprobante = numeroComprobante;
        this.fechaEmision = fechaEmision;
        this.estado = "PENDIENTE";
    }

    // Getters y Setters
    public Integer getIdComprobante() {
        return idComprobante;
    }

    public void setIdComprobante(Integer idComprobante) {
        this.idComprobante = idComprobante;
    }

    public String getNombreComprador() {
        return nombreComprador;
    }

    public void setNombreComprador(String nombreComprador) {
        this.nombreComprador = nombreComprador;
    }

    public String getNumeroComprobante() {
        return numeroComprobante;
    }

    public void setNumeroComprobante(String numeroComprobante) {
        this.numeroComprobante = numeroComprobante;
    }

    public Date getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(Date fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public byte[] getImagenComprobante() {
        return imagenComprobante;
    }

    public void setImagenComprobante(byte[] imagenComprobante) {
        this.imagenComprobante = imagenComprobante;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Comprobante{" +
                "idComprobante=" + idComprobante +
                ", nombreComprador='" + nombreComprador + '\'' +
                ", numeroComprobante='" + numeroComprobante + '\'' +
                ", fechaEmision=" + fechaEmision +
                ", estado='" + estado + '\'' +
                '}';
    }
}
