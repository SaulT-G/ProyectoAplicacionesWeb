package com.modelo.entities;

import jakarta.persistence.*;
import java.io.Serializable;

/**
 * Clase Direccion - Entidad JPA que representa la dirección de un comprador
 * Según el diagrama de clases del flujo Gestionar Clientes
 */
@Entity
@Table(name = "direccion")
public class Direccion implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_direccion")
    private Integer idDireccion;

    @Column(name = "calle", nullable = false, length = 200)
    private String calle;

    @Column(name = "provincia", nullable = false, length = 100)
    private String provincia;

    @Column(name = "ciudad", nullable = false, length = 100)
    private String ciudad;

    @Column(name = "codigo_postal", length = 20)
    private String codigoPostal;

    @Column(name = "referencia", length = 255)
    private String referencia;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_comprador", nullable = true)
    private Comprador comprador;

    // Constructores
    public Direccion() {
    }

    public Direccion(String calle, String provincia, String ciudad, String codigoPostal, String referencia) {
        this.calle = calle;
        this.provincia = provincia;
        this.ciudad = ciudad;
        this.codigoPostal = codigoPostal;
        this.referencia = referencia;
    }

    // Getters y Setters
    public Integer getIdDireccion() {
        return idDireccion;
    }

    public void setIdDireccion(Integer idDireccion) {
        this.idDireccion = idDireccion;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getCodigoPostal() {
        return codigoPostal;
    }

    public void setCodigoPostal(String codigoPostal) {
        this.codigoPostal = codigoPostal;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public Comprador getComprador() {
        return comprador;
    }

    public void setComprador(Comprador comprador) {
        this.comprador = comprador;
    }

    @Override
    public String toString() {
        return calle + ", " + ciudad + ", " + provincia + 
               (codigoPostal != null ? " - " + codigoPostal : "") +
               (referencia != null ? " (Ref: " + referencia + ")" : "");
    }
}
