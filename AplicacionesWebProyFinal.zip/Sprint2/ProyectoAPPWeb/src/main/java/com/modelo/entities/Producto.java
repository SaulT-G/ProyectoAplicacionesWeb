package com.modelo.entities;

import java.math.BigDecimal;
import jakarta.persistence.*;

/**
 * ========================================================================
 * ENTIDAD: Producto (Hereda de ItemVenta)
 * ========================================================================
 * Representa un producto estándar del catálogo.
 * Hereda id, nombre y precio de ItemVenta.
 * 
 * Atributos propios:
 * - descripcion: Descripción del producto
 * - stock: Cantidad en inventario
 * - imagen: Imagen del producto
 * - descuento: Descuento aplicable
 * - categoria: Categoría del producto
 */
@Entity
@Table(name = "producto")
@PrimaryKeyJoinColumn(name = "id")
public class Producto extends ItemVenta {
    private static final long serialVersionUID = 1L;

    @Column(name = "descripcion", columnDefinition = "TEXT")
    private String descripcion;

    @Column(name = "stock", nullable = false)
    private int stock;

    @Column(name = "descuento", precision = 5, scale = 2)
    private BigDecimal descuento = BigDecimal.ZERO;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "categoria_id")
    private Categoria categoria;

    // Constructores
    public Producto() {
        super();
        this.descuento = BigDecimal.ZERO;
    }

    public Producto(String nombre, String descripcion, BigDecimal precio, int stock, byte[] imagen, Categoria categoria) {
        super(nombre, precio.doubleValue());
        this.descripcion = descripcion;
        this.stock = stock;
        super.imagen = imagen;
        this.categoria = categoria;
        this.descuento = BigDecimal.ZERO;
    }

    public Producto(int id, String nombre, String descripcion, BigDecimal precio, int stock, byte[] imagen, Categoria categoria) {
        super(id, nombre, precio.doubleValue());
        this.descripcion = descripcion;
        this.stock = stock;
        super.imagen = imagen;
        this.categoria = categoria;
        this.descuento = BigDecimal.ZERO;
    }

    // Getters y Setters (propios de Producto)
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public byte[] getImagen() {
        return super.imagen;
    }

    public void setImagen(byte[] imagen) {
        super.imagen = imagen;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    // Método sobrecargado para establecer precio desde BigDecimal (mantener compatibilidad)
    @Override
    public void setPrecio(BigDecimal precio) {
        super.precio = precio;
    }

    /**
     * Sobrescribe getPrecio() para devolver el precio con descuento aplicado.
     * De esta forma, el descuento se refleja automáticamente en catálogo, carrito y pedido.
     * @return precio con descuento aplicado (precio - (precio * descuento / 100))
     */
    @Override
    public BigDecimal getPrecio() {
        if (descuento != null && descuento.compareTo(BigDecimal.ZERO) > 0 && super.precio != null) {
            // Calcular precio con descuento: precio - (precio * descuento / 100)
            BigDecimal descuentoAplicado = super.precio.multiply(descuento).divide(new BigDecimal("100"), 2, java.math.RoundingMode.HALF_UP);
            return super.precio.subtract(descuentoAplicado);
        }
        return super.precio;
    }

    /**
     * Obtiene el precio original sin descuento (para mostrar precio tachado en vistas)
     * @return precio base sin descuento
     */
    public BigDecimal getPrecioOriginal() {
        return super.precio;
    }

    public BigDecimal getDescuento() {
        return descuento;
    }

    public void setDescuento(BigDecimal descuento) {
        this.descuento = descuento;
    }

    @Override
    public String toString() {
        return "Producto{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", precio=" + precio +
                ", stock=" + stock +
                ", imagen=" + (imagen != null ? "[" + imagen.length + " bytes]" : "null") +
                ", descuento=" + descuento +
                ", categoria=" + (categoria != null ? categoria.getNombre() : "null") +
                '}';
    }
}
