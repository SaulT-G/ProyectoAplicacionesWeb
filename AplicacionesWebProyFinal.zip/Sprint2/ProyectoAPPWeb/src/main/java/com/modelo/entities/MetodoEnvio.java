package com.modelo.entities;

import jakarta.persistence.*;
import java.io.Serializable;

/**
 * ========================================================================
 * ENTIDAD: MetodoEnvio
 * ========================================================================
 * Representa un método de envío disponible para el pedido.
 * Según el diagrama de clases:
 * - tipo : String
 * - descripcion : String
 * - costo : double
 * - tiempoEstimado : String
 */
@Entity
@Table(name = "metodo_envio")
public class MetodoEnvio implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_metodo_envio")
    private Integer idMetodoEnvio;

    @Column(name = "tipo", nullable = false, length = 50)
    private String tipo;

    @Column(name = "descripcion", length = 255)
    private String descripcion;

    @Column(name = "costo", nullable = false)
    private double costo;

    @Column(name = "tiempo_estimado", length = 100)
    private String tiempoEstimado;

    // Constructores
    public MetodoEnvio() {
    }

    public MetodoEnvio(String tipo, String descripcion, double costo, String tiempoEstimado) {
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.costo = costo;
        this.tiempoEstimado = tiempoEstimado;
    }

    // Getters y Setters
    public Integer getIdMetodoEnvio() {
        return idMetodoEnvio;
    }

    public void setIdMetodoEnvio(Integer idMetodoEnvio) {
        this.idMetodoEnvio = idMetodoEnvio;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

    public String getTiempoEstimado() {
        return tiempoEstimado;
    }

    public void setTiempoEstimado(String tiempoEstimado) {
        this.tiempoEstimado = tiempoEstimado;
    }

    @Override
    public String toString() {
        return tipo + " - " + descripcion + " ($" + costo + ") - " + tiempoEstimado;
    }
}
