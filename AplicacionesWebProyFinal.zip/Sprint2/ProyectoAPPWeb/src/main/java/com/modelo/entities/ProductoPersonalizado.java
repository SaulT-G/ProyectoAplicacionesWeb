package com.modelo.entities;

import jakarta.persistence.*;
import java.util.List;

/**
 * ========================================================================
 * ENTIDAD: ProductoPersonalizado (Hereda de ItemVenta)
 * ========================================================================
 * Representa un producto que el comprador ha personalizado seleccionando
 * opciones de diferentes secciones de personalización.
 * Hereda id, nombre y precio de ItemVenta.
 * 
 * Relaciones:
 * - ManyToOne con SeccionDePersonalizacion
 * - ManyToMany con ProductoPersonalizable (opciones seleccionadas)
 */
@Entity
@Table(name = "producto_personalizado")
@PrimaryKeyJoinColumn(name = "id")
public class ProductoPersonalizado extends ItemVenta {
    private static final long serialVersionUID = 1L;
    
    @ManyToOne
    @JoinColumn(name = "seccion_id")
    private SeccionDePersonalizacion seccion;
    
    @ManyToMany
    @JoinTable(
        name = "producto_personalizado_opciones",
        joinColumns = @JoinColumn(name = "producto_personalizado_id"),
        inverseJoinColumns = @JoinColumn(name = "opcion_id")
    )
    private List<ProductoPersonalizable> opciones;

    // Constructor vacío (requerido por JPA)
    public ProductoPersonalizado() {
        super();
    }

    // Getters y Setters (propios de ProductoPersonalizado)
    public SeccionDePersonalizacion getSeccion() {
        return seccion;
    }

    public void setSeccion(SeccionDePersonalizacion seccion) {
        this.seccion = seccion;
    }

    public List<ProductoPersonalizable> getOpciones() {
        return opciones;
    }

    public void setOpciones(List<ProductoPersonalizable> opciones) {
        this.opciones = opciones;
    }

    // Métodos getId, setId, getNombre, setNombre, getPrecio, setPrecio 
    // se heredan de ItemVenta
}
